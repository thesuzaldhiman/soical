<?php
/**
 * Plugin Name: Auto Engine
 * Plugin URI: https://example.com/auto-engine
 * Description: Fully automated RSS-based news publishing with content cleaning, image watermarking, SEO optimization, and bidirectional Social Auto Poster Bridge.
 * Version: 7.6.0
 * Author: Auto Engine
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: auto-engine
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants
define( 'AE_VERSION', '7.6.0' );
define( 'AE_PLUGIN_FILE', __FILE__ );
define( 'AE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Activation hook — create database tables and set defaults.
 */
function ae_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Feeds table
    $table_feeds = $wpdb->prefix . 'ae_feeds';
    $sql_feeds = "CREATE TABLE $table_feeds (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        feed_url TEXT NOT NULL,
        feed_name VARCHAR(255) DEFAULT '',
        category_id BIGINT(20) UNSIGNED DEFAULT 0,
        category_ids TEXT DEFAULT NULL,
        fetch_mode VARCHAR(20) DEFAULT 'new_only',
        image_mode VARCHAR(20) DEFAULT 'featured_only',
        fetch_interval INT UNSIGNED DEFAULT 10,
        author_id BIGINT(20) UNSIGNED DEFAULT 0,
        logo_watermark TINYINT(1) DEFAULT 0,
        logo_position VARCHAR(20) DEFAULT 'bottom-right',
        content_mode VARCHAR(20) DEFAULT 'direct',
        is_active TINYINT(1) DEFAULT 1,
        last_fetched DATETIME DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Logs table
    $table_logs = $wpdb->prefix . 'ae_logs';
    $sql_logs = "CREATE TABLE $table_logs (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        feed_id BIGINT(20) UNSIGNED DEFAULT 0,
        log_type VARCHAR(20) DEFAULT 'info',
        message TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY feed_id (feed_id),
        KEY log_type (log_type),
        KEY created_at (created_at)
    ) $charset_collate;";

    // Processed items table
    $table_processed = $wpdb->prefix . 'ae_processed';
    $sql_processed = "CREATE TABLE $table_processed (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        feed_id BIGINT(20) UNSIGNED DEFAULT 0,
        item_hash VARCHAR(64) NOT NULL,
        title TEXT NOT NULL,
        post_id BIGINT(20) UNSIGNED DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY item_hash (item_hash),
        KEY feed_id (feed_id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql_feeds );
    dbDelta( $sql_logs );
    dbDelta( $sql_processed );

    // Upgrade: add new columns if they don't exist (for existing installs)
    $existing_cols = $wpdb->get_col( "DESCRIBE {$table_feeds}", 0 );
    if ( ! in_array( 'fetch_interval', $existing_cols, true ) ) {
        $wpdb->query( "ALTER TABLE {$table_feeds} ADD COLUMN fetch_interval INT UNSIGNED DEFAULT 10 AFTER image_mode" );
    }
    if ( ! in_array( 'author_id', $existing_cols, true ) ) {
        $wpdb->query( "ALTER TABLE {$table_feeds} ADD COLUMN author_id BIGINT(20) UNSIGNED DEFAULT 0 AFTER fetch_interval" );
    }
    if ( ! in_array( 'category_ids', $existing_cols, true ) ) {
        $wpdb->query( "ALTER TABLE {$table_feeds} ADD COLUMN category_ids TEXT DEFAULT NULL AFTER category_id" );
    }
    if ( ! in_array( 'content_mode', $existing_cols, true ) ) {
        $wpdb->query( "ALTER TABLE {$table_feeds} ADD COLUMN content_mode VARCHAR(20) DEFAULT 'direct' AFTER logo_position" );
    }

    // Set default settings
    $defaults = array(
        'post_status'        => 'publish',
        'min_word_count'     => 0,
        'rate_limit_hour'    => 0,
        'rate_limit_day'     => 0,
        'max_posts_per_cycle' => 0,
        'time_slots'         => array(),
        'ai_enabled'         => false,
        'ai_api_key'         => '',
        'ai_model'           => 'gpt-3.5-turbo',
        'ai_rewrite_title'   => false,
        'ai_rewrite_content' => false,
        'ai_custom_prompt'   => '',
        'image_insert'       => true,
        'image_position'     => 1,
        'watermark_enabled'  => false,
        'watermark_image'    => '',
        'watermark_position' => 'bottom-right',
        'watermark_opacity'  => 50,
        'watermark_size'     => 20,
        'find_replace_rules' => array(),
    );

    if ( ! get_option( 'auto_engine_settings' ) ) {
        add_option( 'auto_engine_settings', $defaults );
    }

    // Store DB version
    update_option( 'ae_db_version', AE_VERSION );

    // Schedule cron — runs every 1 minute as heartbeat, checks per-feed intervals
    wp_clear_scheduled_hook( 'auto_engine_cron_hook' );
    if ( ! wp_next_scheduled( 'auto_engine_cron_hook' ) ) {
        wp_schedule_event( time(), 'ae_every_minute', 'auto_engine_cron_hook' );
    }

    // Auto-generate direct cron key if not set
    if ( ! get_option( 'ae_direct_cron_key' ) ) {
        update_option( 'ae_direct_cron_key', wp_generate_password( 32, false ) );
    }
    if ( ! get_option( 'ae_cron_interval' ) ) {
        update_option( 'ae_cron_interval', 2 );
    }

    // Flush rewrite rules
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ae_activate' );

/**
 * Deactivation hook — clear cron.
 */
function ae_deactivate() {
    wp_clear_scheduled_hook( 'auto_engine_cron_hook' );
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'ae_deactivate' );

/**
 * Add custom cron interval.
 */
function ae_cron_schedules( $schedules ) {
    $schedules['ae_every_minute'] = array(
        'interval' => 60,
        'display'  => __( 'Every Minute (Auto Engine Heartbeat)', 'auto-engine' ),
    );

    return $schedules;
}
add_filter( 'cron_schedules', 'ae_cron_schedules' );

/**
 * Load plugin text domain.
 */
function ae_load_textdomain() {
    load_plugin_textdomain( 'auto-engine', false, dirname( AE_PLUGIN_BASENAME ) . '/languages' );
}
add_action( 'plugins_loaded', 'ae_load_textdomain' );

// Include required files
require_once AE_PLUGIN_DIR . 'includes/class-logger.php';
require_once AE_PLUGIN_DIR . 'includes/class-feed-manager.php';
require_once AE_PLUGIN_DIR . 'includes/class-feed-fetcher.php';
require_once AE_PLUGIN_DIR . 'includes/class-content-cleaner.php';
require_once AE_PLUGIN_DIR . 'includes/class-duplicate-checker.php';
require_once AE_PLUGIN_DIR . 'includes/class-ai-rewriter.php';
require_once AE_PLUGIN_DIR . 'includes/class-seo-optimizer.php';
require_once AE_PLUGIN_DIR . 'includes/class-image-handler.php';
require_once AE_PLUGIN_DIR . 'includes/class-publisher.php';
require_once AE_PLUGIN_DIR . 'includes/class-rate-limiter.php';
require_once AE_PLUGIN_DIR . 'includes/class-cron-handler.php';
require_once AE_PLUGIN_DIR . 'includes/class-auto-engine.php';
require_once AE_PLUGIN_DIR . 'includes/class-admin.php';
require_once AE_PLUGIN_DIR . 'includes/class-bridge-api.php';

/**
 * Initialize the plugin.
 */
function ae_init() {
    AE_Auto_Engine::get_instance();
    AE_Bridge_API::get_instance();
    if ( is_admin() ) {
        AE_Admin::get_instance();
    }

    // Bridge Secret Key for Social Auto Poster App
    if ( ! get_option( 'ae_bridge_key' ) ) {
        update_option( 'ae_bridge_key', wp_generate_password( 32, false ) );
    }

    // Existing installs ke liye — agar key nahi hai to generate karo
    if ( ! get_option( 'ae_direct_cron_key' ) ) {
        update_option( 'ae_direct_cron_key', wp_generate_password( 32, false ) );
    }
    if ( ! get_option( 'ae_cron_interval' ) ) {
        update_option( 'ae_cron_interval', 2 );
    }
}
add_action( 'plugins_loaded', 'ae_init', 20 );

/**
 * Direct HTTP Cron Trigger — WP-Cron ko bypass karta hai.
 *
 * URL: https://yoursite.com/?ae_cron=1&ae_key=AE_DIRECT_CRON_KEY
 *
 * wp-config.php mein add karo:
 *   define( 'AE_DIRECT_CRON_KEY', 'apni-secret-key-yahan' );
 */
function ae_direct_cron_trigger() {
    if ( ! isset( $_GET['ae_cron'] ) || $_GET['ae_cron'] !== '1' ) {
        return;
    }

    // wp-config.php mein constant define hai to woh use karo, warna DB key use karo
    if ( defined( 'AE_DIRECT_CRON_KEY' ) && AE_DIRECT_CRON_KEY !== '' ) {
        $valid_key = AE_DIRECT_CRON_KEY;
    } else {
        $valid_key = get_option( 'ae_direct_cron_key', '' );
    }

    $request_key = isset( $_GET['ae_key'] ) ? sanitize_text_field( $_GET['ae_key'] ) : '';

    if ( empty( $valid_key ) || ! hash_equals( $valid_key, $request_key ) ) {
        status_header( 403 );
        die( 'Forbidden' );
    }

    // WP-Cron bypass — seedha run karo
    if ( ! defined( 'DOING_CRON' ) ) {
        define( 'DOING_CRON', true );
    }

    AE_Cron_Handler::get_instance()->run();

    status_header( 200 );
    die( 'OK' );
}
add_action( 'init', 'ae_direct_cron_trigger', 1 );
