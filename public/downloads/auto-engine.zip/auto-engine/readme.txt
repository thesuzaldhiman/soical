=== Auto Engine ===
Contributors: autoengine
Tags: rss, automation, news, publishing, ai
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 7.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Fully automated RSS-based news publishing with content cleaning, optional AI rewriting, image watermarking, and SEO optimization.

== Description ==

Auto Engine is a production-ready WordPress plugin that automates news publishing from RSS feeds. It fetches content, cleans it, optionally rewrites it using AI, handles images with watermarking, optimizes for SEO, and publishes automatically.

**Key Features:**

* RSS Feed Management with modern admin UI
* Content Cleaning Engine (removes links, preserves embeds & structure)
* Optional AI Rewriting via OpenAI API
* Image Handling with watermark support
* SEO Optimization (title, meta, slug, tags)
* Duplicate Protection (title + content hash)
* Rate Limiting (per hour/day)
* Comprehensive Logging System
* WP-Cron based near real-time publishing
* Manual fetch and reprocess controls

== Installation ==

1. Upload the `auto-engine` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'Auto Engine' in your admin sidebar
4. Add your first RSS feed and configure settings

== Frequently Asked Questions ==

= Does this plugin require an AI API key? =
No. AI rewriting is completely optional. The plugin works perfectly with just content cleaning.

= What RSS feeds are supported? =
Any valid RSS 2.0 or Atom feed is supported via WordPress's built-in SimplePie library.

= How does duplicate protection work? =
The plugin checks each incoming item by generating a SHA-256 hash of the title and link. If a match is found, the item is skipped.

== Changelog ==

= 7.5.0 =
* New: Social Auto Poster Bridge REST API (`/wp-json/auto-engine/v1/publish` and `/wp-json/auto-engine/v1/status`). Allows direct remote post drafting, watermarked image publishing, and scheduling from the Social Auto Poster Web Studio.
* New: Social Auto Poster settings tab with 1-click Secret Key copy and connection guide.

= 7.3.1 =
* Fix: Watermark logo washed-out/dull dikhna (opacity 100% set hone par bhi) aur corner ke around dark/grey patch dikhna — yeh PHP GD library ke `imagecopymerge()` function ka jaana-mana bug tha jo semi-transparent pixels (soft shadow/glow effect wale logos mein common) ko galat blend karta tha. Ab manual alpha-channel scaling se opacity correctly apply hoti hai, aur logo bilkul corner se sharp/clean dikhega (agar Imagick server pe available nahi hai aur GD fallback use ho raha ho).

= 7.3.0 =
* Fix: Per-feed watermark settings (opacity, size, "corner se touch") ab silently reset nahi hote. Bug tha — feed due-check cron jab sirf "last_fetched" timestamp update karta tha, to woh galti se opacity/size/no_margin ko bhi default values (80%/20%/off) pe reset kar deta tha. Ab yeh values sirf tab badlengi jab aap explicitly Feed Manager se save karein.
* New: Feed Manager table mein "📰 News" column add hua — har feed ki aaj ki aur total published news count dikhti hai.
* New: "All Posts" list (Screen Options) mein "📡 Auto Engine" column add hua — toggle karne par har post ke saamne dikhega ki woh kis feed se publish hui (feed ka naam), ya "—" agar manually banayi gayi post hai.

= 7.2.0 =
* New: Short-content scraping fallback — agar feed sirf chhota teaser/summary deti hai (e.g. onmanorama.com jaisi feeds jo poora article RSS mein nahi dalti), plugin ab article URL se full content scrape karne ki koshish karega (Settings → Content Quality & Rate Limits → "Scrape Short Feed Content").
* Fix: Word count calculation ab Hindi/Devanagari content ko bhi sahi se count karta hai (pehle sirf ASCII/Latin words count hote the, jisse Hindi articles ka word count galat (bahut kam) aata tha).

= 1.0.0 =
* Initial release
* RSS feed management
* Content cleaning engine
* Optional AI rewriting
* Image handling with watermark
* SEO optimization
* Duplicate protection
* Rate limiting
* Comprehensive logging
* Modern admin dashboard
