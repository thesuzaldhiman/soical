/**
 * Auto Engine — Admin Dashboard JavaScript
 *
 * Handles all AJAX operations, modal management, tab navigation,
 * feed management, settings, logs, and toast notifications.
 *
 * @package Auto_Engine
 */

(function ($) {
    'use strict';

    // ─── Toast Notification System ───
    const Toast = {
        container: null,

        init() {
            this.container = $('<div class="ae-toast-container"></div>');
            $('body').append(this.container);
        },

        show(message, type = 'info', duration = 4000) {
            const icons = {
                success: '✓',
                error: '✕',
                warning: '⚠',
                info: 'ℹ',
            };

            const toast = $(`
                <div class="ae-toast ae-toast-${type}">
                    <span class="ae-toast-icon">${icons[type] || icons.info}</span>
                    <span class="ae-toast-message">${message}</span>
                    <button class="ae-toast-dismiss">×</button>
                </div>
            `);

            this.container.append(toast);

            toast.find('.ae-toast-dismiss').on('click', () => {
                toast.css('animation', 'ae-slideOut 0.3s ease forwards');
                setTimeout(() => toast.remove(), 300);
            });

            if (duration > 0) {
                setTimeout(() => {
                    toast.css('animation', 'ae-slideOut 0.3s ease forwards');
                    setTimeout(() => toast.remove(), 300);
                }, duration);
            }
        },

        success(msg) { this.show(msg, 'success'); },
        error(msg) { this.show(msg, 'error', 6000); },
        warning(msg) { this.show(msg, 'warning'); },
        info(msg) { this.show(msg, 'info'); },
    };

    // ─── AJAX Helper ───
    function aeAjax(action, data = {}, callback = null) {
        data.action = action;
        data.nonce = aeAdmin.nonce;

        // category_ids array ko PHP-compatible format mein flatten karo
        // taaki feed_url jaise baaki fields affect na hon
        const postData = {};
        Object.keys(data).forEach(function(key) {
            if (key === 'category_ids' && Array.isArray(data[key])) {
                data[key].forEach(function(val, i) {
                    postData['category_ids[' + i + ']'] = val;
                });
            } else {
                postData[key] = data[key];
            }
        });

        return $.ajax({
            url: aeAdmin.ajax_url,
            type: 'POST',
            data: postData,
            success(response) {
                if (callback) callback(response);
            },
            error(xhr) {
                Toast.error(aeAdmin.strings.error);
                console.error('AE AJAX Error:', xhr);
            },
        });
    }

    // ─── Button Loading State ───
    function setLoading(btn, loading) {
        const $btn = $(btn);
        if (loading) {
            $btn.addClass('ae-loading').prop('disabled', true);
        } else {
            $btn.removeClass('ae-loading').prop('disabled', false);
        }
    }

    // ─── Tab Navigation ───
    function initTabs() {
        $(document).on('click', '.ae-tab', function () {
            const target = $(this).data('tab');
            const $container = $(this).closest('.ae-wrap');

            // Tabs
            $(this).siblings('.ae-tab').removeClass('ae-active');
            $(this).addClass('ae-active');

            // Content
            $container.find('.ae-tab-content').removeClass('ae-active');
            $container.find(`#ae-tab-${target}`).addClass('ae-active');
        });
    }

    // ─── Modal Management ───
    function openModal(id) {
        $(`#${id}`).addClass('ae-active');
        $('body').css('overflow', 'hidden');
    }

    function closeModal(id) {
        $(`#${id}`).removeClass('ae-active');
        $('body').css('overflow', '');
    }

    function initModals() {
        // Close on overlay click
        $(document).on('click', '.ae-modal-overlay', function (e) {
            if ($(e.target).hasClass('ae-modal-overlay')) {
                $(this).removeClass('ae-active');
                $('body').css('overflow', '');
            }
        });

        // Close button
        $(document).on('click', '.ae-modal-close', function () {
            $(this).closest('.ae-modal-overlay').removeClass('ae-active');
            $('body').css('overflow', '');
        });

        // ESC key
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape') {
                $('.ae-modal-overlay.ae-active').removeClass('ae-active');
                $('body').css('overflow', '');
            }
        });
    }

    // ─── Dashboard ───
    function loadDashboardStats() {
        aeAjax('ae_get_stats', {}, function (res) {
            if (!res.success) return;
            const d = res.data;

            $('#ae-stat-feeds').text(d.total_feeds || 0);
            $('#ae-stat-active').text(d.active_feeds || 0);
            $('#ae-stat-posts').text(d.posts_published || 0);
            $('#ae-stat-errors').text(d.log_counts?.error || 0);

            // Cron status
            if (d.cron && d.cron.scheduled) {
                $('#ae-cron-status').html(`<span class="ae-badge ae-badge-success"><span class="ae-badge-dot"></span> Active</span>`);
                $('#ae-cron-next').text('⚡ Server cron active — har minute run ho raha hai');
            } else {
                $('#ae-cron-status').html(`<span class="ae-badge ae-badge-error"><span class="ae-badge-dot"></span> Inactive</span>`);
                $('#ae-cron-next').text('⚠️ Cron scheduled nahi hai — Cron Setup tab check karo');
            }

            // AI status
            $('#ae-ai-status').html(
                d.ai_enabled
                    ? '<span class="ae-badge ae-badge-success"><span class="ae-badge-dot"></span> Enabled</span>'
                    : '<span class="ae-badge ae-badge-neutral"><span class="ae-badge-dot"></span> Disabled</span>'
            );
        });
    }

    function loadRecentActivity() {
        aeAjax('ae_get_logs', { per_page: 10, page: 1 }, function (res) {
            if (!res.success || !res.data.logs.length) {
                $('#ae-recent-activity').html('<div class="ae-empty"><p>No activity yet.</p></div>');
                return;
            }

            let html = '<div class="ae-timeline">';
            res.data.logs.forEach(function (log) {
                const time = new Date(log.created_at).toLocaleString();
                html += `
                    <div class="ae-timeline-item ae-type-${log.log_type}">
                        <div class="ae-timeline-time">${time}</div>
                        <div class="ae-timeline-message">
                            <span class="ae-badge ae-badge-${getLogBadgeType(log.log_type)} ae-btn-sm">${log.log_type}</span>
                            ${escHtml(log.message)}
                        </div>
                    </div>
                `;
            });
            html += '</div>';

            $('#ae-recent-activity').html(html);
        });
    }

    // ─── Feed Manager ───
    function loadFeeds() {
        aeAjax('ae_get_feeds', {}, function (res) {
            if (!res.success) return;

            const feeds = res.data.feeds;
            const $body = $('#ae-feeds-table-body');

            if (!feeds.length) {
                $body.html(`
                    <tr>
                        <td colspan="8">
                            <div class="ae-empty">
                                <div class="ae-empty-icon">📡</div>
                                <h3>No feeds added yet</h3>
                                <p>Add your first RSS feed to get started.</p>
                            </div>
                        </td>
                    </tr>
                `);
                return;
            }

            let html = '';
            feeds.forEach(function (feed) {
                const isActive = feed.is_active == 1;
                const statusBadge = `
                    <label class="ae-toggle ae-feed-toggle-switch" title="${isActive ? 'Click to Deactivate' : 'Click to Activate'}" style="cursor:pointer;">
                        <input type="checkbox" class="ae-feed-toggle-input" data-id="${feed.id}" ${isActive ? 'checked' : ''} style="position:absolute;opacity:0;width:0;height:0;">
                        <span class="ae-toggle-slider"></span>
                        <span class="ae-toggle-label" style="font-size:12px;color:${isActive ? 'var(--ae-success)' : 'var(--ae-text-muted)'};">${isActive ? 'Active' : 'Inactive'}</span>
                    </label>`;

                const lastFetched = feed.last_fetched
                    ? new Date(feed.last_fetched).toLocaleString()
                    : '—';

                const imageMode = feed.image_mode === 'featured_only' ? '🖼 Featured Only' : '🖼 All Images';
                const logoLabel = feed.logo_watermark == 1
                    ? `<span style="font-size:11px;color:var(--ae-success);">🔖 Logo: ${feed.logo_position || 'bottom-right'}</span>`
                    : `<span style="font-size:11px;color:var(--ae-text-muted);">No Logo</span>`;

                const contentModeMap = {
                    'direct':        '🇬🇧 Direct',
                    'translate':     '🔄 Free Translate',
                    'api_translate': '🤖 API Translate',
                };
                const contentModeLabel = contentModeMap[feed.content_mode] || '🇬🇧 Direct';
                const contentModeBadgeColor = feed.content_mode === 'api_translate' ? 'var(--ae-primary)' : feed.content_mode === 'translate' ? 'var(--ae-warning,#f59e0b)' : 'var(--ae-success)';

                html += `
                    <tr data-feed-id="${feed.id}">
                        <td>
                            <div class="ae-feed-name">${escHtml(feed.feed_name || 'Untitled Feed')}</div>
                            <div class="ae-feed-url">${escHtml(feed.feed_url)}</div>
                        </td>
                        <td>${escHtml(feed.category_names_display || feed.category_name || '—')}</td>
                        <td>${statusBadge}</td>
                        <td><span class="ae-badge ae-badge-info">${feed.fetch_mode === 'all' ? 'All Posts' : 'New Only'}</span><br><span style="font-size:11px;color:${contentModeBadgeColor};margin-top:4px;display:inline-block;">${contentModeLabel}</span></td>
                        <td><span style="font-size:12px;color:var(--ae-text-muted)">${imageMode}</span><br>${logoLabel}</td>
                        <td>
                            <span style="font-size:13px;font-weight:600;color:var(--ae-success);">${feed.posts_today || 0}</span>
                            <span style="font-size:11px;color:var(--ae-text-muted);"> aaj</span>
                            <br>
                            <span style="font-size:11px;color:var(--ae-text-muted);">${feed.posts_total || 0} total</span>
                        </td>
                        <td style="font-size:12px;color:var(--ae-text-muted)">${lastFetched}</td>
                        <td>
                            <div class="ae-actions">
                                <button class="ae-action-btn ae-feed-test" data-url="${escAttr(feed.feed_url)}" title="Test Feed">🔍</button>
                                <button class="ae-action-btn ae-feed-edit" data-id="${feed.id}" title="Edit">✏️</button>
                                <button class="ae-action-btn ae-action-danger ae-feed-delete" data-id="${feed.id}" title="Delete">🗑️</button>
                                <button class="ae-action-btn ae-feed-fetch" data-id="${feed.id}" title="Fetch Now">⚡</button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            $body.html(html);
        });
    }

    // Add Feed
    $(document).on('click', '#ae-add-feed-btn', function () {
        resetFeedForm();
        $('#ae-feed-modal-title').text('Add Feed');
        $('#ae-feed-form-id').val('');
        openModal('ae-feed-modal');
    });

    // Logo watermark checkbox toggle
    $(document).on('change', '#ae-feed-logo-watermark', function () {
        $('#ae-feed-logo-position-wrap').toggle($(this).is(':checked'));
    });

    // Save Feed (Add/Edit)
    $(document).on('click', '#ae-save-feed-btn', function () {
        const $btn = $(this);
        const feedId = $('#ae-feed-form-id').val();

        const data = {
            feed_url: $('#ae-feed-url').val(),
            feed_name: $('#ae-feed-name').val(),
            category_ids: (function() {
                // jQuery multiple select: null (none), string (one), array (multiple)
                // Hamesha array banana zaroori hai
                const v = $('#ae-feed-category').val();
                if (!v) return [];
                return Array.isArray(v) ? v : [v];
            })(),
            fetch_mode: $('#ae-feed-fetch-mode').val(),
            image_mode: $('input[name="ae_image_mode"]:checked').val() || 'featured_only',
            fetch_interval: $('#ae-feed-interval').val() || 10,
            author_id: $('#ae-feed-author').val() || 0,
            logo_watermark: $('#ae-feed-logo-watermark').is(':checked') ? 1 : 0,
            logo_position:  $('input[name="ae_logo_position"]:checked').val() || 'bottom-right',
            logo_opacity:   Number($('#ae-feed-logo-opacity').val()),
            logo_size:      Number($('#ae-feed-logo-size').val()),
            logo_no_margin: $('#ae-feed-logo-no-margin').is(':checked') ? 1 : 0,
            content_mode: $('input[name="ae_content_mode"]:checked').val() || 'direct',
        };

        if (!data.feed_url) {
            Toast.error('Please enter a feed URL.');
            return;
        }

        setLoading($btn, true);

        // Debug: console mein dekho kya ja raha hai
        console.log('[AE] Saving feed, category_ids:', data.category_ids);

        if (feedId) {
            data.feed_id = feedId;
            aeAjax('ae_update_feed', data, function (res) {
                setLoading($btn, false);
                if (res.success) {
                    Toast.success(res.data.message);
                    closeModal('ae-feed-modal');
                    loadFeeds();
                } else {
                    Toast.error(res.data.message);
                }
            });
        } else {
            aeAjax('ae_add_feed', data, function (res) {
                setLoading($btn, false);
                if (res.success) {
                    Toast.success(res.data.message);
                    closeModal('ae-feed-modal');
                    loadFeeds();
                } else {
                    Toast.error(res.data.message);
                }
            });
        }
    });

    // Edit Feed
    $(document).on('click', '.ae-feed-edit', function () {
        const feedId = $(this).data('id');

        aeAjax('ae_get_feeds', {}, function (res) {
            if (!res.success) return;
            const feed = res.data.feeds.find(f => f.id == feedId);
            if (!feed) return;

            $('#ae-feed-modal-title').text('Edit Feed');
            $('#ae-feed-form-id').val(feed.id);
            $('#ae-feed-url').val(feed.feed_url);
            $('#ae-feed-name').val(feed.feed_name);
            // Multiple categories — string array banana zaroori hai jQuery .val() ke liye
            console.log('[AE] Edit feed raw data:', feed.category_ids, 'category_id:', feed.category_id);
            const catIds = Array.isArray(feed.category_ids) && feed.category_ids.length > 0
                ? feed.category_ids.map(String)
                : (feed.category_id && feed.category_id != '0' ? [String(feed.category_id)] : []);
            console.log('[AE] catIds to select:', catIds);

            $('#ae-feed-fetch-mode').val(feed.fetch_mode);
            $('#ae-feed-interval').val(feed.fetch_interval || 10);
            $('#ae-feed-author').val(feed.author_id || 0);
            $(`input[name="ae_image_mode"][value="${feed.image_mode}"]`).prop('checked', true);

            // Content mode
            const cMode = feed.content_mode || 'direct';
            $(`input[name="ae_content_mode"][value="${cMode}"]`).prop('checked', true);

            // Per-feed logo watermark
            const logoOn = feed.logo_watermark == 1 || feed.logo_watermark === true;
            $('#ae-feed-logo-watermark').prop('checked', logoOn);
            $('#ae-feed-logo-position-wrap').toggle(logoOn);
            if (feed.logo_position) {
                $(`input[name="ae_logo_position"][value="${feed.logo_position}"]`).prop('checked', true);
            }
            // Opacity
            const opacity = feed.logo_opacity !== undefined ? feed.logo_opacity : 80;
            $('#ae-feed-logo-opacity').val(opacity);
            $('#ae-feed-opacity-val').text(opacity + '%');
            // Size
            const size = feed.logo_size !== undefined ? feed.logo_size : 20;
            $('#ae-feed-logo-size').val(size);
            $('#ae-feed-size-val').text(size + '%');
            // No margin
            $('#ae-feed-logo-no-margin').prop('checked', feed.logo_no_margin == 1);

            openModal('ae-feed-modal');

            // Vanilla JS se har option ko manually selected karo — most reliable approach
            const selectEl = document.getElementById('ae-feed-category');
            if (selectEl) {
                for (let i = 0; i < selectEl.options.length; i++) {
                    selectEl.options[i].selected = catIds.indexOf(selectEl.options[i].value) !== -1;
                }
            }
        });
    });

    // Delete Feed
    $(document).on('click', '.ae-feed-delete', function () {
        if (!confirm(aeAdmin.strings.confirm_delete)) return;

        const feedId = $(this).data('id');
        aeAjax('ae_delete_feed', { feed_id: feedId }, function (res) {
            if (res.success) {
                Toast.success(res.data.message);
                loadFeeds();
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    // Toggle Feed (inline switch)
    $(document).on('change', '.ae-feed-toggle-input', function () {
        const $input   = $(this);
        const feedId   = $input.data('id');
        const $label   = $input.closest('.ae-feed-toggle-switch');
        const $slider  = $label.find('.ae-toggle-slider');
        const $lbl     = $label.find('.ae-toggle-label');

        // Optimistically flip; revert on error
        const nowActive = $input.is(':checked');

        $lbl.text(nowActive ? 'Active' : 'Inactive')
            .css('color', nowActive ? 'var(--ae-success)' : 'var(--ae-text-muted)');
        $label.attr('title', nowActive ? 'Click to Deactivate' : 'Click to Activate');

        aeAjax('ae_toggle_feed', { feed_id: feedId }, function (res) {
            if (res.success) {
                Toast.success(res.data.message);
                // Server bolta hai new_status — sync karo agar mismatch ho
                const serverActive = res.data.active == 1 || res.data.active === true;
                if (serverActive !== nowActive) {
                    $input.prop('checked', serverActive);
                    $lbl.text(serverActive ? 'Active' : 'Inactive')
                        .css('color', serverActive ? 'var(--ae-success)' : 'var(--ae-text-muted)');
                    $label.attr('title', serverActive ? 'Click to Deactivate' : 'Click to Activate');
                }
            } else {
                // Revert on failure
                $input.prop('checked', !nowActive);
                $lbl.text(!nowActive ? 'Active' : 'Inactive')
                    .css('color', !nowActive ? 'var(--ae-success)' : 'var(--ae-text-muted)');
                $label.attr('title', !nowActive ? 'Click to Deactivate' : 'Click to Activate');
                Toast.error(res.data.message || 'Toggle failed');
            }
        });
    });

    // Test Feed
    $(document).on('click', '.ae-feed-test, #ae-test-feed-btn', function () {
        const url = $(this).data('url') || $('#ae-feed-url').val();
        if (!url) {
            Toast.error('Please enter a feed URL.');
            return;
        }

        const $btn = $(this);
        setLoading($btn, true);

        $('#ae-test-results').html('<div style="text-align:center;padding:20px;color:var(--ae-text-muted)">Testing feed...</div>');

        aeAjax('ae_test_feed', { feed_url: url }, function (res) {
            setLoading($btn, false);

            if (res.success) {
                Toast.success(res.data.message);
                renderTestResults(res.data.items);
            } else {
                Toast.error(res.data.message);
                $('#ae-test-results').html(`<div style="text-align:center;padding:20px;color:var(--ae-error)">❌ ${escHtml(res.data.message)}</div>`);
            }
        });
    });

    function renderTestResults(items) {
        if (!items || !items.length) {
            $('#ae-test-results').html('<div class="ae-empty"><p>No items found.</p></div>');
            return;
        }

        let html = '<div class="ae-test-results">';
        items.forEach(function (item) {
            const img = item.image
                ? `<img src="${escAttr(item.image)}" class="ae-test-item-image" alt="" onerror="this.style.display='none'">`
                : '<div class="ae-test-item-image ae-no-image">📄</div>';

            html += `
                <div class="ae-test-item">
                    ${img}
                    <div class="ae-test-item-content">
                        <h4>${escHtml(item.title)}</h4>
                        <p>${escHtml(item.excerpt)}</p>
                        <span class="ae-test-date">${item.date || ''}</span>
                    </div>
                </div>
            `;
        });
        html += '</div>';

        $('#ae-test-results').html(html);
    }

    // Fetch Now (single feed)
    $(document).on('click', '.ae-feed-fetch', function () {
        const $btn = $(this);
        const feedId = $btn.data('id');
        setLoading($btn, true);

        aeAjax('ae_fetch_now', { feed_id: feedId }, function (res) {
            setLoading($btn, false);
            if (res.success) {
                Toast.success(res.data.message);
                loadFeeds();
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    // Fetch All Now
    $(document).on('click', '#ae-fetch-all-btn', function () {
        const $btn = $(this);
        setLoading($btn, true);

        aeAjax('ae_fetch_now', { feed_id: 0 }, function (res) {
            setLoading($btn, false);
            if (res.success) {
                Toast.success(res.data.message);
                if (typeof loadFeeds === 'function') loadFeeds();
                if (typeof loadDashboardStats === 'function') loadDashboardStats();
                if (typeof loadRecentActivity === 'function') loadRecentActivity();
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    function resetFeedForm() {
        $('#ae-feed-form-id').val('');
        $('#ae-feed-url').val('');
        $('#ae-feed-name').val('');
        $('#ae-feed-category').val([]);
        $('#ae-feed-fetch-mode').val('new_only');
        $('#ae-feed-interval').val(10);
        $('#ae-feed-author').val(0);
        $('input[name="ae_image_mode"][value="featured_only"]').prop('checked', true);
        $('input[name="ae_content_mode"][value="direct"]').prop('checked', true);
        $('#ae-feed-logo-watermark').prop('checked', false);
        $('#ae-feed-logo-position-wrap').hide();
        $('input[name="ae_logo_position"][value="bottom-right"]').prop('checked', true);
        $('#ae-feed-logo-opacity').val(80); $('#ae-feed-opacity-val').text('80%');
        $('#ae-feed-logo-size').val(20);    $('#ae-feed-size-val').text('20%');
        $('#ae-feed-logo-no-margin').prop('checked', false);
        $('#ae-test-results').html('');
    }

    // ─── Settings ───
    $(document).on('click', '#ae-save-settings-btn', function () {
        const $btn = $(this);
        setLoading($btn, true);

        const data = {
            // General
            post_status: $('#ae-post-status').val(),
            min_word_count: $('#ae-min-word-count').val(),
            scrape_short_content: $('#ae-scrape-short-content').is(':checked') ? 1 : 0,
            scrape_min_word_count: $('#ae-scrape-min-word-count').val(),
            max_content_age_hours: $('#ae-max-content-age-hours').val(),
            shuffle_recent_items: $('#ae-shuffle-recent-items').is(':checked') ? 1 : 0,
            shuffle_pool_size: $('#ae-shuffle-pool-size').val(),
            rate_limit_hour: $('#ae-rate-limit-hour').val(),
            rate_limit_day: $('#ae-rate-limit-day').val(),

            // AI
            ai_enabled: $('#ae-ai-enabled').is(':checked') ? 1 : 0,
            ai_provider: $('input[name="ae_ai_provider"]:checked').val() || 'openai',
            ai_api_key: $('#ae-ai-api-key').val(),
            ai_model: $('#ae-ai-model').val(),
            ai_rewrite_title: $('#ae-ai-rewrite-title').is(':checked') ? 1 : 0,
            ai_rewrite_content: $('#ae-ai-rewrite-content').is(':checked') ? 1 : 0,
            ai_custom_prompt: $('#ae-ai-custom-prompt').val(),

            // Image
            image_insert: $('#ae-image-insert').is(':checked') ? 1 : 0,
            image_position: $('#ae-image-position').val(),

            // Watermark
            watermark_enabled: $('#ae-watermark-enabled').is(':checked') ? 1 : 0,
            watermark_image: $('#ae-watermark-image-id').val(),
            watermark_position: $('.ae-position-cell.ae-selected').data('position') || 'bottom-right',
            watermark_opacity: $('#ae-watermark-opacity').val(),
            watermark_size: $('#ae-watermark-size').val(),
            watermark_no_margin: $('#ae-watermark-no-margin').is(':checked') ? 1 : 0,

            // Text Watermark
            text_watermark_enabled: $('#ae-text-watermark-enabled').is(':checked') ? 1 : 0,
            twm_bold_text: $('#ae-twm-bold-text').val(),
            twm_random_text: $('#ae-twm-random-text').val(),

            // Find & Replace
            find_replace_rules: JSON.stringify(collectFindReplaceRules()),

            // Title Filter Keywords
            title_filter_keywords: $('#ae-title-filter-keywords').val(),

            // Auto Fetch Schedule — interval mode
            auto_fetch_enabled: $('#ae-auto-fetch-enabled').is(':checked') ? 1 : 0,
            fetch_interval_minutes: parseInt($('#ae-fetch-interval-minutes').val()) || 30,

            // Title Symbol / ZWC
            title_symbol: $('#ae-title-symbol').val(),
            title_symbol_type: $('#ae-title-symbol-type').val(),
            title_symbol_position: $('input[name="title_symbol_position"]:checked').val() || 'none',

            // Time Slots
            max_posts_per_cycle: $('#ae-max-posts-per-cycle').val(),
            time_slots: JSON.stringify(collectTimeSlots()),
        };

        aeAjax('ae_save_settings', data, function (res) {
            setLoading($btn, false);
            if (res.success) {
                Toast.success(res.data.message);
                // Server se confirmed saved values ke saath toggle sync karo
                if (typeof res.data.auto_fetch_enabled !== 'undefined') {
                    const savedVal = parseInt(res.data.auto_fetch_enabled) === 1;
                    $('#ae-auto-fetch-enabled').prop('checked', savedVal);
                    $('#ae-auto-fetch-status-on').toggle(savedVal);
                    $('#ae-auto-fetch-status-off').toggle(!savedVal);
                    $('#ae-fetch-countdown-box').toggle(savedVal);
                    $('#ae-fetch-interval-info').toggle(savedVal);
                    if (window.aeAdmin && window.aeAdmin.settings) {
                        window.aeAdmin.settings.auto_fetch_enabled = res.data.auto_fetch_enabled;
                    }
                    // Update hidden ts if server sent fresh value
                    if (res.data.last_fetch_ts) {
                        $('#ae-last-fetch-ts').val(res.data.last_fetch_ts);
                    }
                    // Update interval status text
                    const intervalMin = parseInt($('#ae-fetch-interval-minutes').val()) || 30;
                    $('#ae-fetch-interval-status').text('Har ' + intervalMin + ' minute baad saari feeds fetch hongi.');
                    // Restart countdown
                    if (savedVal) startFetchCountdown();
                }
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    // AI toggle visibility
    $(document).on('change', '#ae-ai-enabled', function () {
        $('#ae-ai-options').toggle($(this).is(':checked'));
    });

    // AI Provider switch — model list dynamically update karo
    $(document).on('change', 'input[name="ae_ai_provider"]', function () {
        const provider = $(this).val();
        const $model   = $('#ae-ai-model');
        const $keyLbl  = $('#ae-api-key-label');
        const $keyInp  = $('#ae-ai-api-key');
        const $hint    = $('#ae-model-hint');

        if ( provider === 'anthropic' ) {
            $keyLbl.html('Anthropic (Claude) API Key <span class="ae-required">*</span>');
            $keyInp.attr('placeholder', 'sk-ant-...');
            $hint.text('Claude Haiku sabse fast aur sasta hai translate ke liye.');
            $model.html(`
                <option value="claude-haiku-4-5-20251001">Claude Haiku (fastest, cheapest)</option>
                <option value="claude-sonnet-4-6">Claude Sonnet 4.6 (balanced)</option>
                <option value="claude-opus-4-6">Claude Opus 4.6 (best quality)</option>
            `);
        } else {
            $keyLbl.html('OpenAI API Key <span class="ae-required">*</span>');
            $keyInp.attr('placeholder', 'sk-...');
            $hint.text('GPT-3.5 Turbo recommended for bulk translate tasks.');
            $model.html(`
                <option value="gpt-3.5-turbo">GPT-3.5 Turbo (faster, cheaper)</option>
                <option value="gpt-4">GPT-4 (better quality)</option>
                <option value="gpt-4-turbo">GPT-4 Turbo</option>
                <option value="gpt-4o">GPT-4o</option>
                <option value="gpt-4o-mini">GPT-4o Mini</option>
            `);
        }
    });

    // Watermark toggle visibility
    $(document).on('change', '#ae-watermark-enabled', function () {
        $('#ae-watermark-options').toggle($(this).is(':checked'));
    });

    // Text Watermark toggle
    $(document).on('change', '#ae-text-watermark-enabled', function () {
        $('#ae-text-watermark-options').toggle($(this).is(':checked'));
    });

    // Text Watermark live preview
    $(document).on('input', '#ae-twm-bold-text', function () {
        $('#ae-preview-bold').text($(this).val() || 'Bold heading text...');
    });
    $(document).on('input', '#ae-twm-random-text', function () {
        $('#ae-preview-random').text($(this).val() || 'Random watermark text...');
    });

    // Watermark position grid
    $(document).on('click', '.ae-position-cell', function () {
        $('.ae-position-cell').removeClass('ae-selected');
        $(this).addClass('ae-selected');
    });

    // Watermark image upload
    $(document).on('click', '#ae-upload-watermark', function (e) {
        e.preventDefault();

        const frame = wp.media({
            title: 'Select Watermark Logo',
            button: { text: 'Use this image' },
            multiple: false,
            library: { type: 'image' },
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            $('#ae-watermark-image-id').val(attachment.id);
            $('#ae-watermark-preview').html(`<img src="${attachment.url}" alt="Watermark">`);
        });

        frame.open();
    });

    // Range slider value display
    $(document).on('input', '#ae-watermark-opacity', function () {
        $('#ae-opacity-value').text($(this).val() + '%');
    });

    $(document).on('input', '#ae-watermark-size', function () {
        $('#ae-size-value').text($(this).val() + '%');
    });

    // Test AI connection
    $(document).on('click', '#ae-test-ai-btn', function () {
        const $btn = $(this);
        setLoading($btn, true);

        aeAjax('ae_test_ai', {}, function (res) {
            setLoading($btn, false);
            if (res.success) {
                Toast.success(res.data.message);
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    // ─── Find & Replace ───
    // Build one rule row HTML — used by both +Add Rule and page-load init
    function buildFrRuleHtml(rule) {
        rule = rule || {};
        var type    = rule.type    || 'normal';
        var find    = escHtml(rule.find    || '');
        var replace = escHtml(rule.replace || '');
        var target  = rule.target  || 'both';
        var special = ['remove_brackets','remove_curly','remove_square'].indexOf(type) !== -1;
        var dim     = special ? 'opacity:0.3;pointer-events:none;' : '';
        function opt(val, label) {
            return '<option value="'+val+'"'+(type===val?' selected':'')+'>'+label+'</option>';
        }
        function topt(val, label) {
            return '<option value="'+val+'"'+(target===val?' selected':'')+'>'+label+'</option>';
        }
        return '<div class="ae-fr-rule">'
            +'<div class="ae-form-row" style="grid-template-columns:auto 1fr 1fr auto auto;gap:10px;align-items:end;margin-bottom:12px;">'
                +'<div class="ae-form-group" style="margin-bottom:0;">'
                    +'<label class="ae-form-label">Rule Type</label>'
                    +'<select class="ae-form-select ae-fr-type" style="min-width:160px;" onchange="aeFrTypeChange(this)">'
                        +opt('normal',          'Find & Replace')
                        +opt('remove_brackets', 'Remove () Brackets')
                        +opt('remove_curly',    'Remove {} Brackets')
                        +opt('remove_square',   'Remove [] Brackets')
                    +'</select>'
                +'</div>'
                +'<div class="ae-form-group ae-fr-find-wrap" style="margin-bottom:0;'+dim+'">'
                    +'<label class="ae-form-label">Find</label>'
                    +'<input type="text" class="ae-form-input ae-fr-find" value="'+find+'" placeholder="Text to find">'
                +'</div>'
                +'<div class="ae-form-group ae-fr-replace-wrap" style="margin-bottom:0;'+dim+'">'
                    +'<label class="ae-form-label">Replace With</label>'
                    +'<input type="text" class="ae-form-input ae-fr-replace" value="'+replace+'" placeholder="Replace with (empty = delete)">'
                +'</div>'
                +'<div class="ae-form-group" style="margin-bottom:0;">'
                    +'<label class="ae-form-label">Apply To</label>'
                    +'<select class="ae-form-select ae-fr-target" style="min-width:120px;">'
                        +topt('both','Both')
                        +topt('title','Title Only')
                        +topt('content','Content Only')
                    +'</select>'
                +'</div>'
                +'<button class="ae-btn ae-btn-danger ae-btn-sm ae-remove-rule" style="margin-bottom:0;height:40px;">&#x1F5D1;</button>'
            +'</div>'
        +'</div>';
    }

    window.aeFrTypeChange = function(el) {
        var $rule = $(el).closest('.ae-fr-rule');
        var special = ['remove_brackets','remove_curly','remove_square'].indexOf($(el).val()) !== -1;
        $rule.find('.ae-fr-find-wrap, .ae-fr-replace-wrap').css({
            'opacity': special ? '0.3' : '1',
            'pointer-events': special ? 'none' : ''
        });
    };

    function collectFindReplaceRules() {
        var rules = [];
        $('.ae-fr-rule').each(function () {
            var type    = $(this).find('.ae-fr-type').val() || 'normal';
            var find    = $(this).find('.ae-fr-find').val();
            var replace = $(this).find('.ae-fr-replace').val();
            var target  = $(this).find('.ae-fr-target').val();
            var special = ['remove_brackets','remove_curly','remove_square'].indexOf(type) !== -1;
            if (!special && !find) return;
            rules.push({ type: type, find: find || '', replace: replace || '', target: target || 'both' });
        });
        return rules;
    }

    // ─── Auto Fetch Schedule (Interval Mode) ─────────────────────────────────

    let _countdownTimer = null;

    function startFetchCountdown() {
        if (_countdownTimer) clearInterval(_countdownTimer);

        const $box     = $('#ae-fetch-countdown-box');
        const $display = $('#ae-fetch-countdown');
        const $enabled = $('#ae-auto-fetch-enabled');

        function tick() {
            if (!$enabled.is(':checked')) {
                $box.hide();
                return;
            }
            $box.css('display', 'flex');

            const intervalMin = parseInt($('#ae-fetch-interval-minutes').val()) || 30;
            const lastFetchTs = parseInt($('#ae-last-fetch-ts').val()) || 0;
            const nowTs       = Math.floor(Date.now() / 1000);

            let remaining;
            if (lastFetchTs === 0) {
                // Pehli baar — next fetch upcoming hai, cron hit hone tak wait
                remaining = intervalMin * 60;
            } else {
                const nextFetchTs = lastFetchTs + (intervalMin * 60);
                remaining = nextFetchTs - nowTs;
            }

            if (remaining <= 0) {
                $display.text('Abhi!');
            } else {
                const mins = Math.floor(remaining / 60);
                const secs = remaining % 60;
                $display.text(
                    String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0')
                );
            }
        }

        tick();
        _countdownTimer = setInterval(tick, 1000);
    }

    $(document).on('change', '#ae-auto-fetch-enabled', function () {
        const enabled = $(this).is(':checked');
        $('#ae-auto-fetch-status-on').toggle(enabled);
        $('#ae-auto-fetch-status-off').toggle(!enabled);
        $('#ae-fetch-countdown-box').toggle(enabled);
        $('#ae-fetch-interval-info').toggle(enabled);
        if (enabled) startFetchCountdown();
        else { if (_countdownTimer) clearInterval(_countdownTimer); }
    });

    $(document).on('change', '#ae-fetch-interval-minutes', function () {
        const min = parseInt($(this).val()) || 30;
        const enabled = $('#ae-auto-fetch-enabled').is(':checked');
        if (enabled) {
            $('#ae-fetch-interval-status').text('Har ' + min + ' minute baad saari feeds fetch hongi.');
            startFetchCountdown();
        }
    });

    // Init countdown on load if enabled — use server-provided last fetch ts
    if (typeof aeAdmin !== 'undefined' && aeAdmin.last_bulk_fetch_ts) {
        $('#ae-last-fetch-ts').val(aeAdmin.last_bulk_fetch_ts);
    }
    if ($('#ae-auto-fetch-enabled').is(':checked')) {
        startFetchCountdown();
    }

    // ─── Title Symbol / ZWC ──────────────────────────────────────────────────

    const ZWC_CHAR = '\u200B';

    function getSelectedSymbol() {
        const type = $('#ae-title-symbol-type').val();
        if (type === 'zwc')    return ZWC_CHAR;
        if (type === 'custom') return $('#ae-custom-symbol-input').val();
        return $('#ae-title-symbol').val();
    }

    function updateSymbolPreview() {
        const type     = $('#ae-title-symbol-type').val();
        const sym      = getSelectedSymbol();
        const position = $('input[name="title_symbol_position"]:checked').val() || 'none';
        const sample   = 'Breaking: India GDP Grows 8%';

        // For ZWC show label, else show actual char
        const displaySym = (type === 'zwc') ? '(ZWC)' : sym;

        let preview = '';
        if (position === 'prefix')      preview = displaySym + sample;
        else if (position === 'suffix') preview = sample + displaySym;
        else if (position === 'both')   preview = displaySym + sample + displaySym;
        else                            preview = sample + ' (symbol off)';

        $('#ae-symbol-preview').text(preview);
    }

    $(document).on('click', '.ae-symbol-btn', function () {
        const type = $(this).data('symbol-type');
        const val  = $(this).data('symbol-value');

        // Update button active state
        $('.ae-symbol-btn').removeClass('ae-btn-primary').addClass('ae-btn-secondary');
        $(this).removeClass('ae-btn-secondary').addClass('ae-btn-primary');

        // Update hidden fields
        $('#ae-title-symbol-type').val(type);

        if (type === 'zwc') {
            $('#ae-title-symbol').val(ZWC_CHAR);
            $('#ae-custom-symbol-wrap').hide();
        } else if (type === 'custom') {
            $('#ae-custom-symbol-wrap').show();
            $('#ae-title-symbol').val($('#ae-custom-symbol-input').val());
        } else {
            $('#ae-title-symbol').val(val);
            $('#ae-custom-symbol-wrap').hide();
        }

        updateSymbolPreview();
    });

    $(document).on('input', '#ae-custom-symbol-input', function () {
        $('#ae-title-symbol').val($(this).val());
        updateSymbolPreview();
    });

    $(document).on('change', 'input[name="title_symbol_position"]', function () {
        updateSymbolPreview();
    });

    // Init preview on load
    updateSymbolPreview();

    // ─── Time Slots ──────────────────────────────────────────────────────────

    function collectTimeSlots() {
        const slots = [];
        $('.ae-time-slot-row').each(function () {
            const start = $(this).find('.ae-slot-start').val();
            const end   = $(this).find('.ae-slot-end').val();
            if (start && end) {
                slots.push({ start: start, end: end });
            }
        });
        return slots;
    }

    function updateSlotsPreview() {
        const slots = collectTimeSlots();
        const $preview = $('#ae-slots-preview');
        if (slots.length === 0) {
            $preview.hide();
            return;
        }
        const text = slots.map(function (s) {
            return `<strong>${s.start}</strong> → <strong>${s.end}</strong>`;
        }).join(' &nbsp;|&nbsp; ');
        $('#ae-slots-preview-text').html(text);
        $preview.show();
    }

    function addSlotRow(start, end) {
        const idx = $('.ae-time-slot-row').length;
        const html = `
            <div class="ae-time-slot-row" style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
                <label style="font-size:13px;color:var(--ae-text-secondary);min-width:40px;">Start</label>
                <input type="time" class="ae-form-input ae-slot-start" value="${start || ''}"
                    style="width:140px;" data-index="${idx}">
                <label style="font-size:13px;color:var(--ae-text-secondary);min-width:30px;">End</label>
                <input type="time" class="ae-form-input ae-slot-end" value="${end || ''}"
                    style="width:140px;" data-index="${idx}">
                <button type="button" class="ae-btn ae-btn-danger ae-remove-slot"
                    style="padding:4px 10px;font-size:12px;">✕ Remove</button>
            </div>`;
        $('#ae-time-slots-container').append(html);
        updateSlotsPreview();
    }

    $(document).on('click', '#ae-add-slot-btn', function () {
        addSlotRow('', '');
    });

    $(document).on('click', '.ae-remove-slot', function () {
        $(this).closest('.ae-time-slot-row').remove();
        updateSlotsPreview();
    });

    $(document).on('change', '.ae-slot-start, .ae-slot-end', function () {
        updateSlotsPreview();
    });

    // ─────────────────────────────────────────────────────────────────────────

    $(document).on('click', '#ae-add-rule-btn', function () {
        $('#ae-no-rules').hide();
        $('#ae-find-replace-rules').append(buildFrRuleHtml({}));
    });

    $(document).on('click', '.ae-remove-rule', function () {
        $(this).closest('.ae-fr-rule').remove();
        if ($('.ae-fr-rule').length === 0) {
            $('#ae-no-rules').show();
        }
    });

    // ─── Logs ───
    let currentLogPage = 1;

    function loadLogs(page) {
        page = page || 1;
        currentLogPage = page;

        const data = {
            log_type: $('#ae-log-type-filter').val() || '',
            feed_id:  $('#ae-log-feed-filter').val() || 0,
            search:   $('#ae-log-search').val() || '',
            per_page: 50,
            page: page,
        };

        aeAjax('ae_get_logs', data, function (res) {
            if (!res.success) return;

            const logs  = res.data.logs;
            const total = res.data.total;
            const $body = $('#ae-logs-body');

            // Populate feed dropdown on first load
            if (res.data.feeds && res.data.feeds.length) {
                const $feedFilter = $('#ae-log-feed-filter');
                if ($feedFilter.find('option').length <= 1) {
                    res.data.feeds.forEach(function (f) {
                        $feedFilter.append('<option value="' + f.id + '">' + escHtml(f.name) + '</option>');
                    });
                }
            }

            if (!logs.length) {
                $body.html('<div class="ae-empty"><div class="ae-empty-icon">📋</div><h3>No logs found</h3><p>Activity will appear here once feeds are processed.</p></div>');
                $('#ae-logs-pagination').html('');
                return;
            }

            let html = '';
            logs.forEach(function (log) {
                const time = new Date(log.created_at).toLocaleString();

                // Feed badge — show feed name if available
                let feedBadge = '';
                if (log.feed_name) {
                    feedBadge = '<span class="ae-badge ae-badge-info ae-btn-sm ae-feed-badge" title="' + escHtml(log.feed_url || '') + '">📡 ' + escHtml(log.feed_name) + '</span>';
                } else if (parseInt(log.feed_id) > 0) {
                    feedBadge = '<span class="ae-badge ae-btn-sm" style="opacity:.5;">Feed #' + log.feed_id + '</span>';
                }

                // Post link — extract post ID from publish messages like "... (ID: 123, ...)"
                let msgHtml = escHtml(log.message);
                if (log.log_type === 'publish') {
                    const idMatch = log.message.match(/\(ID:\s*(\d+)/);
                    if (idMatch) {
                        const postId   = idMatch[1];
                        const adminBase = (typeof aeAdmin !== 'undefined' && aeAdmin.admin_url) ? aeAdmin.admin_url : '/wp-admin/';
                        const editUrl  = adminBase + 'post.php?post=' + postId + '&action=edit';
                        const siteBase = (typeof aeAdmin !== 'undefined' && aeAdmin.site_url) ? aeAdmin.site_url : '';
                        const viewUrl  = siteBase + '/?p=' + postId;
                        msgHtml += ' <span class="ae-log-post-links"><a href="' + editUrl + '" target="_blank">✏️ Edit</a> <a href="' + viewUrl + '" target="_blank">👁 View</a></span>';
                    }
                }

                html += '<div class="ae-log-entry">';
                html += '<span class="ae-log-time">' + time + '</span>';
                html += '<span class="ae-badge ae-badge-' + getLogBadgeType(log.log_type) + ' ae-btn-sm">' + log.log_type + '</span>';
                html += feedBadge;
                html += '<span class="ae-log-message">' + msgHtml + '</span>';
                html += '</div>';
            });

            $body.html(html);

            // Pagination
            const totalPages = Math.ceil(total / 50);
            renderPagination(totalPages, page);
        });
    }

    function renderPagination(totalPages, currentPage) {
        if (totalPages <= 1) {
            $('#ae-logs-pagination').html('');
            return;
        }

        let html = '';
        const maxVisible = 5;
        let start = Math.max(1, currentPage - Math.floor(maxVisible / 2));
        let end = Math.min(totalPages, start + maxVisible - 1);

        if (end - start < maxVisible - 1) {
            start = Math.max(1, end - maxVisible + 1);
        }

        if (currentPage > 1) {
            html += `<button class="ae-page-btn ae-log-page" data-page="${currentPage - 1}">‹</button>`;
        }

        for (let i = start; i <= end; i++) {
            html += `<button class="ae-page-btn ae-log-page ${i === currentPage ? 'ae-active' : ''}" data-page="${i}">${i}</button>`;
        }

        if (currentPage < totalPages) {
            html += `<button class="ae-page-btn ae-log-page" data-page="${currentPage + 1}">›</button>`;
        }

        html += `<span class="ae-page-info">Page ${currentPage} of ${totalPages}</span>`;

        $('#ae-logs-pagination').html(html);
    }

    $(document).on('click', '.ae-log-page', function () {
        loadLogs($(this).data('page'));
    });

    $(document).on('change', '#ae-log-type-filter, #ae-log-feed-filter', function () {

    // Search with debounce — 400ms
    var logSearchTimer;
    $(document).on('input', '#ae-log-search', function () {
        clearTimeout(logSearchTimer);
        logSearchTimer = setTimeout(function () { loadLogs(1); }, 400);
    });
        loadLogs(1);
    });

    $(document).on('click', '#ae-clear-logs-btn', function () {
        if (!confirm(aeAdmin.strings.confirm_clear)) return;

        aeAjax('ae_clear_logs', {}, function (res) {
            if (res.success) {
                Toast.success(res.data.message);
                loadLogs(1);
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    // ─── Reprocess Post ───
    $(document).on('click', '#ae-reprocess-btn', function () {
        const postId = $('#ae-reprocess-post-id').val();
        if (!postId) {
            Toast.error('Please enter a Post ID.');
            return;
        }

        const $btn = $(this);
        setLoading($btn, true);

        aeAjax('ae_reprocess_post', { post_id: postId }, function (res) {
            setLoading($btn, false);
            if (res.success) {
                Toast.success(res.data.message);
            } else {
                Toast.error(res.data.message);
            }
        });
    });

    // ─── Helper Functions ───
    function escHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function escAttr(str) {
        if (!str) return '';
        return str.replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function getLogBadgeType(type) {
        const map = {
            fetch: 'info',
            publish: 'success',
            error: 'error',
            duplicate: 'warning',
            ai: 'info',
            image: 'info',
            info: 'neutral',
        };
        return map[type] || 'neutral';
    }

    // ─── Initialize ───
    $(document).ready(function () {
        Toast.init();
        initTabs();
        initModals();

        // Populate category dropdown in feed modal
        const $catSelect = $('#ae-feed-category');
        if ($catSelect.length && aeAdmin.categories) {
            $catSelect.html('');
            aeAdmin.categories.forEach(function (cat) {
                $catSelect.append(`<option value="${cat.id}">${escHtml(cat.name)}</option>`);
            });
        }

        // Populate author dropdown in feed modal
        const $authorSelect = $('#ae-feed-author');
        if ($authorSelect.length && aeAdmin.authors) {
            $authorSelect.html('<option value="0">— Default (Admin) —</option>');
            aeAdmin.authors.forEach(function (author) {
                $authorSelect.append(`<option value="${author.id}">${escHtml(author.name)}</option>`);
            });
        }

        // Page-specific initialization
        const page = $('body').attr('class') || '';

        // Dashboard page
        if ($('#ae-dashboard-page').length) {
            loadDashboardStats();
            loadRecentActivity();
        }

        // Feeds page
        if ($('#ae-feeds-page').length) {
            loadFeeds();
        }

        // Logs page
        if ($('#ae-logs-page').length) {
            loadLogs(1);
        }

        // Settings page — initialize toggle visibility
        if ($('#ae-settings-page').length) {
            // Existing rules ko page load par JS se render karo
            var initRules = window._aeFrInitRules || [];
            if (initRules.length > 0) {
                $('#ae-no-rules').hide();
                initRules.forEach(function(rule) {
                    $('#ae-find-replace-rules').append(buildFrRuleHtml(rule));
                });
            } else {
                $('#ae-no-rules').show();
            }

            const s = aeAdmin.settings || {};

            // Set initial values
            if (s.ai_enabled) {
                $('#ae-ai-enabled').prop('checked', true);
                $('#ae-ai-options').show();
            }
            if (s.watermark_enabled) {
                $('#ae-watermark-enabled').prop('checked', true);
                $('#ae-watermark-options').show();
            }
            if (s.watermark_position) {
                $(`.ae-position-cell[data-position="${s.watermark_position}"]`).addClass('ae-selected');
            }

            // Range values
            $('#ae-opacity-value').text((s.watermark_opacity || 50) + '%');
            $('#ae-size-value').text((s.watermark_size || 20) + '%');

            // No-margin restore
            if (s.watermark_no_margin) {
                $('#ae-watermark-no-margin').prop('checked', true);
            }
            // Text Watermark restore
            if (s.text_watermark_enabled) {
                $('#ae-text-watermark-enabled').prop('checked', true);
                $('#ae-text-watermark-options').show();
            }
            if (s.twm_bold_text) {
                $('#ae-twm-bold-text').val(s.twm_bold_text);
                $('#ae-preview-bold').text(s.twm_bold_text);
            }
            if (s.twm_random_text) {
                $('#ae-twm-random-text').val(s.twm_random_text);
                $('#ae-preview-random').text(s.twm_random_text);
            }

            // Watermark image preview
            if (s.watermark_image) {
                // Fetch attachment URL
                const attachId = s.watermark_image;
                if (attachId && wp && wp.media && wp.media.attachment) {
                    const att = wp.media.attachment(attachId);
                    att.fetch().then(function () {
                        if (att.get('url')) {
                            $('#ae-watermark-preview').html(`<img src="${att.get('url')}" alt="Watermark">`);
                        }
                    });
                }
            }

            // Max posts per cycle
            if (typeof s.max_posts_per_cycle !== 'undefined') {
                $('#ae-max-posts-per-cycle').val(s.max_posts_per_cycle);
            }

            // Time slots — render saved slots and show preview
            if (s.time_slots && Array.isArray(s.time_slots) && s.time_slots.length > 0) {
                // Clear any PHP-rendered placeholders (page may already have them)
                // Only add via JS if container is empty (no PHP rows rendered)
                if ($('#ae-time-slots-container .ae-time-slot-row').length === 0) {
                    s.time_slots.forEach(function (slot) {
                        addSlotRow(slot.start || '', slot.end || '');
                    });
                }
            }
            updateSlotsPreview();
        }

        // ══════════════════════════════════════════
        // Cron Setup Tab
        // ══════════════════════════════════════════

        // Copy Key
        $('#ae-copy-key-btn').on('click', function () {
            const val = $('#ae-cron-key-display').val();
            if (val) { navigator.clipboard.writeText(val); Toast.show('🔑 Key copied!', 'success'); }
        });

        // Copy URL
        $('#ae-copy-url-btn').on('click', function () {
            const val = $('#ae-trigger-url').val();
            if (val) { navigator.clipboard.writeText(val); Toast.show('🔗 URL copied!', 'success'); }
        });

        // Copy Command
        $('#ae-copy-cmd-btn').on('click', function () {
            const val = $('#ae-cron-command').text();
            if (val) { navigator.clipboard.writeText(val); Toast.show('📋 Command copied!', 'success'); }
        });

        // Generate New Key
        $('#ae-generate-key-btn').on('click', function () {
            if (!confirm('Purani key invalid ho jaayegi. Naya cron command update karna hoga. Continue?')) return;
            aeAjax('ae_generate_cron_key', {}, function (res) {
                if (!res.success) return Toast.show('Error generating key', 'error');
                $('#ae-cron-key-display').val(res.data.key);
                $('#ae-trigger-url').val(res.data.trigger_url);
                $('#ae-cron-command').text('curl -s "' + res.data.trigger_url + '" > /dev/null');
                Toast.show('🔑 Naya key generate hua! Cron command update karo.', 'success');
            });
        });

        // Save Cron Settings
        $('#ae-save-cron-btn').on('click', function () {
            const $btn = $(this);
            $btn.find('.ae-btn-text').text('Saving...');
            $btn.prop('disabled', true);

            const interval = $('#ae-cron-interval').val() || 2;

            aeAjax('ae_save_cron_settings', { cron_interval: interval }, function (res) {
                $btn.find('.ae-btn-text').text('💾 Save Cron Settings');
                $btn.prop('disabled', false);

                if (!res.success) return Toast.show('Save failed', 'error');

                $('#ae-cron-key-display').val(res.data.key);
                $('#ae-trigger-url').val(res.data.trigger_url);
                $('#ae-cron-command').text('curl -s "' + res.data.trigger_url + '" > /dev/null');
                $('#ae-cron-schedule').text(res.data.schedule);

                Toast.show('✅ Cron settings saved!', 'success');
            });
        });

        // Test Cron
        $('#ae-test-cron-btn').on('click', function () {
            const $btn = $(this);
            const $result = $('#ae-cron-test-result');
            $btn.find('.ae-btn-text').text('Running...');
            $btn.prop('disabled', true);
            $result.hide();

            aeAjax('ae_test_cron', {}, function (res) {
                $btn.find('.ae-btn-text').text('▶ Run Cron Now');
                $btn.prop('disabled', false);

                if (!res.success) {
                    $result.show().css({ background: '#fdecea', border: '1px solid #f5c6cb', color: '#721c24' })
                        .text('❌ Error: ' + (res.data?.message || 'Unknown error'));
                    return;
                }

                const isSkipped = res.data.status === 'skipped';
                $result.show()
                    .css({
                        background: isSkipped ? '#fff3cd' : '#d4edda',
                        border: '1px solid ' + (isSkipped ? '#ffc107' : '#c3e6cb'),
                        color: isSkipped ? '#856404' : '#155724'
                    })
                    .text(res.data.message);
            });
        });

        // ─── Export / Import Feeds (sirf feeds page pe) ───
        if ($('#ae-feeds-page').length) {

        var aeImportFeeds = [];

        $('#ae-export-feeds-btn').on('click', function () {
            const $btn = $(this);
            $btn.prop('disabled', true).text('⏳ Exporting...');

            aeAjax('ae_export_feeds', {}, function (res) {
                $btn.prop('disabled', false).html('📤 Export Feeds');
                if (!res.success) {
                    Toast.error(res.data.message || 'Export failed.');
                    return;
                }
                const exportData = res.data;
                const json = JSON.stringify(exportData, null, 2);
                const blob = new Blob([json], { type: 'application/json' });
                const url  = URL.createObjectURL(blob);
                const a    = document.createElement('a');
                const siteName = (exportData.site_name || 'site').replace(/[^a-z0-9]/gi, '-').toLowerCase();
                a.href     = url;
                a.download = 'ae-feeds-' + siteName + '.json';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                Toast.success(exportData.count + ' feeds export ho gayi!');
            });
        });

        $('#ae-import-feeds-btn').on('click', function () {
            aeImportFeeds = [];
            $('#ae-import-json').val('');
            $('#ae-import-step1-error').hide().text('');
            $('#ae-import-step-1').show();
            $('#ae-import-step-2').hide();
            $('#ae-import-next-btn').show();
            $('#ae-import-back-btn').hide();
            $('#ae-import-submit-btn').hide();
            openModal('ae-import-modal');
        });

        $('#ae-import-cancel-btn').on('click', function () {
            closeModal('ae-import-modal');
        });

        $('#ae-import-back-btn').on('click', function () {
            $('#ae-import-step-2').hide();
            $('#ae-import-step-1').show();
            $('#ae-import-next-btn').show();
            $('#ae-import-back-btn').hide();
            $('#ae-import-submit-btn').hide();
        });

        $('#ae-import-next-btn').on('click', function () {
            var raw = $('#ae-import-json').val().trim();
            if (!raw) {
                $('#ae-import-step1-error').text('JSON paste karo pehle.').show();
                return;
            }
            var parsed;
            try { parsed = JSON.parse(raw); }
            catch(e) {
                $('#ae-import-step1-error').text('Invalid JSON: ' + e.message).show();
                return;
            }
            if (!parsed.feeds || !Array.isArray(parsed.feeds) || parsed.feeds.length === 0) {
                $('#ae-import-step1-error').text('JSON mein "feeds" array nahi mila ya empty hai.').show();
                return;
            }
            $('#ae-import-step1-error').hide();
            aeImportFeeds = parsed.feeds;

            var catOptions = '<option value="">— Skip (No Category) —</option>';
            (aeAdmin.categories || []).forEach(function(cat) {
                catOptions += '<option value="' + cat.id + '">' + escHtml(cat.name) + '</option>';
            });

            var html = '<table style="width:100%;border-collapse:collapse;"><thead><tr>'
                + '<th style="text-align:left;padding:8px 10px;font-size:12px;color:var(--ae-text-muted);border-bottom:1px solid var(--ae-border);">Feed Name / URL</th>'
                + '<th style="text-align:left;padding:8px 10px;font-size:12px;color:var(--ae-text-muted);border-bottom:1px solid var(--ae-border);">Original Categories</th>'
                + '<th style="text-align:left;padding:8px 10px;font-size:12px;color:var(--ae-text-muted);border-bottom:1px solid var(--ae-border);">Is Site Ki Category</th>'
                + '</tr></thead><tbody>';

            aeImportFeeds.forEach(function(feed, i) {
                var origCats = (feed.original_category_names || []).join(', ') || '—';
                var feedLabel = feed.feed_name ? escHtml(feed.feed_name) : escHtml(feed.feed_url);
                var autoMatch = '';
                (aeAdmin.categories || []).forEach(function(cat) {
                    (feed.original_category_names || []).forEach(function(oName) {
                        if (cat.name.toLowerCase() === oName.toLowerCase()) autoMatch = cat.id;
                    });
                });
                html += '<tr style="border-bottom:1px solid var(--ae-border);">'
                    + '<td style="padding:10px;font-size:13px;max-width:200px;word-break:break-all;"><strong>' + feedLabel + '</strong><br>'
                    + '<span style="font-size:11px;color:var(--ae-text-muted);">' + escHtml(feed.feed_url) + '</span></td>'
                    + '<td style="padding:10px;font-size:12px;color:var(--ae-text-secondary);">' + escHtml(origCats) + '</td>'
                    + '<td style="padding:10px;"><select class="ae-form-select ae-import-cat-select" data-url="' + escAttr(feed.feed_url) + '" style="width:100%;font-size:12px;">' + catOptions + '</select></td>'
                    + '</tr>';
                if (autoMatch) {
                    setTimeout(function(idx, val) { $('.ae-import-cat-select').eq(idx).val(val); }.bind(null, i, autoMatch), 50);
                }
            });
            html += '</tbody></table>';
            $('#ae-import-mapping-table').html(html);
            $('#ae-import-step-1').hide();
            $('#ae-import-step-2').show();
            $('#ae-import-next-btn').hide();
            $('#ae-import-back-btn').show();
            $('#ae-import-submit-btn').show();
        });

        $('#ae-import-submit-btn').on('click', function () {
            var $btn = $(this);
            setLoading($btn, true);
            var catMapping = {};
            $('.ae-import-cat-select').each(function() {
                var url = $(this).data('url');
                var catId = $(this).val();
                if (url && catId) catMapping[url] = [parseInt(catId)];
            });
            aeAjax('ae_import_feeds', {
                feeds: JSON.stringify(aeImportFeeds),
                category_mapping: JSON.stringify(catMapping),
            }, function(res) {
                setLoading($btn, false);
                if (res.success) {
                    closeModal('ae-import-modal');
                    Toast.success(res.data.message);
                    loadFeeds();
                } else {
                    Toast.error(res.data.message || 'Import failed.');
                }
            });
        });

        } // end #ae-feeds-page

    });

})(jQuery);
