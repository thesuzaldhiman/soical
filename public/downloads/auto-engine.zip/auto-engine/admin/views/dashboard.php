<?php
/**
 * Dashboard view — main stats and activity overview.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="ae-wrap" id="ae-dashboard-page">

    <div class="ae-page-header">
        <h1>
            <span class="ae-logo-icon">⚡</span>
            Auto Engine
            <span class="ae-version">v<?php echo esc_html( AE_VERSION ); ?></span>
        </h1>
        <div class="ae-header-actions">
            <button class="ae-btn ae-btn-primary" id="ae-fetch-all-btn">
                <span class="ae-spinner"></span>
                <span class="ae-btn-text">⚡ Fetch All Now</span>
            </button>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="ae-stats-grid">
        <div class="ae-stat-card">
            <div class="ae-stat-icon ae-icon-feeds">📡</div>
            <div class="ae-stat-value" id="ae-stat-feeds">—</div>
            <div class="ae-stat-label">Total Feeds</div>
        </div>
        <div class="ae-stat-card">
            <div class="ae-stat-icon ae-icon-feeds">✅</div>
            <div class="ae-stat-value" id="ae-stat-active">—</div>
            <div class="ae-stat-label">Active Feeds</div>
        </div>
        <div class="ae-stat-card">
            <div class="ae-stat-icon ae-icon-posts">📝</div>
            <div class="ae-stat-value" id="ae-stat-posts">—</div>
            <div class="ae-stat-label">Posts Published</div>
        </div>
        <div class="ae-stat-card">
            <div class="ae-stat-icon ae-icon-errors">⚠️</div>
            <div class="ae-stat-value" id="ae-stat-errors">—</div>
            <div class="ae-stat-label">Errors</div>
        </div>
    </div>

    <!-- Status Cards Row -->
    <div class="ae-stats-grid" style="margin-bottom: 30px;">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>⏱ Cron Status</h3>
                <span id="ae-cron-status">—</span>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 14px; margin: 0;" id="ae-cron-next">—</p>
            </div>
        </div>
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🤖 AI Rewriting</h3>
                <span id="ae-ai-status">—</span>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 14px; margin: 0;">
                    <?php
                    $settings = get_option( 'auto_engine_settings', array() );
                    echo ! empty( $settings['ai_enabled'] )
                        ? esc_html__( 'Content will be rewritten via AI before publishing.', 'auto-engine' )
                        : esc_html__( 'Original cleaned content will be published.', 'auto-engine' );
                    ?>
                </p>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="ae-card">
        <div class="ae-card-header">
            <h3>🔧 Quick Actions</h3>
        </div>
        <div class="ae-card-body" style="display: flex; gap: 12px; flex-wrap: wrap;">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=auto-engine-feeds' ) ); ?>" class="ae-btn ae-btn-secondary">
                📡 Manage Feeds
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=auto-engine-settings' ) ); ?>" class="ae-btn ae-btn-secondary">
                ⚙️ Settings
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=auto-engine-logs' ) ); ?>" class="ae-btn ae-btn-secondary">
                📋 View Logs
            </a>
            <div style="flex: 1;"></div>
            <div style="display: flex; gap: 8px; align-items: center;">
                <input type="number" id="ae-reprocess-post-id" class="ae-form-input" placeholder="Post ID" style="width: 120px;">
                <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-reprocess-btn">
                    <span class="ae-spinner"></span>
                    <span class="ae-btn-text">🔄 Reprocess</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="ae-card">
        <div class="ae-card-header">
            <h3>📊 Recent Activity</h3>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=auto-engine-logs' ) ); ?>" class="ae-btn ae-btn-ghost ae-btn-sm">
                View All →
            </a>
        </div>
        <div class="ae-card-body" id="ae-recent-activity">
            <div class="ae-empty">
                <p>Loading activity...</p>
            </div>
        </div>
    </div>

</div>
