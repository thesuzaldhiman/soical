<?php
/**
 * Feed Manager view — add, edit, test, and manage RSS feeds.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="ae-wrap" id="ae-feeds-page">

    <div class="ae-page-header">
        <h1>
            <span class="ae-logo-icon">📡</span>
            Feed Manager
        </h1>
        <div class="ae-header-actions">
            <button class="ae-btn ae-btn-secondary" id="ae-fetch-all-btn">
                <span class="ae-spinner"></span>
                <span class="ae-btn-text">⚡ Fetch All</span>
            </button>
            <button class="ae-btn ae-btn-secondary" id="ae-import-feeds-btn">
                📥 Import Feeds
            </button>
            <button class="ae-btn ae-btn-secondary" id="ae-export-feeds-btn">
                <span class="ae-spinner"></span>
                <span class="ae-btn-text">📤 Export Feeds</span>
            </button>
            <button class="ae-btn ae-btn-primary" id="ae-add-feed-btn">
                <span class="ae-btn-text">+ Add Feed</span>
            </button>
        </div>
    </div>

    <!-- Feeds Table -->
    <div class="ae-card">
        <div class="ae-card-header">
            <h3>📋 Your Feeds</h3>
        </div>
        <div class="ae-table-wrap">
            <table class="ae-table">
                <thead>
                    <tr>
                        <th>Feed</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Mode</th>
                        <th>Images</th>
                        <th>📰 News</th>
                        <th>Last Fetched</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ae-feeds-table-body">
                    <tr>
                        <td colspan="8">
                            <div class="ae-empty">
                                <p>Loading feeds...</p>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Test Results -->
    <div class="ae-card" id="ae-test-results-card" style="display:none;">
        <div class="ae-card-header">
            <h3>🔍 Feed Test Results</h3>
            <button class="ae-btn ae-btn-ghost ae-btn-sm" onclick="document.getElementById('ae-test-results-card').style.display='none';">✕ Close</button>
        </div>
        <div class="ae-card-body" id="ae-test-results-global"></div>
    </div>

    <!-- Import Feeds Modal -->
    <div class="ae-modal-overlay" id="ae-import-modal">
        <div class="ae-modal" style="max-width:700px;">
            <div class="ae-modal-header">
                <h3>📥 Import Feeds</h3>
                <button class="ae-modal-close" data-modal="ae-import-modal">✕</button>
            </div>
            <div class="ae-modal-body">
                <div id="ae-import-step-1">
                    <div class="ae-form-group">
                        <label class="ae-form-label">Exported JSON Paste Karo</label>
                        <p class="ae-form-hint" style="margin-bottom:10px;">Doosri site se Export kiya hua JSON yahan paste karo, phir "Next" dabao.</p>
                        <textarea id="ae-import-json" class="ae-form-input" rows="10" style="font-family:monospace;font-size:12px;" placeholder='{"feeds":[...]}'></textarea>
                    </div>
                    <div id="ae-import-step1-error" style="color:var(--ae-danger);font-size:13px;display:none;margin-top:8px;"></div>
                </div>
                <div id="ae-import-step-2" style="display:none;">
                    <p style="margin-bottom:14px;font-size:13px;color:var(--ae-text-secondary);">
                        Har feed ke liye <strong>is site ki category</strong> select karo. Agar koi category nahi chahiye toh "— Skip —" choose karo.
                    </p>
                    <div id="ae-import-mapping-table" style="max-height:400px;overflow-y:auto;"></div>
                </div>
            </div>
            <div class="ae-modal-footer">
                <button class="ae-btn ae-btn-secondary" id="ae-import-cancel-btn">Cancel</button>
                <button class="ae-btn ae-btn-secondary" id="ae-import-back-btn" style="display:none;">← Back</button>
                <button class="ae-btn ae-btn-primary" id="ae-import-next-btn">Next →</button>
                <button class="ae-btn ae-btn-primary" id="ae-import-submit-btn" style="display:none;">
                    <span class="ae-spinner"></span>
                    <span class="ae-btn-text">📥 Import Feeds</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Feed Modal -->
    <div class="ae-modal-overlay" id="ae-feed-modal">
        <div class="ae-modal">
            <div class="ae-modal-header">
                <h3 id="ae-feed-modal-title">Add Feed</h3>
                <button class="ae-modal-close">✕</button>
            </div>
            <div class="ae-modal-body">
                <input type="hidden" id="ae-feed-form-id" value="">

                <div class="ae-form-group">
                    <label class="ae-form-label">Feed URL <span class="ae-required">*</span></label>
                    <div style="display: flex; gap: 10px;">
                        <input type="url" id="ae-feed-url" class="ae-form-input" placeholder="https://example.com/feed/" style="flex: 1;">
                        <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-test-feed-btn">
                            <span class="ae-spinner"></span>
                            <span class="ae-btn-text">🔍 Test</span>
                        </button>
                    </div>
                </div>

                <div class="ae-form-group">
                    <label class="ae-form-label">Feed Name</label>
                    <input type="text" id="ae-feed-name" class="ae-form-input" placeholder="e.g. TechCrunch News">
                    <p class="ae-form-hint">A display name for easy identification.</p>
                </div>

                <div class="ae-form-row">
                    <div class="ae-form-group">
                        <label class="ae-form-label">Categories <span style="color: var(--ae-text-muted); font-size: 12px;">(Ctrl/Cmd + click se multiple)</span></label>
                        <select id="ae-feed-category" class="ae-form-select" multiple style="height: 120px; resize: vertical;">
                        </select>
                    </div>

                    <div class="ae-form-group">
                        <label class="ae-form-label">Fetch Mode</label>
                        <select id="ae-feed-fetch-mode" class="ae-form-select">
                            <option value="new_only">Only New Posts (default)</option>
                            <option value="all">Fetch Old + New</option>
                        </select>
                    </div>
                </div>

                <div class="ae-form-group">
                    <label class="ae-form-label">🌐 Content Mode <span class="ae-required">*</span></label>
                    <div style="display: flex; flex-direction: column; gap: 10px; padding: 14px; background: var(--ae-bg-input); border-radius: var(--ae-radius-sm); border: 1px solid var(--ae-border);">
                        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;">
                            <input type="radio" name="ae_content_mode" value="direct" checked style="margin-top:3px;">
                            <span>
                                <strong>🇬🇧 Direct (English → English)</strong><br>
                                <span style="font-size:12px;color:var(--ae-text-muted);">English feed se content as-is publish hoga. Koi translate/rewrite nahi. (Recommended for English feeds)</span>
                            </span>
                        </label>
                        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;">
                            <input type="radio" name="ae_content_mode" value="translate" style="margin-top:3px;">
                            <span>
                                <strong>🔄 Translate (Hindi → English — Free)</strong><br>
                                <span style="font-size:12px;color:var(--ae-text-muted);">Hindi/regional feed ko Google Translate se English mein convert karo. Free hai, API key ki zaroorat nahi.</span>
                            </span>
                        </label>
                        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;">
                            <input type="radio" name="ae_content_mode" value="api_translate" style="margin-top:3px;">
                            <span>
                                <strong>🤖 API Translate (Claude / ChatGPT)</strong><br>
                                <span style="font-size:12px;color:var(--ae-text-muted);">Hindi ya English — dono ke liye AI API se high-quality translate + rewrite. Settings mein Claude ya ChatGPT API key configure karna hoga.</span>
                            </span>
                        </label>
                    </div>
                </div>

                <div class="ae-form-group">
                    <label class="ae-form-label">Image Control</label>
                    <div style="display: flex; flex-direction: column; gap: 12px; padding: 14px; background: var(--ae-bg-input); border-radius: var(--ae-radius-sm); border: 1px solid var(--ae-border);">
                        <label class="ae-toggle">
                            <input type="radio" name="ae_image_mode" value="featured_only" checked>
                            <span class="ae-toggle-slider"></span>
                            <span class="ae-toggle-label">
                                🖼 Fetch Only Featured Image <span style="color: var(--ae-text-muted); font-size: 12px;">(recommended)</span>
                            </span>
                        </label>
                        <label class="ae-toggle">
                            <input type="radio" name="ae_image_mode" value="all_images">
                            <span class="ae-toggle-slider"></span>
                            <span class="ae-toggle-label">
                                🖼 Fetch All Images
                            </span>
                        </label>
                    </div>
                </div>

                <div class="ae-form-group">
                    <label class="ae-form-label">🔖 Logo Watermark (Is Feed ke Liye)</label>
                    <div style="padding: 14px; background: var(--ae-bg-input); border-radius: var(--ae-radius-sm); border: 1px solid var(--ae-border);">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; margin-bottom: 12px;">
                            <input type="checkbox" id="ae-feed-logo-watermark" value="1" style="width:16px;height:16px;cursor:pointer;">
                            <span style="font-size:13px;">Is feed ki images pe Logo/Watermark lagao</span>
                        </label>
                        <div id="ae-feed-logo-position-wrap" style="display:none; margin-top:10px;">

                            <!-- POSITION -->
                            <label class="ae-form-label" style="font-size:12px; margin-bottom:6px;">📍 Logo Position</label>
                            <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:14px;">
                                <?php
                                $positions = array(
                                    'top-left'     => '↖ Top Left',
                                    'top-right'    => '↗ Top Right',
                                    'bottom-left'  => '↙ Bottom Left',
                                    'bottom-right' => '↘ Bottom Right',
                                    'center'       => '⊙ Center',
                                );
                                foreach ( $positions as $val => $lbl ) : ?>
                                    <label style="display:flex;align-items:center;gap:5px;font-size:12px;cursor:pointer;background:var(--ae-bg);padding:5px 10px;border-radius:4px;border:1px solid var(--ae-border);">
                                        <input type="radio" name="ae_logo_position" value="<?php echo esc_attr( $val ); ?>" <?php echo $val === 'bottom-right' ? 'checked' : ''; ?>>
                                        <?php echo esc_html( $lbl ); ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>

                            <!-- OPACITY -->
                            <div style="margin-bottom:14px;">
                                <label class="ae-form-label" style="font-size:12px; margin-bottom:6px;">🔆 Opacity — <span id="ae-feed-opacity-val">80%</span></label>
                                <input type="range" id="ae-feed-logo-opacity" name="ae_logo_opacity"
                                    min="0" max="100" step="5" value="80"
                                    style="width:100%;"
                                    oninput="document.getElementById('ae-feed-opacity-val').textContent = this.value + '%'">
                            </div>

                            <!-- SIZE -->
                            <div style="margin-bottom:14px;">
                                <label class="ae-form-label" style="font-size:12px; margin-bottom:6px;">📐 Size (image width ka %) — <span id="ae-feed-size-val">20%</span></label>
                                <input type="range" id="ae-feed-logo-size" name="ae_logo_size"
                                    min="5" max="80" step="5" value="20"
                                    style="width:100%;"
                                    oninput="document.getElementById('ae-feed-size-val').textContent = this.value + '%'">
                            </div>

                            <!-- NO MARGIN -->
                            <div style="margin-bottom:10px;">
                                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:12px;">
                                    <input type="checkbox" id="ae-feed-logo-no-margin" name="ae_logo_no_margin" value="1" style="width:15px;height:15px;cursor:pointer;">
                                    <span>📌 Corner se bilkul touch karo (no margin)</span>
                                </label>
                                <p class="ae-form-hint" style="margin-top:3px;margin-left:23px;">Check karne pe logo edge se chipka lagega, unchecked = thoda margin rahega.</p>
                            </div>

                            <p class="ae-form-hint" style="margin-top:4px; background:#fef9c3; padding:6px 10px; border-radius:4px;">⚠️ Logo image <strong>Settings → Watermark</strong> mein upload karni hoti hai.</p>
                        </div>
                    </div>
                </div>

                <div class="ae-form-row">
                    <div class="ae-form-group">
                        <label class="ae-form-label">Fetch Interval (minutes)</label>
                        <input type="number" id="ae-feed-interval" class="ae-form-input" value="10" min="1" max="1440" step="1">
                        <p class="ae-form-hint">How often to check this feed for new posts.</p>
                    </div>

                    <div class="ae-form-group">
                        <label class="ae-form-label">Post Author</label>
                        <select id="ae-feed-author" class="ae-form-select">
                            <option value="0">— Default (Admin) —</option>
                        </select>
                        <p class="ae-form-hint">Which WordPress user the posts will be published as.</p>
                    </div>
                </div>

                <!-- Test Results inside Modal -->
                <div id="ae-test-results"></div>
            </div>

            <div class="ae-modal-footer">
                <button class="ae-btn ae-btn-secondary ae-modal-close">Cancel</button>
                <button class="ae-btn ae-btn-primary" id="ae-save-feed-btn">
                    <span class="ae-spinner"></span>
                    <span class="ae-btn-text">Save Feed</span>
                </button>
            </div>
        </div>
    </div>

</div>
