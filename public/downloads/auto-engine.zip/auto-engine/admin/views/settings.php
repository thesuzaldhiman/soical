<?php
/**
 * Settings view — tabbed settings for General, AI, Images, and Watermark.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$settings = get_option( 'auto_engine_settings', array() );
$bridge_key = get_option( 'ae_bridge_key', '' );
if ( empty( $bridge_key ) ) {
    $bridge_key = get_option( 'ae_direct_cron_key', '' );
}
$bridge_publish_url = home_url( '/wp-json/auto-engine/v1/publish' );
$bridge_status_url  = home_url( '/wp-json/auto-engine/v1/status' );
?>
<div class="ae-wrap" id="ae-settings-page">

    <div class="ae-page-header">
        <h1>
            <span class="ae-logo-icon">⚙️</span>
            Settings
        </h1>
        <div class="ae-header-actions">
            <button class="ae-btn ae-btn-primary" id="ae-save-settings-btn">
                <span class="ae-spinner"></span>
                <span class="ae-btn-text">💾 Save Settings</span>
            </button>
        </div>
    </div>

    <!-- Tabs -->
    <div class="ae-tabs">
        <button class="ae-tab ae-active" data-tab="general">⚙️ General</button>
        <button class="ae-tab" data-tab="ai">🤖 AI Rewriting</button>
        <button class="ae-tab" data-tab="images">🖼 Images</button>
        <button class="ae-tab" data-tab="watermark">💧 Watermark</button>
        <button class="ae-tab" data-tab="text-watermark">✍️ Text Watermark</button>
        <button class="ae-tab" data-tab="findreplace">🔄 Find & Replace</button>
        <button class="ae-tab" data-tab="cron">🔧 Cron Setup</button>
        <button class="ae-tab" data-tab="bridge">🔌 Social Auto Poster</button>
    </div>

    <!-- ═══ General Tab ═══ -->
    <div class="ae-tab-content ae-active" id="ae-tab-general">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>📝 Publishing</h3>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 13px; margin: 0 0 16px 0;">
                    💡 Fetch interval is now set per-feed in the Feed Manager.
                </p>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Post Status</h4>
                        <p>Default status for auto-published posts.</p>
                    </div>
                    <div class="ae-setting-control">
                        <select id="ae-post-status" class="ae-form-select">
                            <option value="publish" selected>Publish</option>
                        </select>
                        <p style="font-size:12px;color:#888;margin-top:4px;">Posts seedha publish honge (Draft option hata diya gaya).</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🛡 Content Quality & Rate Limits</h3>
            </div>
            <div class="ae-card-body">
                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Minimum Word Count</h4>
                        <p>Skip articles with fewer words than this. Set to 0 to disable.</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-min-word-count" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['min_word_count'] ?? 50 ); ?>"
                            min="0" step="10">
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>&#128270; Scrape Short Feed Content</h4>
                        <p>Kuch feeds sirf chhota teaser/summary deti hain (poora article RSS mein nahi hota). On rakhne par, agar content threshold se kam hai, plugin article ke URL se full content scrape karne ki koshish karega.</p>
                    </div>
                    <div class="ae-setting-control">
                        <label class="ae-toggle">
                            <input type="checkbox" id="ae-scrape-short-content"
                                <?php checked( $settings['scrape_short_content'] ?? true ); ?>>
                            <span class="ae-toggle-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Scrape Trigger Word Count</h4>
                        <p>Agar feed se mila content is se kam words ka hai, to scraping fallback try hoga. Minimum Word Count se kam rakhein (taaki scrape ke baad bhi normal min-word check ho sake).</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-scrape-min-word-count" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['scrape_min_word_count'] ?? 40 ); ?>"
                            min="0" step="10">
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>&#9200; Maximum Content Age (Hours)</h4>
                        <p>Is se zyada purani news publish <strong>nahi</strong> hogi. News sites ke liye <strong>24</strong> recommend hai. 0 set karo to disable (no limit).</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-max-content-age-hours" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['max_content_age_hours'] ?? 24 ); ?>"
                            min="0" step="1" placeholder="24">
                        <small style="display:block;margin-top:4px;color:#888;">ghante (e.g. 24 = last 24 hrs tak hi publish hoga)</small>
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>&#128256; Shuffle Recent Items (Multi-Site)</h4>
                        <p>Agar yahi feed multiple sites pe configured hai, to normally sab sites same "newest first" order follow karke same article same time pe publish karte hain. Ye on karne se top items ke pool ko har cycle mein randomly shuffle kiya jayega — taaki har site alag item pehle pick kare aur same article alag-alag time pe har site pe aaye.</p>
                    </div>
                    <div class="ae-setting-control">
                        <label class="ae-toggle">
                            <input type="checkbox" id="ae-shuffle-recent-items"
                                <?php checked( $settings['shuffle_recent_items'] ?? false ); ?>>
                            <span class="ae-toggle-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Shuffle Pool Size</h4>
                        <p>Top kitne naye items ke beech shuffle ho (recommend: 3-8). Zyada value = zyada randomness lekin thodi purani news bhi jaldi publish ho sakti hai.</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-shuffle-pool-size" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['shuffle_pool_size'] ?? 5 ); ?>"
                            min="2" max="20" step="1" placeholder="5">
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Rate Limit — Per Hour</h4>
                        <p>Maximum posts published per hour. Set to 0 for unlimited.</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-rate-limit-hour" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['rate_limit_hour'] ?? 0 ); ?>"
                            min="0" step="1">
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Rate Limit — Per Day</h4>
                        <p>Maximum posts published per day. Set to 0 for unlimited.</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-rate-limit-day" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['rate_limit_day'] ?? 0 ); ?>"
                            min="0" step="1">
                    </div>
                </div>

            </div>
        </div>

        <!-- ══ Auto Fetch Schedule Card ══ -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🔁 Auto Fetch Schedule</h3>
                <label class="ae-toggle">
                    <input type="checkbox" id="ae-auto-fetch-enabled"
                        <?php checked( ! empty( $settings['auto_fetch_enabled'] ) ); ?>>
                    <span class="ae-toggle-slider"></span>
                    <span class="ae-toggle-label">Enable Auto Fetch</span>
                </label>
            </div>
            <div class="ae-card-body">

                <!-- Status Banner -->
                <div id="ae-auto-fetch-status-on" style="<?php echo empty( $settings['auto_fetch_enabled'] ) ? 'display:none;' : ''; ?> background:#d1fae5; border-left:3px solid #10b981; padding:10px 14px; border-radius:6px; margin-bottom:14px; font-size:13px; color:#065f46;">
                    ✅ <strong>Auto Fetch Active:</strong> Neeche diya interval ke baad saari feeds ek saath fetch hongi. Har feed ke saare naye items publish honge.
                </div>
                <div id="ae-auto-fetch-status-off" style="<?php echo ! empty( $settings['auto_fetch_enabled'] ) ? 'display:none;' : ''; ?> background:#fef3c7; border-left:3px solid #f59e0b; padding:10px 14px; border-radius:6px; margin-bottom:14px; font-size:13px; color:#92400e;">
                    ⚠️ <strong>Auto Fetch Disabled:</strong> Abhi har minute 1 random post wala legacy mode chal raha hai. Enable karo to interval-based schedule activate hoga.
                </div>

                <!-- Interval Setting -->
                <div class="ae-form-group" style="margin-bottom:16px;">
                    <label class="ae-form-label">⏱️ Fetch Interval (minutes) — Kitni der baad fetch ho</label>
                    <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
                        <input type="number" id="ae-fetch-interval-minutes"
                            class="ae-form-input"
                            value="<?php echo esc_attr( isset( $settings['fetch_interval_minutes'] ) ? intval( $settings['fetch_interval_minutes'] ) : 2 ); ?>"
                            min="1" max="1440" step="1"
                            style="width:110px;">
                        <span style="font-size:13px; color:var(--ae-text-secondary);">minute</span>
                        <!-- Live Countdown Timer -->
                        <div id="ae-fetch-countdown-box" style="display:<?php echo empty( $settings['auto_fetch_enabled'] ) ? 'none' : 'flex'; ?>; align-items:center; gap:8px; background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:7px 14px;">
                            <span style="font-size:13px; color:#1d4ed8; font-weight:600;">⏳ Next fetch in:</span>
                            <span id="ae-fetch-countdown" style="font-size:18px; font-weight:700; color:#1d4ed8; font-family:monospace; min-width:60px;">--:--</span>
                        </div>
                    </div>
                    <p style="font-size:12px; color:var(--ae-text-secondary); margin:8px 0 0 0;">
                        💡 Example: <strong>2</strong> = har 2 minute baad fetch (recommended), <strong>15</strong> = har 15 minute baad. Timer live countdown dikhata hai next fetch tak.
                    </p>
                </div>

                <!-- Last + Next Fetch Info (shown when enabled) -->
                <div id="ae-fetch-interval-info" style="<?php echo empty( $settings['auto_fetch_enabled'] ) ? 'display:none;' : ''; ?> padding:10px 14px; background:var(--ae-bg-secondary,#f6f7f8); border-radius:8px; font-size:13px;">
                    <strong>📅 Status:</strong>
                    <span id="ae-fetch-interval-status" style="color:var(--ae-primary,#4f46e5); font-weight:600;">
                        <?php
                        $interval_min = isset( $settings['fetch_interval_minutes'] ) ? intval( $settings['fetch_interval_minutes'] ) : 2;
                        echo 'Har ' . esc_html( $interval_min ) . ' minute baad saari feeds fetch hongi.';
                        ?>
                    </span>
                </div>
                <!-- Hidden: last fetch timestamp for JS countdown -->
                <input type="hidden" id="ae-last-fetch-ts" value="<?php echo esc_attr( get_option( 'ae_last_bulk_fetch_ts', 0 ) ); ?>">
                <input type="hidden" id="ae-fetch-interval-val" value="<?php echo esc_attr( isset( $settings['fetch_interval_minutes'] ) ? intval( $settings['fetch_interval_minutes'] ) : 2 ); ?>">
            </div>
        </div>

        <!-- ══ Title Symbol / ZWC Card ══ -->
        <?php
        $symbol_options = array(
            'zwc'    => array( 'value' => "\u{200B}", 'display' => 'ZWC Invisible' ),
            'star'   => array( 'value' => '★',        'display' => '★' ),
            'bullet' => array( 'value' => '•',        'display' => '•' ),
            'caret'  => array( 'value' => '^',         'display' => '^' ),
            'hash'   => array( 'value' => '#',         'display' => '#' ),
            'pipe'   => array( 'value' => '|',         'display' => '|' ),
            'dot'    => array( 'value' => '·',         'display' => '·' ),
            'dash'   => array( 'value' => '–',         'display' => '–' ),
            'custom' => array( 'value' => '',          'display' => 'Custom…' ),
        );
        $saved_symbol = isset( $settings['title_symbol'] ) ? $settings['title_symbol'] : '';
        $saved_type   = isset( $settings['title_symbol_type'] ) ? $settings['title_symbol_type'] : 'zwc';
        $saved_pos    = isset( $settings['title_symbol_position'] ) ? $settings['title_symbol_position'] : 'none';
        ?>
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🔣 Title Symbol &amp; ZWC</h3>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 13px; margin: 0 0 14px 0;">
                    Har published title ke saath ek unique symbol ya <strong>ZWC (Zero-Width Character)</strong> lagao.<br>
                    ZWC invisible hota hai — title same dikhega lekin technically alag hoga, isliye copy-paste se same title ki news kabhi duplicate nahi hogi.
                </p>

                <div style="display:flex; gap:28px; flex-wrap:wrap; align-items:flex-start;">

                    <!-- Left: Position -->
                    <div style="min-width:200px;">
                        <label class="ae-form-label" style="margin-bottom:8px; display:block;">📍 Position</label>
                        <?php foreach ( array( 'prefix' => 'Pahle (Prefix)', 'suffix' => 'Baad mein (Suffix)', 'both' => 'Dono taraf (Both)', 'none' => 'Off (None)' ) as $pval => $plabel ) : ?>
                        <label style="display:flex; align-items:center; gap:8px; font-size:13px; cursor:pointer; margin-bottom:7px;">
                            <input type="radio" name="title_symbol_position" value="<?php echo $pval; ?>"
                                <?php checked( $saved_pos, $pval ); ?>>
                            <?php echo $plabel; ?>
                        </label>
                        <?php endforeach; ?>
                    </div>

                    <!-- Right: Symbol picker -->
                    <div style="flex:1; min-width:260px;">
                        <label class="ae-form-label" style="margin-bottom:8px; display:block;">✨ Symbol</label>
                        <div style="display:flex; flex-wrap:wrap; gap:8px;" id="ae-symbol-picker">
                            <?php foreach ( $symbol_options as $key => $opt ) :
                                $is_active = ( $saved_type === $key ); ?>
                            <button type="button"
                                class="ae-btn <?php echo $is_active ? 'ae-btn-primary' : 'ae-btn-secondary'; ?> ae-symbol-btn"
                                data-symbol-type="<?php echo esc_attr( $key ); ?>"
                                data-symbol-value="<?php echo esc_attr( $opt['value'] ); ?>"
                                style="font-size:14px; padding:6px 14px; min-width:64px;">
                                <?php echo esc_html( $opt['display'] ); ?>
                            </button>
                            <?php endforeach; ?>
                        </div>

                        <!-- Custom input -->
                        <div id="ae-custom-symbol-wrap" style="<?php echo ( $saved_type === 'custom' ) ? '' : 'display:none;'; ?> margin-top:10px;">
                            <input type="text" id="ae-custom-symbol-input" class="ae-form-input"
                                placeholder="Koi bhi character ya symbol…"
                                value="<?php echo esc_attr( $saved_type === 'custom' ? $saved_symbol : '' ); ?>"
                                style="width:180px; font-size:16px;">
                        </div>

                        <!-- Hidden fields -->
                        <input type="hidden" id="ae-title-symbol" name="title_symbol" value="<?php echo esc_attr( $saved_symbol ); ?>">
                        <input type="hidden" id="ae-title-symbol-type" name="title_symbol_type" value="<?php echo esc_attr( $saved_type ); ?>">

                        <!-- Preview -->
                        <div style="margin-top:14px; padding:10px 14px; background:var(--ae-bg-secondary,#f6f7f8); border-radius:8px; font-size:13px;">
                            <strong>👁️ Preview:</strong>
                            <span id="ae-symbol-preview" style="font-size:14px; margin-left:8px; font-weight:600; color:var(--ae-primary,#4f46e5);">
                                <?php
                                $sym    = ( $saved_type === 'zwc' ) ? '(ZWC)' : esc_html( $saved_symbol );
                                $sample = 'Breaking: India GDP Grows 8%';
                                if ( $saved_pos === 'prefix' )      echo $sym . $sample;
                                elseif ( $saved_pos === 'suffix' )  echo $sample . $sym;
                                elseif ( $saved_pos === 'both' )    echo $sym . $sample . $sym;
                                else                                echo $sample . ' (symbol off)';
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ══ Time Slots Card ══ -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🕐 Publishing Time Slots (IST)</h3>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 13px; margin: 0 0 16px 0;">
                    💡 Feeds sirf inhi time windows mein run honge. Koi slot nahi = hamesha run hoga.<br>
                    <strong>Tip:</strong> Slot ke andar Max Posts per Cycle = 0 rakhne se koi bhi post miss nahi hogi.
                </p>

                <div id="ae-time-slots-container">
                    <?php
                    $slots = isset( $settings['time_slots'] ) ? $settings['time_slots'] : array();
                    if ( empty( $slots ) ) {
                        $slots = array(); // Show empty state with add button
                    }
                    foreach ( $slots as $i => $slot ) :
                        $start = esc_attr( $slot['start'] ?? '' );
                        $end   = esc_attr( $slot['end'] ?? '' );
                    ?>
                    <div class="ae-time-slot-row" style="display:flex; align-items:center; gap:12px; margin-bottom:10px;">
                        <label style="font-size:13px; color:var(--ae-text-secondary); min-width:40px;">Start</label>
                        <input type="time" class="ae-form-input ae-slot-start" value="<?php echo $start; ?>"
                            style="width:140px;" data-index="<?php echo $i; ?>">
                        <label style="font-size:13px; color:var(--ae-text-secondary); min-width:30px;">End</label>
                        <input type="time" class="ae-form-input ae-slot-end" value="<?php echo $end; ?>"
                            style="width:140px;" data-index="<?php echo $i; ?>">
                        <button type="button" class="ae-btn ae-btn-danger ae-remove-slot"
                            style="padding:4px 10px; font-size:12px;">✕ Remove</button>
                    </div>
                    <?php endforeach; ?>
                </div>

                <button type="button" id="ae-add-slot-btn" class="ae-btn ae-btn-secondary" style="margin-top:8px;">
                    ➕ Add Time Slot
                </button>

                <div id="ae-slots-preview" style="margin-top:14px; padding:10px 14px; background:var(--ae-bg-secondary,#f6f7f8); border-radius:8px; font-size:13px; display:none;">
                    <strong>Active Slots:</strong> <span id="ae-slots-preview-text"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ AI Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-ai">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🤖 AI Rewriting Engine</h3>
                <label class="ae-toggle">
                    <input type="checkbox" id="ae-ai-enabled"
                        <?php checked( ! empty( $settings['ai_enabled'] ) ); ?>>
                    <span class="ae-toggle-slider"></span>
                    <span class="ae-toggle-label">Enable AI</span>
                </label>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 14px; margin: 0 0 20px 0;">
                    When disabled, the plugin publishes cleaned original content. AI is completely optional.
                </p>

                <div id="ae-ai-options" style="<?php echo empty( $settings['ai_enabled'] ) ? 'display:none;' : ''; ?>">
                    <div class="ae-form-group">
                        <label class="ae-form-label">🤖 AI Provider</label>
                        <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:10px 16px;border-radius:var(--ae-radius-sm);border:2px solid var(--ae-border);background:var(--ae-bg);">
                                <input type="radio" name="ae_ai_provider" id="ae-ai-provider-openai" value="openai"
                                    <?php checked( ( $settings['ai_provider'] ?? 'openai' ) === 'openai' ); ?>>
                                <span><strong>ChatGPT (OpenAI)</strong><br><span style="font-size:11px;color:var(--ae-text-muted);">API key: sk-...</span></span>
                            </label>
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:10px 16px;border-radius:var(--ae-radius-sm);border:2px solid var(--ae-border);background:var(--ae-bg);">
                                <input type="radio" name="ae_ai_provider" id="ae-ai-provider-anthropic" value="anthropic"
                                    <?php checked( ( $settings['ai_provider'] ?? 'openai' ) === 'anthropic' ); ?>>
                                <span><strong>Claude (Anthropic)</strong><br><span style="font-size:11px;color:var(--ae-text-muted);">API key: sk-ant-...</span></span>
                            </label>
                        </div>
                    </div>

                    <div class="ae-form-group">
                        <label class="ae-form-label" id="ae-api-key-label">
                            <?php echo ( $settings['ai_provider'] ?? 'openai' ) === 'anthropic' ? 'Anthropic (Claude) API Key' : 'OpenAI API Key'; ?>
                            <span class="ae-required">*</span>
                        </label>
                        <div style="display: flex; gap: 10px;">
                            <input type="password" id="ae-ai-api-key" class="ae-form-input"
                                value="<?php echo esc_attr( $settings['ai_api_key'] ?? '' ); ?>"
                                placeholder="<?php echo ( $settings['ai_provider'] ?? 'openai' ) === 'anthropic' ? 'sk-ant-...' : 'sk-...'; ?>" style="flex: 1;">
                            <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-test-ai-btn">
                                <span class="ae-spinner"></span>
                                <span class="ae-btn-text">🔗 Test</span>
                            </button>
                        </div>
                    </div>

                    <div class="ae-form-group" id="ae-model-group">
                        <label class="ae-form-label">AI Model</label>
                        <select id="ae-ai-model" class="ae-form-select" style="max-width: 340px;">
                            <?php
                            $cur_provider = $settings['ai_provider'] ?? 'openai';
                            $cur_model    = $settings['ai_model'] ?? '';
                            if ( $cur_provider === 'anthropic' ) : ?>
                                <option value="claude-haiku-4-5-20251001" <?php selected( $cur_model, 'claude-haiku-4-5-20251001' ); ?>>Claude Haiku (fastest, cheapest)</option>
                                <option value="claude-sonnet-4-6" <?php selected( $cur_model, 'claude-sonnet-4-6' ); ?>>Claude Sonnet 4.6 (balanced)</option>
                                <option value="claude-opus-4-6" <?php selected( $cur_model, 'claude-opus-4-6' ); ?>>Claude Opus 4.6 (best quality)</option>
                            <?php else : ?>
                                <option value="gpt-3.5-turbo" <?php selected( $cur_model ?: 'gpt-3.5-turbo', 'gpt-3.5-turbo' ); ?>>GPT-3.5 Turbo (faster, cheaper)</option>
                                <option value="gpt-4" <?php selected( $cur_model, 'gpt-4' ); ?>>GPT-4 (better quality)</option>
                                <option value="gpt-4-turbo" <?php selected( $cur_model, 'gpt-4-turbo' ); ?>>GPT-4 Turbo</option>
                                <option value="gpt-4o" <?php selected( $cur_model, 'gpt-4o' ); ?>>GPT-4o</option>
                                <option value="gpt-4o-mini" <?php selected( $cur_model, 'gpt-4o-mini' ); ?>>GPT-4o Mini</option>
                            <?php endif; ?>
                        </select>
                        <p class="ae-form-hint" id="ae-model-hint">
                            <?php echo $cur_provider === 'anthropic' ? 'Claude Haiku sabse fast aur sasta hai translate ke liye.' : 'GPT-3.5 Turbo recommended for bulk translate tasks.'; ?>
                        </p>
                    </div>

                    <div class="ae-settings-row">
                        <div class="ae-setting-info">
                            <h4>Rewrite Title</h4>
                            <p>AI will generate a more engaging, SEO-friendly title.</p>
                        </div>
                        <div class="ae-setting-control">
                            <label class="ae-toggle">
                                <input type="checkbox" id="ae-ai-rewrite-title"
                                    <?php checked( ! empty( $settings['ai_rewrite_title'] ) ); ?>>
                                <span class="ae-toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="ae-settings-row">
                        <div class="ae-setting-info">
                            <h4>Rewrite Content</h4>
                            <p>AI will rewrite the full article content.</p>
                        </div>
                        <div class="ae-setting-control">
                            <label class="ae-toggle">
                                <input type="checkbox" id="ae-ai-rewrite-content"
                                    <?php checked( ! empty( $settings['ai_rewrite_content'] ) ); ?>>
                                <span class="ae-toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="ae-form-group" style="margin-top: 20px;">
                        <label class="ae-form-label">Custom Prompt</label>
                        <textarea id="ae-ai-custom-prompt" class="ae-form-textarea"
                            placeholder="e.g. Rewrite in Hindi, SEO optimized, 400 words, clickbait title"
                            rows="4"><?php echo esc_textarea( $settings['ai_custom_prompt'] ?? '' ); ?></textarea>
                        <p class="ae-form-hint">This prompt will be appended to the AI's instructions. Use it to define language, tone, word count, style, etc.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ Images Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-images">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🖼 Image Insertion</h3>
            </div>
            <div class="ae-card-body">
                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Insert Featured Image in Content</h4>
                        <p>Automatically insert the featured image inside the post content.</p>
                    </div>
                    <div class="ae-setting-control">
                        <label class="ae-toggle">
                            <input type="checkbox" id="ae-image-insert"
                                <?php checked( ! empty( $settings['image_insert'] ) ); ?>>
                            <span class="ae-toggle-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="ae-settings-row">
                    <div class="ae-setting-info">
                        <h4>Image Position</h4>
                        <p>Insert the image after this paragraph number (1 = after first paragraph).</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-image-position" class="ae-form-input"
                            value="<?php echo esc_attr( $settings['image_position'] ?? 1 ); ?>"
                            min="1" max="20" step="1">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ Watermark Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-watermark">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>💧 Image Watermark — Logo Upload</h3>
            </div>
            <div class="ae-card-body">

                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:12px 16px; margin-bottom:20px; font-size:13px; color:#1e40af;">
                    ℹ️ <strong>Yahan sirf logo upload karo.</strong> Watermark ON/OFF, Position, Opacity, Size, aur No Margin — yeh sab har feed me alag-alag set hota hai.<br>
                    <span style="color:#64748b; font-size:12px;">Sirf jinhe watermark chahiye unki image server pe save hogi — baaki feeds ki image download hi nahi hogi.</span>
                </div>

                <div class="ae-form-group">
                    <label class="ae-form-label">WATERMARK LOGO</label>
                    <div class="ae-watermark-preview" id="ae-watermark-preview">
                        <?php if ( ! empty( $settings['watermark_image'] ) ) :
                            $img_url = wp_get_attachment_image_url( $settings['watermark_image'], 'medium' );
                            if ( $img_url ) : ?>
                                <img src="<?php echo esc_url( $img_url ); ?>" style="max-height:100px; max-width:200px; object-fit:contain;">
                            <?php else : ?>
                                <span style="color: var(--ae-text-muted);">No logo selected</span>
                            <?php endif;
                        else : ?>
                            <span style="color: var(--ae-text-muted);">No logo selected</span>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" id="ae-watermark-image-id"
                        value="<?php echo esc_attr( $settings['watermark_image'] ?? '' ); ?>">
                    <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-upload-watermark">
                        📁 Upload Logo
                    </button>
                    <p class="ae-form-hint">Upload a PNG image with transparency for best results.</p>
                </div>

            </div>
        </div>
    </div>

    <!-- ═══ Text Watermark Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-text-watermark">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>✍️ Text Watermark</h3>
                <label class="ae-toggle">
                    <input type="checkbox" id="ae-text-watermark-enabled"
                        <?php checked( ! empty( $settings['text_watermark_enabled'] ) ); ?>>
                    <span class="ae-toggle-slider"></span>
                    <span class="ae-toggle-label">Enable Text Watermark</span>
                </label>
            </div>
            <div class="ae-card-body">

                <div id="ae-text-watermark-options" style="<?php echo empty( $settings['text_watermark_enabled'] ) ? 'display:none;' : ''; ?>">

                    <!-- Box 1: Bold heading text (content se PAHLE dikhega) -->
                    <div class="ae-settings-row" style="margin-bottom:24px;">
                        <div class="ae-setting-info">
                            <h4>📌 Box 1 — Bold Heading Text</h4>
                            <p>Yeh text content shuru hone se <strong>pehle</strong> bold mein dikhega.<br>Jaise: <em>MyNews24.com</em></p>
                        </div>
                        <div class="ae-setting-control" style="flex:2;">
                            <textarea id="ae-twm-bold-text"
                                rows="3"
                                style="width:100%;padding:10px 14px;border:1px solid var(--ae-border);border-radius:8px;background:var(--ae-bg-secondary);color:var(--ae-text-primary);font-size:14px;resize:vertical;box-sizing:border-box;"
                                placeholder="Jaise: MyNews24.com"
                            ><?php echo esc_textarea( $settings['twm_bold_text'] ?? '' ); ?></textarea>
                            <p class="ae-form-hint" style="margin-top:6px;">Sirf plain text — yeh apne aap <strong>bold</strong> ho jaayega.</p>
                        </div>
                    </div>

                    <!-- Box 2: Random watermark text (content ke ANDAR randomly) -->
                    <div class="ae-settings-row" style="margin-bottom:24px;">
                        <div class="ae-setting-info">
                            <h4>🎲 Box 2 — Random Watermark Text</h4>
                            <p>Yeh text content ke <strong>andar randomly</strong> kisi bhi paragraph ke baad <strong>1 baar</strong> insert hoga.</p>
                        </div>
                        <div class="ae-setting-control" style="flex:2;">
                            <textarea id="ae-twm-random-text"
                                rows="3"
                                style="width:100%;padding:10px 14px;border:1px solid var(--ae-border);border-radius:8px;background:var(--ae-bg-secondary);color:var(--ae-text-primary);font-size:14px;resize:vertical;box-sizing:border-box;"
                                placeholder="Jaise: यह खबर आप MyNews24 में पढ़ रहे हैं।"
                            ><?php echo esc_textarea( $settings['twm_random_text'] ?? '' ); ?></textarea>
                            <p class="ae-form-hint" style="margin-top:6px;">Plain text likhein. Content ke beech randomly aayega.</p>
                        </div>
                    </div>

                    <!-- Live Preview -->
                    <div class="ae-settings-row">
                        <div class="ae-setting-info">
                            <h4>👁️ Preview</h4>
                            <p>Aisa dikhega post mein.</p>
                        </div>
                        <div class="ae-setting-control" style="flex:2;">
                            <div style="background:var(--ae-bg-secondary);border:1px solid var(--ae-border);border-radius:8px;padding:16px 20px;font-size:14px;color:var(--ae-text-primary);">
                                <p style="margin:0 0 8px 0;"><strong id="ae-preview-bold"><?php echo esc_html( $settings['twm_bold_text'] ?? 'Bold heading text...' ); ?></strong></p>
                                <p style="margin:0;color:var(--ae-text-secondary);">— Content ke andar —</p>
                                <p style="margin:8px 0 0 0;" id="ae-preview-random"><?php echo esc_html( $settings['twm_random_text'] ?? 'Random watermark text...' ); ?></p>
                            </div>
                        </div>
                    </div>

                </div><!-- /#ae-text-watermark-options -->

            </div>
        </div>
    </div>

    <!-- ═══ Find & Replace Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-findreplace">

        <!-- Title Filter Keywords -->
        <div class="ae-card" style="margin-bottom: 24px;">
            <div class="ae-card-header">
                <h3>🚫 Title Filter Keywords</h3>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 14px; margin: 0 0 16px 0;">
                    Agar post ke title mein neeche diye gaye koi bhi keyword mile to wo post <strong>skip</strong> ho jaayegi (publish nahi hogi).<br>
                    Ek line mein ek keyword likho. <strong>Case-insensitive</strong> check hoga — <code>Video</code> aur <code>video</code> same hain, ek baar likhna kaafi hai.
                </p>
                <div class="ae-form-group">
                    <label class="ae-form-label">Skip Keywords (ek per line)</label>
                    <textarea
                        name="title_filter_keywords"
                        id="ae-title-filter-keywords"
                        class="ae-form-input"
                        rows="6"
                        placeholder="video&#10;live&#10;watch now&#10;viral video"
                        style="font-family: monospace; font-size: 13px;"
                    ><?php
                        $kws = isset( $settings['title_filter_keywords'] ) ? $settings['title_filter_keywords'] : array();
                        // Already lowercase stored hain, direct display karo
                        echo esc_textarea( implode( "\n", $kws ) );
                    ?></textarea>
                    <p style="color: var(--ae-text-muted); font-size: 11px; margin: 6px 0 0 0;">
                        ⚠️ Save hone ke baad keywords automatically lowercase ho jaate hain aur duplicates remove ho jaate hain.
                    </p>
                </div>
                <p style="color: var(--ae-text-secondary); font-size: 12px; margin: 8px 0 0 0;">
                    💡 Example: <code>video</code>, <code>live</code>, <code>watch</code> — partial match bhi kaam karta hai. "viral <strong>video</strong>" ya "LIVE updates" dono skip honge.
                </p>
            </div>
        </div>

        <!-- Find & Replace Rules -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🔄 Find & Replace Rules</h3>
                <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-add-rule-btn">+ Add Rule</button>
            </div>
            <div class="ae-card-body">
                <p style="color: var(--ae-text-secondary); font-size: 14px; margin: 0 0 20px 0;">
                    Define text replacement rules that run before publishing. Useful for removing unwanted phrases, replacing source names, fixing formatting, etc.
                </p>

                <div id="ae-find-replace-rules">
                    <div class="ae-empty" id="ae-no-rules" style="padding: 30px; display:none;">
                        <p>No rules defined yet. Click &quot;+ Add Rule&quot; to create one.</p>
                    </div>
                </div>
                <script>
                window._aeFrInitRules = <?php echo wp_json_encode( isset( $settings['find_replace_rules'] ) ? array_values( $settings['find_replace_rules'] ) : array() ); ?>;
                </script>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ Cron Setup Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-cron">
        <?php
        $cron_key     = get_option( 'ae_direct_cron_key', '' );
        $cron_interval = absint( get_option( 'ae_cron_interval', 2 ) );
        $site_url     = home_url();
        $trigger_url  = $cron_key ? $site_url . '/?ae_cron=1&ae_key=' . $cron_key : '';
        $wp_config_ok = defined( 'AE_DIRECT_CRON_KEY' );
        ?>

        <!-- Key Setup -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🔑 Secret Cron Key</h3>
            </div>
            <div class="ae-card-body">
                <p style="color:var(--ae-text-secondary);font-size:13px;margin:0 0 16px 0;">
                    Yeh key aapke server cron ko plugin se connect karti hai. Sirf aapka cron job isko use kar sakta hai.
                </p>

                <?php if ( $wp_config_ok ) : ?>
                    <div style="background:#d4edda;border:1px solid #c3e6cb;border-radius:8px;padding:12px 16px;margin-bottom:16px;font-size:13px;color:#155724;">
                        ✅ <strong>wp-config.php</strong> mein <code>AE_DIRECT_CRON_KEY</code> defined hai — wahi key use ho rahi hai. Neeche ki key ignore karein.
                    </div>
                <?php endif; ?>

                <div class="ae-form-group">
                    <label class="ae-form-label">Current Key</label>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <input type="text" id="ae-cron-key-display"
                            value="<?php echo esc_attr( $wp_config_ok ? constant('AE_DIRECT_CRON_KEY') : $cron_key ); ?>"
                            class="ae-form-input" readonly style="flex:1;font-family:monospace;font-size:13px;"
                            <?php echo $wp_config_ok ? 'disabled' : ''; ?>>
                        <?php if ( ! $wp_config_ok ) : ?>
                        <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-generate-key-btn">🔄 New Key</button>
                        <?php endif; ?>
                        <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-copy-key-btn">📋 Copy</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Trigger URL -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🔗 Cron Trigger URL</h3>
            </div>
            <div class="ae-card-body">
                <p style="color:var(--ae-text-secondary);font-size:13px;margin:0 0 16px 0;">
                    Yeh URL apne server cron job mein lagao. Har minute ya 2 minute par call honi chahiye.
                </p>

                <div class="ae-form-group">
                    <label class="ae-form-label">Full Trigger URL</label>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <input type="text" id="ae-trigger-url"
                            value="<?php echo esc_attr( $trigger_url ); ?>"
                            class="ae-form-input" readonly style="flex:1;font-family:monospace;font-size:12px;">
                        <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-copy-url-btn">📋 Copy</button>
                    </div>
                </div>

                <!-- Interval Setting -->
                <div class="ae-settings-row" style="margin-top:20px;">
                    <div class="ae-setting-info">
                        <h4>Cron Interval (minutes)</h4>
                        <p>Server cron kitne minute mein ek baar fire kare. Recommended: 2</p>
                    </div>
                    <div class="ae-setting-control">
                        <input type="number" id="ae-cron-interval" class="ae-form-input"
                            value="<?php echo esc_attr( $cron_interval ); ?>"
                            min="1" max="60" step="1" style="width:80px;">
                    </div>
                </div>

                <button class="ae-btn ae-btn-primary" id="ae-save-cron-btn" style="margin-top:16px;">
                    <span class="ae-spinner"></span>
                    <span class="ae-btn-text">💾 Save Cron Settings</span>
                </button>
            </div>
        </div>

        <!-- cPanel Instructions -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>📋 cPanel / hPanel Setup Instructions</h3>
            </div>
            <div class="ae-card-body">
                <p style="color:var(--ae-text-secondary);font-size:13px;margin:0 0 16px 0;">
                    Neeche diya gaya command apne hosting panel ke <strong>Cron Jobs</strong> section mein paste karo.
                </p>

                <div class="ae-form-group">
                    <label class="ae-form-label">Command to Run</label>
                    <div style="background:#1e1e2e;border-radius:8px;padding:14px 16px;font-family:monospace;font-size:13px;color:#a6e3a1;position:relative;">
                        <code id="ae-cron-command">curl -s "<?php echo esc_html( $trigger_url ); ?>" &gt; /dev/null</code>
                        <button class="ae-btn ae-btn-secondary ae-btn-sm" id="ae-copy-cmd-btn"
                            style="position:absolute;top:8px;right:8px;font-size:11px;padding:3px 8px;">
                            📋 Copy
                        </button>
                    </div>
                </div>

                <div style="margin-top:16px;">
                    <strong style="font-size:13px;">Schedule (Crontab):</strong>
                    <div style="background:#1e1e2e;border-radius:8px;padding:10px 14px;font-family:monospace;font-size:13px;color:#89b4fa;margin-top:8px;">
                        <code id="ae-cron-schedule">*/<?php echo esc_html( $cron_interval ); ?> * * * *</code>
                    </div>
                    <p style="color:var(--ae-text-secondary);font-size:12px;margin-top:6px;">
                        💡 Iska matlab: har <?php echo esc_html( $cron_interval ); ?> minute mein run hoga.
                    </p>
                </div>

                <div style="margin-top:20px;padding:12px 16px;background:var(--ae-bg-secondary,#f6f7f8);border-radius:8px;font-size:13px;">
                    <strong>Step-by-step:</strong>
                    <ol style="margin:8px 0 0 0;padding-left:18px;line-height:1.8;">
                        <li>cPanel / hPanel → <strong>Cron Jobs</strong> mein jao</li>
                        <li>Type: <strong>Custom</strong> select karo</li>
                        <li>Upar wala <strong>Command</strong> paste karo</li>
                        <li>Schedule mein <strong>*/<?php echo esc_html( $cron_interval ); ?> * * * *</strong> likho</li>
                        <li><strong>Save</strong> karo — ho gaya! ✅</li>
                    </ol>
                </div>
            </div>
        </div>

        <!-- Test Trigger -->
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🧪 Test Cron Trigger</h3>
            </div>
            <div class="ae-card-body">
                <p style="color:var(--ae-text-secondary);font-size:13px;margin:0 0 16px 0;">
                    Yeh button manually cron trigger karega — check kar sakte ho ki sab kaam kar raha hai ya nahi.
                </p>
                <button class="ae-btn ae-btn-primary" id="ae-test-cron-btn">
                    <span class="ae-spinner"></span>
                    <span class="ae-btn-text">▶ Run Cron Now</span>
                </button>
                <div id="ae-cron-test-result" style="margin-top:14px;display:none;padding:12px 16px;border-radius:8px;font-size:13px;"></div>
            </div>
        </div>
    </div>

    <!-- ═══ Social Auto Poster Bridge Tab ═══ -->
    <div class="ae-tab-content" id="ae-tab-bridge">
        <div class="ae-card">
            <div class="ae-card-header">
                <h3>🔌 Social Auto Poster Bridge Integration</h3>
            </div>
            <div class="ae-card-body">
                <p style="color:var(--ae-text-secondary);font-size:13px;margin:0 0 16px 0;">
                    Connect your WordPress site to the <strong>Social Auto Poster Web Studio</strong> to draft, schedule, and publish posts, articles, and breaking news directly from the web app with automatic watermarking &amp; SEO.
                </p>

                <!-- Site URL -->
                <div class="ae-form-group" style="margin-bottom:16px;">
                    <label class="ae-form-label">WordPress Site URL</label>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <input type="text" id="ae-bridge-site-url"
                            value="<?php echo esc_url( home_url() ); ?>"
                            class="ae-form-input" readonly style="flex:1;font-family:monospace;font-size:12px;">
                        <button type="button" class="ae-btn ae-btn-secondary ae-btn-sm" onclick="navigator.clipboard.writeText('<?php echo esc_js( home_url() ); ?>');alert('Site URL copied!');">📋 Copy</button>
                    </div>
                </div>

                <!-- Secret Bridge Key -->
                <div class="ae-form-group" style="margin-bottom:16px;">
                    <label class="ae-form-label">Bridge Secret Key</label>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <input type="text" id="ae-bridge-key"
                            value="<?php echo esc_attr( $bridge_key ); ?>"
                            class="ae-form-input" readonly style="flex:1;font-family:monospace;font-size:12px;background:#1e1e2e;color:#a6e3a1;">
                        <button type="button" class="ae-btn ae-btn-secondary ae-btn-sm" onclick="navigator.clipboard.writeText('<?php echo esc_js( $bridge_key ); ?>');alert('Bridge Secret Key copied!');">📋 Copy Key</button>
                    </div>
                    <p style="color:var(--ae-text-muted);font-size:11px;margin-top:6px;">
                        Is key ko Social Auto Poster App ke "Connected Accounts" &gt; "Connect WordPress" me paste karein.
                    </p>
                </div>

                <!-- Direct REST Endpoint -->
                <div class="ae-form-group" style="margin-bottom:20px;">
                    <label class="ae-form-label">REST API Publish Endpoint</label>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <input type="text" id="ae-bridge-publish-url"
                            value="<?php echo esc_url( $bridge_publish_url ); ?>"
                            class="ae-form-input" readonly style="flex:1;font-family:monospace;font-size:12px;">
                        <button type="button" class="ae-btn ae-btn-secondary ae-btn-sm" onclick="navigator.clipboard.writeText('<?php echo esc_js( $bridge_publish_url ); ?>');alert('Endpoint URL copied!');">📋 Copy Endpoint</button>
                    </div>
                </div>

                <!-- Outbound Webhook to Social Auto Poster -->
                <div class="ae-form-group" style="margin-bottom:20px;padding:16px;background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;">
                    <label class="ae-form-label" style="font-weight:700;color:#0f172a;">⚡ Outbound Auto-Broadcast Webhook (WP &rarr; Social Media)</label>
                    <p style="color:var(--ae-text-secondary,#475569);font-size:12px;margin:4px 0 10px 0;">
                        Auto Engine jab bhi WordPress me koi nayi post publish karega, vo is Webhook par notify karega taaki <strong>Facebook, Telegram, Instagram</strong> par automatically post publish ho sake.
                    </p>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <input type="url" id="ae-social-webhook-input"
                            value="<?php echo esc_url( get_option( 'ae_social_webhook_url', '' ) ); ?>"
                            placeholder="https://app.socialautoposter.pro/api/webhook/wordpress?secret=..."
                            class="ae-form-input" style="flex:1;font-size:12px;font-family:monospace;">
                        <button type="button" class="ae-btn ae-btn-primary ae-btn-sm" onclick="saveSocialWebhook();">💾 Save Webhook</button>
                    </div>
                    <span id="ae-social-webhook-status" style="display:block;font-size:11px;color:#10b981;margin-top:6px;font-weight:600;"></span>
                </div>

                <script>
                function saveSocialWebhook() {
                    var url = document.getElementById('ae-social-webhook-input').value.trim();
                    var statusEl = document.getElementById('ae-social-webhook-status');
                    statusEl.innerText = 'Saving...';
                    jQuery.post(ajaxurl, {
                        action: 'ae_save_social_webhook',
                        webhook_url: url,
                        _ajax_nonce: '<?php echo esc_js( wp_create_nonce( 'auto_engine_nonce' ) ); ?>'
                    }, function(res) {
                        if (res.success) {
                            statusEl.style.color = '#10b981';
                            statusEl.innerText = '✅ ' + res.data.message;
                        } else {
                            statusEl.style.color = '#ef4444';
                            statusEl.innerText = '❌ Failed to save webhook.';
                        }
                        setTimeout(function(){ statusEl.innerText = ''; }, 4000);
                    });
                }
                </script>

                <!-- Setup Guide Card -->
                <div style="padding:16px;background:var(--ae-bg-secondary,#f8f9fa);border-radius:12px;border:1px solid var(--ae-border,#e2e8f0);font-size:13px;line-height:1.7;">
                    <strong style="color:var(--ae-text-primary,#0f172a);display:block;margin-bottom:8px;">🚀 Quick Setup Steps in Social Auto Poster App:</strong>
                    <ol style="margin:0;padding-left:20px;color:var(--ae-text-secondary,#475569);">
                        <li>Open your <strong>Social Auto Poster</strong> dashboard.</li>
                        <li>Go to <strong>Connected Accounts</strong> and click <strong>"Connect WordPress"</strong>.</li>
                        <li>Paste your <strong>Site URL</strong> (<code><?php echo esc_html( home_url() ); ?></code>) and <strong>Bridge Secret Key</strong> above.</li>
                        <li>Click <strong>"Test Connection &amp; Save"</strong>. Once connected, your WordPress site will appear in targets &amp; Composer live preview!</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

</div>
