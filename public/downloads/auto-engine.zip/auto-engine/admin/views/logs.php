<?php
/**
 * Logs view — filterable activity log viewer with pagination.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="ae-wrap" id="ae-logs-page">

    <div class="ae-page-header">
        <h1>
            <span class="ae-logo-icon">📋</span>
            Activity Logs
        </h1>
        <div class="ae-header-actions">
            <button class="ae-btn ae-btn-danger ae-btn-sm" id="ae-clear-logs-btn">
                🗑️ Clear All Logs
            </button>
        </div>
    </div>

    <!-- Filters -->
    <div class="ae-card">
        <div class="ae-card-body">
            <div class="ae-log-filters">
                <label style="font-size: 14px; color: var(--ae-text-secondary); font-weight: 500;">Type:</label>
                <select id="ae-log-type-filter" class="ae-form-select" style="min-width:130px;">
                    <option value="">All Types</option>
                    <option value="fetch">📥 Fetch</option>
                    <option value="publish">✅ Publish</option>
                    <option value="duplicate">⚠️ Duplicate</option>
                    <option value="error">❌ Error</option>
                    <option value="ai">🤖 AI</option>
                    <option value="image">🖼 Image</option>
                    <option value="info">ℹ️ Info</option>
                </select>

                <label style="font-size: 14px; color: var(--ae-text-secondary); font-weight: 500;">Feed:</label>
                <select id="ae-log-feed-filter" class="ae-form-select" style="min-width:150px;">
                    <option value="">All Feeds</option>
                </select>

                <input
                    type="text"
                    id="ae-log-search"
                    class="ae-form-input"
                    placeholder="🔍 Search messages..."
                    style="min-width:200px; flex:1;"
                />

                <button class="ae-btn ae-btn-secondary ae-btn-sm" onclick="loadLogs && loadLogs(1);">
                    🔄 Refresh
                </button>
            </div>
        </div>
    </div>

    <!-- Log Entries -->
    <div class="ae-card">
        <div class="ae-card-header">
            <h3>📊 Log Entries</h3>
        </div>
        <div class="ae-card-body" style="padding: 0;">
            <div id="ae-logs-body">
                <div class="ae-empty">
                    <p>Loading logs...</p>
                </div>
            </div>
        </div>
        <div class="ae-card-footer" style="justify-content: center;">
            <div class="ae-pagination" id="ae-logs-pagination"></div>
        </div>
    </div>

</div>
