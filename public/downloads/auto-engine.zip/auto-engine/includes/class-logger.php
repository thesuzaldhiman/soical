<?php
/**
 * Logger — handles all plugin logging to custom database table.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Logger {

    /**
     * Singleton instance.
     *
     * @var AE_Logger|null
     */
    private static $instance = null;

    /**
     * Table name.
     *
     * @var string
     */
    private $table;

    /**
     * Constructor.
     */
    private function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'ae_logs';
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Logger
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Add a log entry.
     *
     * @param int    $feed_id Feed ID (0 for general logs).
     * @param string $type    Log type: fetch, duplicate, publish, error, ai, image, info.
     * @param string $message Log message.
     * @return int|false Insert ID or false on failure.
     */
    public function log( $feed_id, $type, $message ) {
        global $wpdb;

        $result = $wpdb->insert(
            $this->table,
            array(
                'feed_id'    => absint( $feed_id ),
                'log_type'   => sanitize_text_field( $type ),
                'message'    => sanitize_text_field( $message ),
                'created_at' => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%s' )
        );

        if ( false === $result ) {
            return false;
        }

        return $wpdb->insert_id;
    }

    /**
     * Get log entries with filters.
     *
     * @param array $args {
     *     Optional. Query arguments.
     *     @type string $log_type Filter by log type.
     *     @type int    $feed_id  Filter by feed ID.
     *     @type int    $per_page Number of results per page. Default 50.
     *     @type int    $page     Page number. Default 1.
     *     @type string $orderby  Column to order by. Default 'created_at'.
     *     @type string $order    ASC or DESC. Default 'DESC'.
     * }
     * @return array {
     *     @type array $logs  Array of log objects.
     *     @type int   $total Total matching entries.
     * }
     */
    public function get_logs( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'log_type' => '',
            'feed_id'  => 0,
            'per_page' => 50,
            'page'     => 1,
            'orderby'  => 'created_at',
            'order'    => 'DESC',
            'search'   => '',
        );

        $args = wp_parse_args( $args, $defaults );

        $feeds_table = $wpdb->prefix . 'ae_feeds';

        $where   = array( '1=1' );
        $values  = array();

        if ( ! empty( $args['log_type'] ) ) {
            $where[]  = 'l.log_type = %s';
            $values[] = sanitize_text_field( $args['log_type'] );
        }

        if ( ! empty( $args['feed_id'] ) ) {
            $where[]  = 'l.feed_id = %d';
            $values[] = absint( $args['feed_id'] );
        }

        if ( ! empty( $args['search'] ) ) {
            $where[]  = 'l.message LIKE %s';
            $values[] = '%' . $wpdb->esc_like( sanitize_text_field( $args['search'] ) ) . '%';
        }

        $where_clause = implode( ' AND ', $where );

        // Allowed columns for ordering
        $allowed_orderby = array( 'id', 'feed_id', 'log_type', 'created_at' );
        $orderby = in_array( $args['orderby'], $allowed_orderby, true ) ? 'l.' . $args['orderby'] : 'l.created_at';
        $order   = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';

        $per_page = max( 1, absint( $args['per_page'] ) );
        $page     = max( 1, absint( $args['page'] ) );
        $offset   = ( $page - 1 ) * $per_page;

        // SELECT with LEFT JOIN to get feed_name alongside each log
        $select = "SELECT l.*, f.feed_name AS feed_name, f.feed_url AS feed_url
                   FROM {$this->table} l
                   LEFT JOIN {$feeds_table} f ON l.feed_id = f.id
                   WHERE $where_clause";

        $count_sql = "SELECT COUNT(*) FROM {$this->table} l WHERE $where_clause";

        if ( ! empty( $values ) ) {
            $total = $wpdb->get_var( $wpdb->prepare( $count_sql, ...$values ) );
            $logs  = $wpdb->get_results(
                $wpdb->prepare(
                    "$select ORDER BY $orderby $order LIMIT %d OFFSET %d",
                    array_merge( $values, array( $per_page, $offset ) )
                )
            );
        } else {
            $total = $wpdb->get_var( $count_sql );
            $logs  = $wpdb->get_results(
                $wpdb->prepare(
                    "$select ORDER BY $orderby $order LIMIT %d OFFSET %d",
                    $per_page,
                    $offset
                )
            );
        }

        return array(
            'logs'  => $logs ? $logs : array(),
            'total' => (int) $total,
        );
    }

    /**
     * Get log count by type.
     *
     * @param string $type Log type.
     * @return int
     */
    public function get_count_by_type( $type ) {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table} WHERE log_type = %s",
                $type
            )
        );
    }

    /**
     * Get counts for all log types.
     *
     * @return array Associative array of type => count.
     */
    public function get_all_counts() {
        global $wpdb;
        $results = $wpdb->get_results(
            "SELECT log_type, COUNT(*) as count FROM {$this->table} GROUP BY log_type",
            OBJECT_K
        );

        $counts = array();
        if ( $results ) {
            foreach ( $results as $type => $row ) {
                $counts[ $type ] = (int) $row->count;
            }
        }

        return $counts;
    }

    /**
     * Get recent logs.
     *
     * @param int $limit Number of recent logs.
     * @return array
     */
    public function get_recent( $limit = 10 ) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->table} ORDER BY created_at DESC LIMIT %d",
                absint( $limit )
            )
        );
    }

    /**
     * Clear logs older than a given date.
     *
     * @param string $before_date MySQL datetime format.
     * @return int|false Number of rows deleted or false on failure.
     */
    public function clear_logs( $before_date = '' ) {
        global $wpdb;

        if ( empty( $before_date ) ) {
            return $wpdb->query( "TRUNCATE TABLE {$this->table}" );
        }

        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table} WHERE created_at < %s",
                $before_date
            )
        );
    }

    /**
     * Clear all logs.
     *
     * @return int|false
     */
    public function clear_all() {
        global $wpdb;
        return $wpdb->query( "TRUNCATE TABLE {$this->table}" );
    }
}
