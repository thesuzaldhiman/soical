<?php
/**
 * Publisher — creates WordPress posts from processed feed items.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Publisher {

    /**
     * Singleton instance.
     *
     * @var AE_Publisher|null
     */
    private static $instance = null;

    /**
     * Plugin settings.
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor.
     */
    private function __construct() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Publisher
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Reload settings.
     */
    public function reload_settings() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Publish a processed item as a WordPress post.
     *
     * @param array $data {
     *     Processed item data.
     *     @type string $title          Post title.
     *     @type string $content        Cleaned/rewritten content.
     *     @type int    $category_id    Category ID.
     *     @type array  $tags           Tag strings.
     *     @type string $featured_image Featured image URL.
     *     @type int    $feed_id        Source feed ID.
     *     @type string $date           Original publish date.
     *     @type string $author         Original author.
     *     @type string $image_mode     Image mode setting.
     * }
     * @return int|WP_Error Post ID on success, WP_Error on failure.
     */
    public function publish( $data ) {
        $logger = AE_Logger::get_instance();
        $seo    = AE_SEO_Optimizer::get_instance();
        $images = AE_Image_Handler::get_instance();

        $title   = isset( $data['title'] ) ? $data['title'] : '';
        $content = isset( $data['content'] ) ? $data['content'] : '';

        if ( empty( $title ) ) {
            return new WP_Error( 'no_title', 'Post title is empty.' );
        }

        // Settings se post status lo — publish ya draft jo bhi set ho.
        $post_status = isset( $this->settings['post_status'] ) && $this->settings['post_status'] === 'draft' ? 'draft' : 'publish';
        $slug        = $seo->generate_slug( $title );

        // Determine author: use per-feed author_id or fallback to admin
        $author_id = ! empty( $data['author_id'] ) ? absint( $data['author_id'] ) : $this->get_fallback_author();

        // Build the post array
        $post_args = array(
            'post_title'   => wp_strip_all_tags( $title ),
            'post_content' => wp_kses_post( $content ),
            'post_status'  => $post_status,
            'post_type'    => 'post',
            'post_name'    => $slug,
            'post_author'  => $author_id,
        );

        // Set categories (multiple support)
        $cat_ids = array();
        if ( ! empty( $data['category_ids'] ) && is_array( $data['category_ids'] ) ) {
            $cat_ids = array_filter( array_map( 'absint', $data['category_ids'] ) );
        }
        // Fallback to legacy single category_id
        if ( empty( $cat_ids ) && ! empty( $data['category_id'] ) ) {
            $cat_ids = array( absint( $data['category_id'] ) );
        }
        if ( ! empty( $cat_ids ) ) {
            $post_args['post_category'] = $cat_ids;
        }

        // Insert the post
        $post_id = wp_insert_post( $post_args, true );

        if ( is_wp_error( $post_id ) ) {
            $logger->log(
                isset( $data['feed_id'] ) ? $data['feed_id'] : 0,
                'error',
                'Post insert failed: ' . $post_id->get_error_message()
            );
            return $post_id;
        }

        // Tags disabled — koi tag assign nahi hoga

        // Handle featured image
        // IMAGE LOGIC:
        // Watermark ON  → image download karo server pe → logo lagao → post me insert (attachment)
        // Watermark OFF → image server pe save NAHI hogi → external URL directly post me insert hogi

        $attachment_id   = 0;
        $logo_watermark  = ! empty( $data['logo_watermark'] );
        $featured_image  = ! empty( $data['featured_image'] ) ? $data['featured_image'] : '';

        if ( ! empty( $featured_image ) ) {

            if ( $logo_watermark ) {
                // --- WATERMARK ON: Download + Logo + Save ---
                $attachment_id = $images->download_image( $featured_image, $post_id, $title );

                if ( ! is_wp_error( $attachment_id ) ) {
                    $images->set_featured_image( $post_id, $attachment_id );

                    // Logo apply karo
                    $watermark_image_id = ! empty( $this->settings['watermark_image'] ) ? $this->settings['watermark_image'] : 0;
                    if ( $watermark_image_id ) {
                        $images->settings['watermark_enabled']   = true;
                        $images->settings['watermark_position']  = ! empty( $data['logo_position'] ) ? $data['logo_position'] : 'bottom-right';
                        $images->settings['watermark_opacity']   = isset( $data['logo_opacity'] ) ? intval( $data['logo_opacity'] ) : 80;
                        $images->settings['watermark_size']      = isset( $data['logo_size'] )    ? intval( $data['logo_size'] )    : 20;
                        $images->settings['watermark_no_margin'] = ! empty( $data['logo_no_margin'] ) ? 1 : 0;
                        $images->apply_watermark( $attachment_id );
                        // Reset
                        $images->settings['watermark_enabled']   = false;
                        $images->settings['watermark_no_margin'] = 0;
                    } else {
                        $logger->log(
                            isset( $data['feed_id'] ) ? $data['feed_id'] : 0,
                            'warning',
                            'Per-feed logo ON hai par Settings > Watermark mein Logo upload nahi ki.'
                        );
                    }

                    // Content me bhi insert karo (agar setting ON hai)
                    if ( ! empty( $this->settings['image_insert'] ) ) {
                        $position        = isset( $this->settings['image_position'] ) ? absint( $this->settings['image_position'] ) : 1;
                        $updated_content = $images->insert_image_in_content( $content, $attachment_id, $position );
                        wp_update_post( array(
                            'ID'           => $post_id,
                            'post_content' => $updated_content,
                            'post_status'  => $post_status,
                        ) );
                    }
                } else {
                    $logger->log(
                        isset( $data['feed_id'] ) ? $data['feed_id'] : 0,
                        'error',
                        'Image download failed: ' . $attachment_id->get_error_message()
                    );
                }

            } else {
                // --- WATERMARK OFF: Server pe save nahi, external URL se direct insert ---

                // Featured image: external URL ko post meta me store karo
                update_post_meta( $post_id, '_ae_external_featured_image', esc_url_raw( $featured_image ) );

                // Content me bhi external URL se insert karo (agar setting ON hai)
                if ( ! empty( $this->settings['image_insert'] ) ) {
                    $position        = isset( $this->settings['image_position'] ) ? absint( $this->settings['image_position'] ) : 1;
                    $updated_content = $images->insert_external_image_in_content( $content, $featured_image, $position );
                    wp_update_post( array(
                        'ID'           => $post_id,
                        'post_content' => $updated_content,
                        'post_status'  => $post_status,
                    ) );
                }
            }
        }

        // Apply SEO metadata
        $seo->apply_seo( $post_id, $title, $content, $slug );

        // Apply text watermark if enabled
        if ( ! empty( $this->settings['text_watermark_enabled'] ) ) {
            $current_content = get_post_field( 'post_content', $post_id );
            $watermarked     = $this->insert_text_watermark( $current_content );
            wp_update_post( array(
                'ID'           => $post_id,
                'post_content' => $watermarked,
                'post_status'  => $post_status,
            ) );
        }

        // Store source meta
        if ( ! empty( $data['link'] ) ) {
            update_post_meta( $post_id, '_ae_source_url', esc_url_raw( $data['link'] ) );
        }
        if ( ! empty( $data['feed_id'] ) ) {
            update_post_meta( $post_id, '_ae_feed_id', absint( $data['feed_id'] ) );
        }
        if ( ! empty( $data['author'] ) ) {
            update_post_meta( $post_id, '_ae_source_author', sanitize_text_field( $data['author'] ) );
        }

        $logger->log(
            isset( $data['feed_id'] ) ? $data['feed_id'] : 0,
            'publish',
            sprintf( 'Post published: "%s" (ID: %d, Status: %s)', $title, $post_id, $post_status )
        );

        // Outbound Auto-Broadcast Webhook to Social Auto Poster App
        $webhook_url = get_option( 'ae_social_webhook_url', '' );
        if ( ! empty( $webhook_url ) && $post_status === 'publish' ) {
            $featured_img_url = get_the_post_thumbnail_url( $post_id, 'full' );
            if ( ! $featured_img_url && ! empty( $featured_image ) ) {
                $featured_img_url = $featured_image;
            }
            wp_remote_post( $webhook_url, array(
                'blocking' => false,
                'timeout'  => 5,
                'headers'  => array( 'Content-Type' => 'application/json' ),
                'body'     => wp_json_encode( array(
                    'title'     => $title,
                    'permalink' => get_permalink( $post_id ),
                    'image_url' => $featured_img_url,
                    'excerpt'   => wp_trim_words( wp_strip_all_tags( $content ), 40 ),
                    'category'  => ! empty( $cat_ids ) ? $cat_ids[0] : 0,
                ) ),
            ) );
        }

        return $post_id;
    }

    /**
     * Reprocess an existing post — re-run image handler and SEO.
     *
     * @param int $post_id Post ID.
     * @return bool|WP_Error True on success.
     */
    public function reprocess( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return new WP_Error( 'not_found', 'Post not found.' );
        }

        $logger = AE_Logger::get_instance();
        $seo    = AE_SEO_Optimizer::get_instance();

        // Re-apply SEO
        $seo->apply_seo( $post_id, $post->post_title, $post->post_content, $post->post_name );

        // Tags disabled

        $logger->log( 0, 'info', sprintf( 'Post reprocessed: "%s" (ID: %d)', $post->post_title, $post_id ) );

        return true;
    }

    /**
     * Insert text watermark into post content.
     * Box 1 (bold_text)   -> prepended BEFORE content.
     * Box 2 (random_text) -> inserted randomly INSIDE content (once).
     *
     * @param string $content Post HTML content.
     * @return string Modified content.
     */
    private function insert_text_watermark( $content ) {
        $bold_text   = ! empty( $this->settings['twm_bold_text'] )   ? trim( $this->settings['twm_bold_text'] )   : '';
        $random_text = ! empty( $this->settings['twm_random_text'] ) ? trim( $this->settings['twm_random_text'] ) : '';

        // Box 1: Bold text at the start of content (same line as first real text)
        if ( ! empty( $bold_text ) ) {
            $bold_inline = '<strong>' . esc_html( $bold_text ) . '</strong> ';

            // Step 1: Shuru ke saare empty tags hata do (jaise <p></p>, <p> </p>, <br>)
            $content = preg_replace( '/^(\s*(<(p|div|span)[^>]*>\s*<\/\3>|<br\s*\/?>)\s*)+/i', '', $content );

            $inserted = false;

            // Case A: Pehla <p> tag mile toh bold andar daalo
            $content = preg_replace_callback(
                '/<p([^>]*)>/i',
                function( $matches ) use ( $bold_inline, &$inserted ) {
                    if ( ! $inserted ) {
                        $inserted = true;
                        return '<p' . $matches[1] . '>' . $bold_inline;
                    }
                    return $matches[0];
                },
                $content
            );

            if ( ! $inserted ) {
                // Case B: Pehla <div> mile toh bold andar daalo
                $content = preg_replace_callback(
                    '/<div([^>]*)>/i',
                    function( $matches ) use ( $bold_inline, &$inserted ) {
                        if ( ! $inserted ) {
                            $inserted = true;
                            return '<div' . $matches[1] . '>' . $bold_inline;
                        }
                        return $matches[0];
                    },
                    $content
                );
            }

            if ( ! $inserted ) {
                // Case C: Koi block tag nahi — seedha bold prefix karo
                $content = '<p>' . $bold_inline . $content . '</p>';
            }
        }

        // Box 2: Random text INSIDE content
        if ( ! empty( $random_text ) ) {
            $random_html = '<p class="ae-twm-random">' . esc_html( $random_text ) . '</p>';

            $parts = preg_split( '|(<\/p>)|i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );

            $pairs = array();
            for ( $i = 0; $i + 1 < count( $parts ); $i += 2 ) {
                $pairs[] = $parts[ $i ] . $parts[ $i + 1 ];
            }
            $leftover = ( count( $parts ) % 2 !== 0 ) ? $parts[ count( $parts ) - 1 ] : '';

            $total = count( $pairs );
            if ( $total < 2 ) {
                $content = $content . "\n" . $random_html;
            } else {
                $insert_after = rand( 1, $total - 1 );
                $out = '';
                foreach ( $pairs as $idx => $para ) {
                    $out .= $para;
                    if ( ( $idx + 1 ) === $insert_after ) {
                        $out .= "\n" . $random_html . "\n";
                    }
                }
                $content = $out . $leftover;
            }
        }

        return $content;
    }
    /**
     * Get a fallback author ID for auto-published posts.
     *
     * @return int User ID.
     */
    private function get_fallback_author() {
        // Use the first administrator
        $admins = get_users( array(
            'role'   => 'administrator',
            'number' => 1,
            'fields' => array( 'ID' ),
        ) );

        if ( ! empty( $admins ) ) {
            return $admins[0]->ID;
        }

        return 1;
    }
}
