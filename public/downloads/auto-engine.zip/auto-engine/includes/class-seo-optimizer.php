<?php
/**
 * SEO Optimizer — generates SEO metadata for published posts.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_SEO_Optimizer {

    /**
     * Singleton instance.
     *
     * @var AE_SEO_Optimizer|null
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return AE_SEO_Optimizer
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Generate an SEO-friendly slug from a title.
     *
     * @param string $title Post title.
     * @return string Sanitized slug.
     */
    public function generate_slug( $title ) {
        $slug = sanitize_title( $title );

        // Limit slug length
        $words = explode( '-', $slug );
        if ( count( $words ) > 10 ) {
            $words = array_slice( $words, 0, 10 );
            $slug = implode( '-', $words );
        }

        return $slug;
    }

    /**
     * Generate a meta description from content.
     *
     * @param string $content Post content.
     * @param int    $length  Max length (default 155).
     * @return string Meta description.
     */
    public function generate_meta_description( $content, $length = 155 ) {
        // Strip HTML tags
        $text = wp_strip_all_tags( $content );

        // Remove extra whitespace
        $text = preg_replace( '/\s+/', ' ', $text );
        $text = trim( $text );

        if ( strlen( $text ) <= $length ) {
            return $text;
        }

        // Cut at word boundary
        $text = substr( $text, 0, $length );
        $last_space = strrpos( $text, ' ' );

        if ( $last_space !== false && $last_space > $length * 0.7 ) {
            $text = substr( $text, 0, $last_space );
        }

        return $text . '...';
    }

    /**
     * Generate tags/keywords from content.
     *
     * @param string $content Post content.
     * @param array  $existing_tags Tags from RSS feed.
     * @param int    $max_tags Maximum number of tags.
     * @return array Array of tag strings.
     */
    public function generate_tags( $content, $existing_tags = array(), $max_tags = 5 ) {
        // Start with existing tags from RSS
        $tags = array();

        if ( ! empty( $existing_tags ) ) {
            foreach ( $existing_tags as $tag ) {
                $tag = trim( $tag );
                if ( ! empty( $tag ) && strlen( $tag ) > 2 ) {
                    $tags[] = $tag;
                }
            }
        }

        // If we already have enough tags, return
        if ( count( $tags ) >= $max_tags ) {
            return array_slice( $tags, 0, $max_tags );
        }

        // Extract additional tags from content using simple keyword extraction
        $text = wp_strip_all_tags( $content );
        $text = strtolower( $text );

        // Remove common stop words
        $stop_words = array(
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
            'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'could', 'should', 'may', 'might', 'can', 'shall', 'it', 'its',
            'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'we',
            'they', 'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his',
            'our', 'their', 'what', 'which', 'who', 'whom', 'when', 'where',
            'why', 'how', 'all', 'each', 'every', 'both', 'few', 'more', 'most',
            'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
            'so', 'than', 'too', 'very', 'just', 'because', 'about', 'also',
            'into', 'through', 'during', 'before', 'after', 'above', 'below',
            'between', 'out', 'off', 'over', 'under', 'again', 'further',
            'then', 'once', 'here', 'there', 'up', 'down', 'if', 'while',
            'said', 'says', 'new', 'one', 'two', 'first', 'last', 'long',
            'great', 'just', 'still', 'also', 'back', 'much', 'get', 'got',
            'make', 'made', 'take', 'like', 'come', 'know', 'look', 'think',
            'see', 'want', 'give', 'use', 'find', 'tell', 'say', 'go', 'went',
        );

        // Extract words
        $words = str_word_count( $text, 1, '0123456789' );

        // Count word frequency
        $freq = array();
        foreach ( $words as $word ) {
            if ( strlen( $word ) < 4 || in_array( $word, $stop_words, true ) ) {
                continue;
            }
            if ( ! isset( $freq[ $word ] ) ) {
                $freq[ $word ] = 0;
            }
            $freq[ $word ]++;
        }

        // Sort by frequency
        arsort( $freq );

        // Add top keywords as tags
        $needed = $max_tags - count( $tags );
        $extracted = array_slice( array_keys( $freq ), 0, $needed );

        foreach ( $extracted as $keyword ) {
            $keyword = ucfirst( $keyword );
            if ( ! in_array( $keyword, $tags, true ) ) {
                $tags[] = $keyword;
            }
        }

        return array_slice( $tags, 0, $max_tags );
    }

    /**
     * Apply SEO metadata to a post.
     *
     * @param int    $post_id Post ID.
     * @param string $title   Post title.
     * @param string $content Post content.
     * @param string $slug    URL slug.
     */
    public function apply_seo( $post_id, $title, $content, $slug = '' ) {
        $meta_description = $this->generate_meta_description( $content );

        // Store as custom meta
        update_post_meta( $post_id, '_ae_seo_title', $title );
        update_post_meta( $post_id, '_ae_meta_description', $meta_description );

        // Set Yoast SEO meta if available
        if ( defined( 'WPSEO_VERSION' ) ) {
            update_post_meta( $post_id, '_yoast_wpseo_title', $title );
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_description );
            if ( ! empty( $slug ) ) {
                update_post_meta( $post_id, '_yoast_wpseo_focuskw', $this->extract_focus_keyword( $title ) );
            }
        }

        // Set RankMath meta if available
        if ( class_exists( 'RankMath' ) ) {
            update_post_meta( $post_id, 'rank_math_title', $title );
            update_post_meta( $post_id, 'rank_math_description', $meta_description );
            if ( ! empty( $slug ) ) {
                update_post_meta( $post_id, 'rank_math_focus_keyword', $this->extract_focus_keyword( $title ) );
            }
        }

        // Set All in One SEO meta if available
        if ( function_exists( 'aioseo' ) ) {
            update_post_meta( $post_id, '_aioseo_title', $title );
            update_post_meta( $post_id, '_aioseo_description', $meta_description );
        }
    }

    /**
     * Extract a focus keyword from the title.
     *
     * @param string $title Post title.
     * @return string Focus keyword.
     */
    private function extract_focus_keyword( $title ) {
        $stop_words = array( 'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'has', 'have' );

        $words = explode( ' ', strtolower( $title ) );
        $keywords = array();

        foreach ( $words as $word ) {
            $word = preg_replace( '/[^a-z0-9]/', '', $word );
            if ( strlen( $word ) > 3 && ! in_array( $word, $stop_words, true ) ) {
                $keywords[] = $word;
            }
        }

        // Return first 2-3 keywords joined
        $keywords = array_slice( $keywords, 0, 3 );
        return implode( ' ', $keywords );
    }
}
