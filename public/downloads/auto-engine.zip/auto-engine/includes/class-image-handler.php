<?php
/**
 * Image Handler — downloads, watermarks, and manages images for posts.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Image_Handler {

    /**
     * Singleton instance.
     *
     * @var AE_Image_Handler|null
     */
    private static $instance = null;

    /**
     * Plugin settings.
     *
     * @var array
     */
    public $settings;

    /**
     * Constructor.
     */
    private function __construct() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Image_Handler
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Reload settings.
     */
    public function reload_settings() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Download an image from URL and add to WordPress media library.
     *
     * @param string $url     Image URL.
     * @param int    $post_id Post ID to attach to.
     * @param string $title   Image title/alt text.
     * @return int|WP_Error Attachment ID or error.
     */
    public function download_image( $url, $post_id = 0, $title = '' ) {
        if ( empty( $url ) ) {
            return new WP_Error( 'no_url', 'No image URL provided.' );
        }

        $logger = AE_Logger::get_instance();

        // Make sure required functions are available
        if ( ! function_exists( 'media_sideload_image' ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        // Download the image to a temp file
        $tmp = download_url( $url, 30 );

        if ( is_wp_error( $tmp ) ) {
            $logger->log( 0, 'error', 'Image download failed: ' . $tmp->get_error_message() );
            return $tmp;
        }

        // Determine file extension
        $file_name = basename( wp_parse_url( $url, PHP_URL_PATH ) );
        if ( empty( $file_name ) || strpos( $file_name, '.' ) === false ) {
            $file_name = 'image-' . time() . '.jpg';
        }

        // Clean up file name
        $file_name = sanitize_file_name( $file_name );

        $file_array = array(
            'name'     => $file_name,
            'tmp_name' => $tmp,
        );

        // Do the sideload
        $attachment_id = media_handle_sideload( $file_array, $post_id );

        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            $logger->log( 0, 'error', 'Image sideload failed: ' . $attachment_id->get_error_message() );
            return $attachment_id;
        }

        // Set alt text
        if ( ! empty( $title ) ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $title ) );
        }

        // Apply watermark if enabled
        // NOTE: Watermark ab download_image mein nahi lagta.
        // Publisher mein per-feed logo_watermark setting check karke apply hota hai.
        // Isse global setting sab feeds pe force nahi hoti.

        $logger->log( 0, 'image', sprintf( 'Image downloaded and uploaded: %s (ID: %d)', $file_name, $attachment_id ) );

        return $attachment_id;
    }

    /**
     * Set a downloaded image as the post's featured image.
     *
     * @param int $post_id       Post ID.
     * @param int $attachment_id Attachment ID.
     * @return bool True on success.
     */
    public function set_featured_image( $post_id, $attachment_id ) {
        return set_post_thumbnail( $post_id, $attachment_id );
    }

    /**
     * Insert an image into post content after a specific paragraph.
     *
     * @param string $content       Post content HTML.
     * @param int    $attachment_id Attachment ID.
     * @param int    $position      Insert after this paragraph number (1-indexed).
     * @return string Modified content.
     */
    public function insert_image_in_content( $content, $attachment_id, $position = 1 ) {
        $image_url = wp_get_attachment_url( $attachment_id );
        if ( ! $image_url ) {
            return $content;
        }

        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $image_html = sprintf(
            '<figure class="ae-inline-image"><img src="%s" alt="%s" loading="lazy" /><figcaption>%s</figcaption></figure>',
            esc_url( $image_url ),
            esc_attr( $alt ),
            esc_html( $alt )
        );

        return $this->insert_html_in_content( $content, $image_html, $position );
    }

    /**
     * External URL se image directly content me insert karo (server pe save nahi hogi)
     */
    public function insert_external_image_in_content( $content, $image_url, $position = 1 ) {
        $image_html = sprintf(
            '<figure class="ae-inline-image"><img src="%s" alt="" loading="lazy" style="max-width:100%%;height:auto;" /></figure>',
            esc_url( $image_url )
        );
        return $this->insert_html_in_content( $content, $image_html, $position );
    }

    /**
     * HTML block ko content me Nth paragraph ke baad insert karo
     */
    private function insert_html_in_content( $content, $html_block, $position = 1 ) {
        // Split content by closing paragraph or heading tags
        $parts = preg_split( '/(<\/p>|<\/h[1-6]>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );

        if ( count( $parts ) < 2 ) {
            // If no paragraphs found, prepend image
            return $html_block . "\n" . $content;
        }

        // Reconstruct and insert after Nth paragraph
        $output     = '';
        $para_count = 0;
        $inserted   = false;

        for ( $i = 0; $i < count( $parts ); $i++ ) {
            $output .= $parts[ $i ];

            if ( preg_match( '/<\/(p|h[1-6])>/i', $parts[ $i ] ) ) {
                $para_count++;

                if ( $para_count === $position && ! $inserted ) {
                    $output  .= "\n" . $html_block . "\n";
                    $inserted = true;
                }
            }
        }

        if ( ! $inserted ) {
            $output .= "\n" . $html_block;
        }

        return $output;
    }

    /**
     * Apply watermark to an image attachment.
     *
     * @param int $attachment_id Attachment ID to watermark.
     * @return bool True on success.
     */
    public function apply_watermark( $attachment_id ) {
        $logger = AE_Logger::get_instance();

        $image_path = get_attached_file( $attachment_id );
        if ( ! $image_path || ! file_exists( $image_path ) ) {
            $logger->log( 0, 'error', 'Watermark: Image file not found.' );
            return false;
        }

        $watermark_id = absint( $this->settings['watermark_image'] );
        $watermark_path = get_attached_file( $watermark_id );

        if ( ! $watermark_path || ! file_exists( $watermark_path ) ) {
            $logger->log( 0, 'error', 'Watermark: Logo file not found.' );
            return false;
        }

        $position  = isset( $this->settings['watermark_position'] )  ? $this->settings['watermark_position']        : 'bottom-right';
        $opacity   = isset( $this->settings['watermark_opacity'] )   ? absint( $this->settings['watermark_opacity'] ) : 80;
        $size      = isset( $this->settings['watermark_size'] )      ? absint( $this->settings['watermark_size'] )    : 20;
        $no_margin = ! empty( $this->settings['watermark_no_margin'] ) ? true : false;
        $margin    = $no_margin ? 0 : 10;

        // Try Imagick first, fall back to GD
        if ( extension_loaded( 'imagick' ) ) {
            $result = $this->watermark_imagick( $image_path, $watermark_path, $position, $opacity, $size, $margin );
        } elseif ( extension_loaded( 'gd' ) ) {
            $result = $this->watermark_gd( $image_path, $watermark_path, $position, $opacity, $size, $margin );
        } else {
            $logger->log( 0, 'error', 'Watermark: Neither Imagick nor GD available.' );
            return false;
        }

        if ( $result ) {
            $metadata = wp_generate_attachment_metadata( $attachment_id, $image_path );
            wp_update_attachment_metadata( $attachment_id, $metadata );
            $logger->log( 0, 'image', 'Watermark applied. no_margin=' . ( $no_margin ? 'YES' : 'NO' ) . ' margin=' . $margin . ' position=' . $position );
        }

        return $result;
    }

    /**
     * Trim transparent padding from around a GD watermark image.
     * Logo PNGs often export with invisible border space around the
     * actual visible logo, which throws off both size% and corner-margin
     * calculations. This scans the alpha channel for the tightest
     * non-transparent bounding box and returns a cropped copy.
     *
     * @param resource|GdImage $src GD image resource (must have alpha).
     * @return resource|GdImage Cropped image (or original if nothing to trim).
     */
    private function trim_transparent_gd( $src ) {
        $w = imagesx( $src );
        $h = imagesy( $src );

        $min_x = $w; $min_y = $h; $max_x = 0; $max_y = 0;
        $found = false;

        // Alpha threshold: GD alpha 0 = fully opaque, 127 = fully transparent.
        // Kisi bhi pixel ko "visible" maante hain agar alpha < 120 (thoda
        // margin taaki halke anti-aliased edge pixels bhi count ho jayen).
        for ( $y = 0; $y < $h; $y++ ) {
            for ( $x = 0; $x < $w; $x++ ) {
                $rgba  = imagecolorat( $src, $x, $y );
                $alpha = ( $rgba >> 24 ) & 0x7F;
                if ( $alpha < 120 ) {
                    $found = true;
                    if ( $x < $min_x ) $min_x = $x;
                    if ( $x > $max_x ) $max_x = $x;
                    if ( $y < $min_y ) $min_y = $y;
                    if ( $y > $max_y ) $max_y = $y;
                }
            }
        }

        if ( ! $found ) {
            return $src; // Sab kuch transparent — kuch nahi kar sakte, original wapas.
        }

        $crop_w = $max_x - $min_x + 1;
        $crop_h = $max_y - $min_y + 1;

        // Agar koi meaningful padding hi nahi thi to original hi rehne do.
        if ( $crop_w >= $w && $crop_h >= $h ) {
            return $src;
        }

        $cropped = imagecreatetruecolor( $crop_w, $crop_h );
        imagealphablending( $cropped, false );
        imagesavealpha( $cropped, true );
        $transparent = imagecolorallocatealpha( $cropped, 0, 0, 0, 127 );
        imagefill( $cropped, 0, 0, $transparent );

        imagecopy( $cropped, $src, 0, 0, $min_x, $min_y, $crop_w, $crop_h );
        imagedestroy( $src );

        return $cropped;
    }

    /**
     * Apply watermark using GD library.
     *
     * @param string $image_path     Path to the image.
     * @param string $watermark_path Path to the watermark.
     * @param string $position       Position (top-left, top-right, bottom-left, bottom-right, center).
     * @param int    $opacity        Opacity percentage (0-100).
     * @param int    $size           Watermark size as percentage of image width.
     * @return bool True on success.
     */
    private function watermark_gd( $image_path, $watermark_path, $position, $opacity, $size, $margin = 10 ) {
        $image_info = getimagesize( $image_path );
        if ( ! $image_info ) {
            return false;
        }

        // Create image resource based on type
        switch ( $image_info[2] ) {
            case IMAGETYPE_JPEG:
                $image = imagecreatefromjpeg( $image_path );
                break;
            case IMAGETYPE_PNG:
                $image = imagecreatefrompng( $image_path );
                break;
            case IMAGETYPE_WEBP:
                if ( function_exists( 'imagecreatefromwebp' ) ) {
                    $image = imagecreatefromwebp( $image_path );
                } else {
                    return false;
                }
                break;
            default:
                return false;
        }

        if ( ! $image ) {
            return false;
        }

        // Load watermark (must be PNG for transparency)
        $watermark_info = getimagesize( $watermark_path );
        if ( ! $watermark_info ) {
            imagedestroy( $image );
            return false;
        }

        switch ( $watermark_info[2] ) {
            case IMAGETYPE_PNG:
                $watermark = imagecreatefrompng( $watermark_path );
                break;
            case IMAGETYPE_JPEG:
                $watermark = imagecreatefromjpeg( $watermark_path );
                break;
            default:
                imagedestroy( $image );
                return false;
        }

        if ( ! $watermark ) {
            imagedestroy( $image );
            return false;
        }

        // Transparent padding trim (see trim_transparent_gd() for why).
        // Sirf PNG ke liye zaroori hai (JPEG me alpha channel hota hi nahi).
        if ( $watermark_info[2] === IMAGETYPE_PNG ) {
            $watermark = $this->trim_transparent_gd( $watermark );
        }

        // Calculate watermark dimensions
        $img_w = imagesx( $image );
        $img_h = imagesy( $image );
        $wm_w  = imagesx( $watermark );
        $wm_h  = imagesy( $watermark );

        // Resize watermark based on size percentage
        $new_wm_w = (int) ( $img_w * $size / 100 );
        $new_wm_h = (int) ( $wm_h * ( $new_wm_w / $wm_w ) );

        $resized_wm = imagecreatetruecolor( $new_wm_w, $new_wm_h );
        imagealphablending( $resized_wm, false );
        imagesavealpha( $resized_wm, true );
        imagecopyresampled( $resized_wm, $watermark, 0, 0, 0, 0, $new_wm_w, $new_wm_h, $wm_w, $wm_h );

        AE_Logger::get_instance()->log( 0, 'image', sprintf(
            'Watermark (GD, trimmed): image=%dx%d, logo=%dx%d (%.0f%% width), opacity=%d%%',
            $img_w, $img_h, $new_wm_w, $new_wm_h, ( $new_wm_w / $img_w ) * 100, $opacity
        ) );

        // Calculate position using passed $margin (0 = corner touch, 10 = default padding)
        list( $x, $y ) = $this->calculate_position( $position, $img_w, $img_h, $new_wm_w, $new_wm_h, $margin );

        $opacity_pct = max( 0, min( 100, $opacity ) );

        // NOTE: imagecopymerge() yahan use NAHI karte — woh alpha-transparent PNGs
        // (jaise watermark logos jisme transparent background hota hai) ke saath
        // correctly kaam nahi karta. Yeh PHP GD ka jaana-mana issue hai: transparent
        // pixels black/grey ban jaate hain aur overall result washed-out/dull dikhta
        // hai, chahe opacity 100% set ho. Iski jagah hum watermark ke alpha channel
        // ko manually scale karte hain (jaisa Imagick automatically karta hai) aur
        // phir imagecopy() se composite karte hain — isse asli transparency
        // (logo ke around ka transparent background) sahi se preserve hoti hai
        // aur opacity bhi accurately apply hoti hai.
        if ( $opacity_pct < 100 ) {
            for ( $py = 0; $py < $new_wm_h; $py++ ) {
                for ( $px = 0; $px < $new_wm_w; $px++ ) {
                    $rgba = imagecolorat( $resized_wm, $px, $py );
                    $alpha = ( $rgba >> 24 ) & 0x7F; // 0 (opaque) - 127 (fully transparent)
                    $current_opacity = 1 - ( $alpha / 127 ); // 0 (transparent) - 1 (opaque)
                    $new_opacity = $current_opacity * ( $opacity_pct / 100 );
                    $new_alpha = (int) round( 127 * ( 1 - $new_opacity ) );
                    $new_alpha = max( 0, min( 127, $new_alpha ) );

                    $r = ( $rgba >> 16 ) & 0xFF;
                    $g = ( $rgba >> 8 ) & 0xFF;
                    $b = $rgba & 0xFF;

                    $new_color = imagecolorallocatealpha( $resized_wm, $r, $g, $b, $new_alpha );
                    imagesetpixel( $resized_wm, $px, $py, $new_color );
                }
            }
        }

        imagealphablending( $image, true );
        imagecopy( $image, $resized_wm, $x, $y, 0, 0, $new_wm_w, $new_wm_h );

        // Save the image
        $saved = false;
        switch ( $image_info[2] ) {
            case IMAGETYPE_JPEG:
                $saved = imagejpeg( $image, $image_path, 90 );
                break;
            case IMAGETYPE_PNG:
                $saved = imagepng( $image, $image_path, 8 );
                break;
            case IMAGETYPE_WEBP:
                if ( function_exists( 'imagewebp' ) ) {
                    $saved = imagewebp( $image, $image_path, 90 );
                }
                break;
        }

        // Cleanup
        imagedestroy( $image );
        imagedestroy( $watermark );
        imagedestroy( $resized_wm );

        return $saved;
    }

    /**
     * Apply watermark using Imagick.
     *
     * @param string $image_path     Path to the image.
     * @param string $watermark_path Path to the watermark.
     * @param string $position       Position string.
     * @param int    $opacity        Opacity percentage (0-100).
     * @param int    $size           Watermark size as percentage of image width.
     * @return bool True on success.
     */
    private function watermark_imagick( $image_path, $watermark_path, $position, $opacity, $size, $margin = 10 ) {
        try {
            $image = new Imagick( $image_path );
            $watermark = new Imagick( $watermark_path );

            // Logo PNG mein aksar visible logo ke around transparent padding
            // bachi hoti hai (jaise export/design tool se). Agar isse trim
            // nahi kiya to "size %" aur "margin" dono galat lagte hain —
            // size % poore canvas (padding samet) pe apply hota hai, aur
            // corner-flush karne pe bhi padding ki wajah se gap dikhta hai.
            // Yahan hum invisible border ko auto-detect karke kaat dete hain.
            $watermark->trimImage( 0 );
            $watermark->setImagePage( 0, 0, 0, 0 );

            // Resize watermark
            $img_w = $image->getImageWidth();
            $img_h = $image->getImageHeight();
            $new_wm_w = (int) ( $img_w * $size / 100 );

            $watermark->scaleImage( $new_wm_w, 0 );

            $wm_w = $watermark->getImageWidth();
            $wm_h = $watermark->getImageHeight();

            AE_Logger::get_instance()->log( 0, 'image', sprintf(
                'Watermark (Imagick, trimmed): image=%dx%d, logo=%dx%d (%.0f%% width), opacity=%d%%',
                $img_w, $img_h, $wm_w, $wm_h, ( $wm_w / $img_w ) * 100, $opacity
            ) );

            // Set opacity
            $watermark->evaluateImage( Imagick::EVALUATE_MULTIPLY, $opacity / 100, Imagick::CHANNEL_ALPHA );

            // Calculate position using passed $margin
            list( $x, $y ) = $this->calculate_position( $position, $img_w, $img_h, $wm_w, $wm_h, $margin );

            // Composite
            $image->compositeImage( $watermark, Imagick::COMPOSITE_OVER, $x, $y );

            // Save
            $image->writeImage( $image_path );

            $image->destroy();
            $watermark->destroy();

            return true;
        } catch ( Exception $e ) {
            AE_Logger::get_instance()->log( 0, 'error', 'Imagick watermark error: ' . $e->getMessage() );
            return false;
        }
    }

    /**
     * Calculate x,y position for watermark placement.
     *
     * @param string $position Position string.
     * @param int    $img_w    Image width.
     * @param int    $img_h    Image height.
     * @param int    $wm_w     Watermark width.
     * @param int    $wm_h     Watermark height.
     * @param int    $margin   Margin in pixels.
     * @return array [x, y] position.
     */
    private function calculate_position( $position, $img_w, $img_h, $wm_w, $wm_h, $margin ) {
        switch ( $position ) {
            case 'top-left':
                return array( $margin, $margin );

            case 'top-center':
                return array( (int) ( ( $img_w - $wm_w ) / 2 ), $margin );

            case 'top-right':
                return array( $img_w - $wm_w - $margin, $margin );

            case 'center-left':
                return array( $margin, (int) ( ( $img_h - $wm_h ) / 2 ) );

            case 'center':
                return array( (int) ( ( $img_w - $wm_w ) / 2 ), (int) ( ( $img_h - $wm_h ) / 2 ) );

            case 'center-right':
                return array( $img_w - $wm_w - $margin, (int) ( ( $img_h - $wm_h ) / 2 ) );

            case 'bottom-left':
                return array( $margin, $img_h - $wm_h - $margin );

            case 'bottom-center':
                return array( (int) ( ( $img_w - $wm_w ) / 2 ), $img_h - $wm_h - $margin );

            case 'bottom-right':
            default:
                return array( $img_w - $wm_w - $margin, $img_h - $wm_h - $margin );
        }
    }
}
