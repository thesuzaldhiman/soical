<?php
/**
 * AI Rewriter — content rewriting + translation via OpenAI (ChatGPT) or Anthropic (Claude) API.
 *
 * content_mode values:
 *   direct        → koi AI nahi, content as-is publish (English feed → English content)
 *   translate     → Hindi content → English translate (Google Translate free fallback)
 *   api_translate → API (Claude ya ChatGPT) se translate/rewrite karo
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_AI_Rewriter {

    /** @var AE_AI_Rewriter|null */
    private static $instance = null;

    /** @var array */
    private $settings;

    private function __construct() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function reload_settings() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Global AI enabled hai ya nahi (rewrite ke liye).
     */
    public function is_enabled() {
        return ! empty( $this->settings['ai_enabled'] ) && ! empty( $this->settings['ai_api_key'] );
    }

    /**
     * API provider: 'openai' ya 'anthropic'
     */
    public function get_provider() {
        return ! empty( $this->settings['ai_provider'] ) ? $this->settings['ai_provider'] : 'openai';
    }

    // -----------------------------------------------------------------------
    // Title rewrite (global AI on/off ke saath)
    // -----------------------------------------------------------------------

    public function rewrite_title( $title, $feed_id = 0 ) {
        if ( ! $this->is_enabled() || empty( $this->settings['ai_rewrite_title'] ) ) {
            return $title;
        }
        $system = "You are a professional content editor. Rewrite the given article title to be more engaging and SEO-optimized. Return ONLY the rewritten title, nothing else. Do not include any links, URLs, or markdown formatting.";
        $custom = ! empty( $this->settings['ai_custom_prompt'] ) ? $this->settings['ai_custom_prompt'] : '';
        if ( $custom ) {
            $system .= "\n\nAdditional instructions: " . $custom;
        }
        $result = $this->call_api( $system, "Rewrite this title: " . $title );
        if ( is_wp_error( $result ) ) {
            AE_Logger::get_instance()->log( $feed_id, 'error', 'AI title rewrite failed: ' . $result->get_error_message() );
            return $title;
        }
        $out = $this->clean_ai_output( $result );
        if ( empty( $out ) ) {
            return $title;
        }
        AE_Logger::get_instance()->log( $feed_id, 'ai', sprintf( 'Title rewritten: "%s" → "%s"', $title, $out ) );
        return $out;
    }

    public function rewrite_content( $content, $title = '', $feed_id = 0 ) {
        if ( ! $this->is_enabled() || empty( $this->settings['ai_rewrite_content'] ) ) {
            return $content;
        }
        $system = "You are a professional content writer and editor. Rewrite the given article content while preserving the original meaning and key information. Follow these rules strictly:\n1. Do NOT include any links or URLs in your output.\n2. Preserve the heading structure (H1, H2, H3, etc.) where applicable.\n3. Use clean HTML formatting with proper paragraphs.\n4. Maintain factual accuracy.\n5. Output should be well-structured and readable.\n6. Do not add conclusions or meta-commentary about the rewriting.";
        $custom = ! empty( $this->settings['ai_custom_prompt'] ) ? $this->settings['ai_custom_prompt'] : '';
        if ( $custom ) {
            $system .= "\n\nAdditional instructions: " . $custom;
        }
        $msg = '';
        if ( ! empty( $title ) ) {
            $msg .= "Article Title: " . $title . "\n\n";
        }
        $msg .= "Article Content:\n" . wp_strip_all_tags( $content );
        if ( strlen( $msg ) > 12000 ) {
            $msg = substr( $msg, 0, 12000 );
        }
        $result = $this->call_api( $system, $msg );
        if ( is_wp_error( $result ) ) {
            AE_Logger::get_instance()->log( $feed_id, 'error', 'AI content rewrite failed: ' . $result->get_error_message() );
            return $content;
        }
        $out = $this->clean_ai_output( $result );
        if ( empty( $out ) || str_word_count( wp_strip_all_tags( $out ) ) < 20 ) {
            AE_Logger::get_instance()->log( $feed_id, 'error', 'AI rewrite insufficient content, using original.' );
            return $content;
        }
        if ( strpos( $out, '<p>' ) === false ) {
            $out = wpautop( $out );
        }
        AE_Logger::get_instance()->log( $feed_id, 'ai', 'Content rewritten successfully via AI.' );
        return $out;
    }

    // -----------------------------------------------------------------------
    // TRANSLATION METHODS
    // -----------------------------------------------------------------------

    /**
     * Hindi (ya koi bhi non-English) content → English translate karo via API.
     * api_translate mode ke liye use hota hai.
     *
     * @param string $title    Original title.
     * @param string $content  Original content (HTML ok).
     * @param int    $feed_id  Feed ID for logging.
     * @return array ['title' => ..., 'content' => ...]
     */
    public function translate_via_api( $title, $content, $feed_id = 0 ) {
        $logger = AE_Logger::get_instance();

        if ( empty( $this->settings['ai_api_key'] ) ) {
            $logger->log( $feed_id, 'error', 'API Translate: No API key configured.' );
            return array( 'title' => $title, 'content' => $content );
        }

        $custom = ! empty( $this->settings['ai_custom_prompt'] ) ? $this->settings['ai_custom_prompt'] : '';

        // --- Translate Title ---
        $title_system = "You are a professional translator and SEO expert. Translate the given news article title to English. Make it engaging and SEO-optimized. Return ONLY the translated/rewritten English title, nothing else.";
        if ( $custom ) {
            $title_system .= "\n\nAdditional instructions: " . $custom;
        }
        $title_result = $this->call_api( $title_system, "Translate this title to English: " . $title );
        if ( ! is_wp_error( $title_result ) ) {
            $new_title = $this->clean_ai_output( $title_result );
            if ( ! empty( $new_title ) ) {
                $logger->log( $feed_id, 'ai', sprintf( 'Title translated: "%s" → "%s"', $title, $new_title ) );
                $title = $new_title;
            }
        } else {
            $logger->log( $feed_id, 'error', 'API Translate title failed: ' . $title_result->get_error_message() );
        }

        // --- Translate Content ---
        $content_system = "You are a professional translator and content writer. Translate the given news article content to English. Follow these rules:\n1. Translate accurately while making it read naturally in English.\n2. Do NOT include any links or URLs.\n3. Use clean HTML formatting with proper paragraphs (<p> tags).\n4. Preserve heading structure if present.\n5. Return ONLY the translated English content, no commentary.";
        if ( $custom ) {
            $content_system .= "\n\nAdditional instructions: " . $custom;
        }

        $plain_content = wp_strip_all_tags( $content );
        if ( strlen( $plain_content ) > 10000 ) {
            $plain_content = substr( $plain_content, 0, 10000 );
        }

        $content_msg = "Translate this article content to English:\n\n" . $plain_content;
        $content_result = $this->call_api( $content_system, $content_msg );

        if ( ! is_wp_error( $content_result ) ) {
            $new_content = $this->clean_ai_output( $content_result );
            if ( ! empty( $new_content ) && str_word_count( wp_strip_all_tags( $new_content ) ) >= 20 ) {
                if ( strpos( $new_content, '<p>' ) === false ) {
                    $new_content = wpautop( $new_content );
                }
                $logger->log( $feed_id, 'ai', 'Content translated to English via API.' );
                $content = $new_content;
            }
        } else {
            $logger->log( $feed_id, 'error', 'API Translate content failed: ' . $content_result->get_error_message() );
        }

        return array( 'title' => $title, 'content' => $content );
    }

    /**
     * Free Google Translate fallback (translate mode — no API key needed).
     * Hindi → English using Google Translate unofficial endpoint.
     *
     * @param string $text     Text to translate.
     * @param string $from     Source language code (default 'hi').
     * @param string $to       Target language code (default 'en').
     * @return string          Translated text or original on failure.
     */
    public function google_translate( $text, $from = 'hi', $to = 'en' ) {
        if ( empty( $text ) ) {
            return $text;
        }
        // Chunk large text
        $chunks = array();
        $words  = explode( ' ', $text );
        $chunk  = '';
        foreach ( $words as $word ) {
            if ( strlen( $chunk ) + strlen( $word ) > 4000 ) {
                $chunks[] = $chunk;
                $chunk    = $word;
            } else {
                $chunk .= ( $chunk ? ' ' : '' ) . $word;
            }
        }
        if ( $chunk ) {
            $chunks[] = $chunk;
        }

        $translated = '';
        foreach ( $chunks as $c ) {
            $url      = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' . $from . '&tl=' . $to . '&dt=t&q=' . rawurlencode( $c );
            $response = wp_remote_get( $url, array( 'timeout' => 15 ) );
            if ( is_wp_error( $response ) ) {
                $translated .= ' ' . $c; // fallback
                continue;
            }
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );
            $part = '';
            if ( isset( $data[0] ) && is_array( $data[0] ) ) {
                foreach ( $data[0] as $seg ) {
                    if ( isset( $seg[0] ) ) {
                        $part .= $seg[0];
                    }
                }
            }
            $translated .= ( $translated ? ' ' : '' ) . ( $part ?: $c );
        }

        return trim( $translated ) ?: $text;
    }

    // -----------------------------------------------------------------------
    // INTERNAL: API call dispatcher
    // -----------------------------------------------------------------------

    private function call_api( $system_prompt, $user_message ) {
        $provider = $this->get_provider();
        if ( $provider === 'anthropic' ) {
            return $this->call_anthropic_api( $system_prompt, $user_message );
        }
        return $this->call_openai_api( $system_prompt, $user_message );
    }

    private function call_openai_api( $system_prompt, $user_message ) {
        $api_key = $this->settings['ai_api_key'];
        $model   = ! empty( $this->settings['ai_model'] ) ? $this->settings['ai_model'] : 'gpt-3.5-turbo';

        $body = array(
            'model'       => $model,
            'messages'    => array(
                array( 'role' => 'system', 'content' => $system_prompt ),
                array( 'role' => 'user',   'content' => $user_message ),
            ),
            'temperature' => 0.7,
            'max_tokens'  => 2000,
        );

        $response = wp_remote_post(
            'https://api.openai.com/v1/chat/completions',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 60,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $status = wp_remote_retrieve_response_code( $response );
        $data   = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $status !== 200 ) {
            $msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'Unknown API error (HTTP ' . $status . ')';
            return new WP_Error( 'api_error', $msg );
        }
        if ( empty( $data['choices'][0]['message']['content'] ) ) {
            return new WP_Error( 'empty_response', 'OpenAI returned empty response.' );
        }
        return trim( $data['choices'][0]['message']['content'] );
    }

    private function call_anthropic_api( $system_prompt, $user_message ) {
        $api_key = $this->settings['ai_api_key'];
        $model   = ! empty( $this->settings['ai_model'] ) ? $this->settings['ai_model'] : 'claude-haiku-4-5-20251001';

        $body = array(
            'model'      => $model,
            'max_tokens' => 2000,
            'system'     => $system_prompt,
            'messages'   => array(
                array( 'role' => 'user', 'content' => $user_message ),
            ),
        );

        $response = wp_remote_post(
            'https://api.anthropic.com/v1/messages',
            array(
                'headers' => array(
                    'x-api-key'         => $api_key,
                    'anthropic-version' => '2023-06-01',
                    'Content-Type'      => 'application/json',
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 60,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $status = wp_remote_retrieve_response_code( $response );
        $data   = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $status !== 200 ) {
            $msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'Unknown Anthropic API error (HTTP ' . $status . ')';
            return new WP_Error( 'api_error', $msg );
        }
        if ( empty( $data['content'][0]['text'] ) ) {
            return new WP_Error( 'empty_response', 'Claude returned empty response.' );
        }
        return trim( $data['content'][0]['text'] );
    }

    private function clean_ai_output( $text ) {
        $text = preg_replace( '/https?:\/\/\S+/i', '', $text );
        $text = preg_replace( '/\[([^\]]+)\]\([^)]+\)/', '$1', $text );
        $text = preg_replace( '/<a[^>]*>(.*?)<\/a>/is', '$1', $text );
        $text = trim( $text, '"\'' );
        $text = preg_replace( '/\s+/', ' ', $text );
        return trim( $text );
    }

    // -----------------------------------------------------------------------
    // Test connection
    // -----------------------------------------------------------------------

    public function test_connection() {
        if ( empty( $this->settings['ai_api_key'] ) ) {
            return new WP_Error( 'no_key', 'No API key configured.' );
        }
        $result = $this->call_api( 'You are a helpful assistant.', 'Reply with exactly: "Connection successful"' );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return array(
            'status'  => 'success',
            'message' => 'API connection working (' . $this->get_provider() . '). Response: ' . $result,
        );
    }
}
