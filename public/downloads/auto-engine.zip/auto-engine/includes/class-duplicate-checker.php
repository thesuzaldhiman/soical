<?php
/**
 * Duplicate Checker — prevents duplicate posts from being published.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Duplicate_Checker {

    /**
     * Singleton instance.
     *
     * @var AE_Duplicate_Checker|null
     */
    private static $instance = null;

    /**
     * Processed items table.
     *
     * @var string
     */
    private $table;

    /**
     * Constructor.
     */
    private function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'ae_processed';
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Duplicate_Checker
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Generate a hash for deduplication.
     *
     * @param string $title Item title.
     * @param string $link  Item link/URL.
     * @return string SHA-256 hash.
     */
    public function generate_hash( $title, $link ) {
        $normalized_title = strtolower( trim( $title ) );
        $normalized_link  = strtolower( trim( $link ) );
        return hash( 'sha256', $normalized_title . '|' . $normalized_link );
    }

    /**
     * Check if an item is a duplicate.
     *
     * @param string $title Item title.
     * @param string $link  Item link/URL.
     * @return bool True if duplicate exists.
     */
    public function is_duplicate( $title, $link ) {
        global $wpdb;

        $hash = $this->generate_hash( $title, $link );

        // Check in processed items table only
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table} WHERE item_hash = %s",
                $hash
            )
        );

        return $exists > 0;
    }

    /**
     * Mark an item as processed.
     *
     * @param int    $feed_id Feed ID.
     * @param string $title   Item title.
     * @param string $link    Item link/URL.
     * @param int    $post_id Published WordPress post ID.
     * @return bool True on success.
     */
    public function mark_processed( $feed_id, $title, $link, $post_id = 0 ) {
        global $wpdb;

        $hash = $this->generate_hash( $title, $link );

        $result = $wpdb->replace(
            $this->table,
            array(
                'feed_id'    => absint( $feed_id ),
                'item_hash'  => $hash,
                'title'      => sanitize_text_field( $title ),
                'post_id'    => absint( $post_id ),
                'created_at' => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%d', '%s' )
        );

        return false !== $result;
    }

    /**
     * Get total processed count.
     *
     * @param int $feed_id Optional feed ID filter.
     * @return int
     */
    public function get_processed_count( $feed_id = 0 ) {
        global $wpdb;

        if ( $feed_id > 0 ) {
            return (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table} WHERE feed_id = %d",
                    $feed_id
                )
            );
        }

        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table}" );
    }

    /**
     * Get published post count (items with a post_id).
     *
     * @return int
     */
    public function get_published_count() {
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table} WHERE post_id > 0"
        );
    }

    /**
     * Clean up old processed entries.
     *
     * @param int $days Keep entries newer than this many days.
     * @return int Number of entries deleted.
     */
    public function cleanup( $days = 90 ) {
        global $wpdb;
        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
                absint( $days )
            )
        );
    }
}
