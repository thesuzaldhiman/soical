<?php
/**
 * Rate Limiter — controls publishing rate per hour/day.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Rate_Limiter {

    /**
     * Singleton instance.
     *
     * @var AE_Rate_Limiter|null
     */
    private static $instance = null;

    /**
     * Plugin settings.
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor.
     */
    private function __construct() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Rate_Limiter
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Reload settings.
     */
    public function reload_settings() {
        $this->settings = get_option( 'auto_engine_settings', array() );
    }

    /**
     * Check if publishing is allowed under current rate limits.
     *
     * @return bool True if publishing is allowed.
     */
    public function can_publish() {
        $hourly_limit = isset( $this->settings['rate_limit_hour'] ) ? absint( $this->settings['rate_limit_hour'] ) : 0;
        $daily_limit  = isset( $this->settings['rate_limit_day'] ) ? absint( $this->settings['rate_limit_day'] ) : 0;

        // Check hourly limit
        if ( $hourly_limit > 0 ) {
            $hourly_count = $this->get_hourly_count();
            if ( $hourly_count >= $hourly_limit ) {
                AE_Logger::get_instance()->log( 0, 'info', sprintf( 'Hourly rate limit reached (%d/%d).', $hourly_count, $hourly_limit ) );
                return false;
            }
        }

        // Check daily limit
        if ( $daily_limit > 0 ) {
            $daily_count = $this->get_daily_count();
            if ( $daily_count >= $daily_limit ) {
                AE_Logger::get_instance()->log( 0, 'info', sprintf( 'Daily rate limit reached (%d/%d).', $daily_count, $daily_limit ) );
                return false;
            }
        }

        return true;
    }

    /**
     * Record a publish event.
     */
    public function record_publish() {
        // Increment hourly counter
        $hourly_key   = 'ae_rate_hourly_' . gmdate( 'YmdH' );
        $hourly_count = get_transient( $hourly_key );
        if ( false === $hourly_count ) {
            set_transient( $hourly_key, 1, HOUR_IN_SECONDS );
        } else {
            set_transient( $hourly_key, $hourly_count + 1, HOUR_IN_SECONDS );
        }

        // Increment daily counter
        $daily_key   = 'ae_rate_daily_' . gmdate( 'Ymd' );
        $daily_count = get_transient( $daily_key );
        if ( false === $daily_count ) {
            set_transient( $daily_key, 1, DAY_IN_SECONDS );
        } else {
            set_transient( $daily_key, $daily_count + 1, DAY_IN_SECONDS );
        }
    }

    /**
     * Get current hourly publish count.
     *
     * @return int
     */
    public function get_hourly_count() {
        $key = 'ae_rate_hourly_' . gmdate( 'YmdH' );
        $count = get_transient( $key );
        return $count ? (int) $count : 0;
    }

    /**
     * Get current daily publish count.
     *
     * @return int
     */
    public function get_daily_count() {
        $key = 'ae_rate_daily_' . gmdate( 'Ymd' );
        $count = get_transient( $key );
        return $count ? (int) $count : 0;
    }

    /**
     * Get remaining publish capacity.
     *
     * @return array {
     *     @type int $hourly_remaining Hours remaining (0 = unlimited).
     *     @type int $daily_remaining  Daily remaining (0 = unlimited).
     * }
     */
    public function get_remaining() {
        $hourly_limit = isset( $this->settings['rate_limit_hour'] ) ? absint( $this->settings['rate_limit_hour'] ) : 0;
        $daily_limit  = isset( $this->settings['rate_limit_day'] ) ? absint( $this->settings['rate_limit_day'] ) : 0;

        return array(
            'hourly_remaining' => $hourly_limit > 0 ? max( 0, $hourly_limit - $this->get_hourly_count() ) : -1,
            'daily_remaining'  => $daily_limit > 0 ? max( 0, $daily_limit - $this->get_daily_count() ) : -1,
        );
    }
}
