<?php
/**
 * Feed Fetcher — fetches items from RSS feeds using SimplePie.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Feed_Fetcher {

    /**
     * Singleton instance.
     *
     * @var AE_Feed_Fetcher|null
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return AE_Feed_Fetcher
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Fetch items from a feed.
     *
     * @param object $feed Feed database object.
     * @return array Array of structured feed items.
     */
    public function fetch( $feed ) {
        $logger = AE_Logger::get_instance();
        $url    = $feed->feed_url;

        $logger->log( $feed->id, 'fetch', sprintf( 'Fetching feed: %s', $url ) );

        $body = $this->fetch_url( $url );

        if ( is_wp_error( $body ) ) {
            $logger->log( $feed->id, 'error', sprintf( 'Feed fetch error: %s', $body->get_error_message() ) );
            return array();
        }

        // SimplePie se manually parse karo
        // SimplePie load karo
        if ( ! class_exists( 'SimplePie' ) ) {
            require_once ABSPATH . WPINC . '/class-simplepie.php';
        }

        $rss = new SimplePie();
        $rss->set_raw_data( $body );
        $rss->enable_cache( false );
        $rss->force_feed( true );
        $rss->set_stupidly_fast( true );
        $rss->init();

        if ( $rss->error() ) {
            $logger->log( $feed->id, 'error', sprintf( 'Feed parse error: %s', $rss->error() ) );
            return array();
        }

        $max_items = $rss->get_item_quantity( 50 );
        $rss_items = $rss->get_items( 0, $max_items );

        if ( empty( $rss_items ) ) {
            $logger->log( $feed->id, 'fetch', 'No items found in feed.' );
            return array();
        }

        $items = array();
        foreach ( $rss_items as $rss_item ) {
            $item = $this->parse_item( $rss_item, $feed );
            if ( $item ) {
                $items[] = $item;
            }
        }

        $logger->log( $feed->id, 'fetch', sprintf( 'Fetched %d items from feed.', count( $items ) ) );

        AE_Feed_Manager::get_instance()->update_last_fetched( $feed->id );

        return $items;
    }

    /**
     * Fetch a URL with multiple fallback strategies.
     * Kuch APIs browser simulation chahte hain — yeh function multiple strategies try karta hai.
     *
     * @param string $url Feed URL.
     * @return string|WP_Error Raw body or error.
     */
    private function fetch_url( $url ) {
        $strategies = array(
            // Strategy 1: Chrome browser simulation
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'headers'    => array(
                    'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Accept-Language' => 'hi-IN,hi;q=0.9,en-IN;q=0.8,en;q=0.7',
                    'Accept-Encoding' => 'gzip, deflate, br',
                    'Referer'         => ( parse_url( $url, PHP_URL_SCHEME ) ?: 'https' ) . '://' . ( parse_url( $url, PHP_URL_HOST ) ?: '' ) . '/',
                    'Cache-Control'   => 'no-cache',
                    'Pragma'          => 'no-cache',
                ),
            ),
            // Strategy 2: Firefox simulation
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
                'headers'    => array(
                    'Accept'          => 'application/rss+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language' => 'hi,en;q=0.5',
                    'Referer'         => home_url(),
                    'Cache-Control'   => 'max-age=0',
                ),
            ),
            // Strategy 3: Generic RSS reader
            array(
                'user-agent' => 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)',
                'headers'    => array(
                    'Accept' => 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*',
                ),
            ),
        );

        foreach ( $strategies as $strategy ) {
            $response = wp_remote_get( $url, array(
                'timeout'    => 20,
                'user-agent' => $strategy['user-agent'],
                'headers'    => $strategy['headers'],
                'sslverify'  => false,
                'redirection' => 5,
            ) );

            if ( is_wp_error( $response ) ) {
                continue;
            }

            $code = wp_remote_retrieve_response_code( $response );
            if ( $code === 200 ) {
                $body = wp_remote_retrieve_body( $response );
                if ( ! empty( $body ) ) {
                    return $body;
                }
            }
        }

        return new WP_Error( 'fetch_failed', sprintf( 'Feed fetch failed. Server ne request block kar di (tried %d strategies).', count( $strategies ) ) );
    }

    /**
     * Parse a single SimplePie item into a structured array.
     *
     * @param SimplePie_Item $rss_item SimplePie item.
     * @param object         $feed     Feed database object.
     * @return array|false Structured item or false on failure.
     */
    private function parse_item( $rss_item, $feed ) {
        $title = $rss_item->get_title();
        $title = trim( wp_strip_all_tags( $title ) );
        $title = html_entity_decode( $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        if ( empty( $title ) ) {
            return false;
        }

        $content = $rss_item->get_content();
        $link    = $rss_item->get_permalink();
        $date    = $rss_item->get_date( 'Y-m-d H:i:s' );
        $author  = '';

        $author_obj = $rss_item->get_author();
        if ( $author_obj ) {
            $author = $author_obj->get_name();
        }

        // Extract images
        $images = $this->extract_images( $rss_item, $content );

        // Determine featured image
        $featured_image = ! empty( $images ) ? $images[0] : '';

        return array(
            'title'          => $title,
            'content'        => $content,
            'link'           => $link,
            'date'           => $date,
            'author'         => $author,
            'featured_image' => $featured_image,
            'all_images'     => $images,
            'tags'           => array(),
            'feed_id'        => $feed->id,
            'category_id'    => $feed->category_id,
            'image_mode'     => $feed->image_mode,
        );
    }

    /**
     * Extract images from a feed item.
     * Checks content, enclosures, and media namespace.
     *
     * @param SimplePie_Item $rss_item SimplePie item.
     * @param string         $content  Item content HTML.
     * @return array Array of image URLs.
     */
    private function extract_images( $rss_item, $content ) {
        $images = array();

        // 1. Check media:thumbnail
        $thumb = $rss_item->get_item_tags( 'http://search.yahoo.com/mrss/', 'thumbnail' );
        if ( $thumb && isset( $thumb[0]['attribs']['']['url'] ) ) {
            $images[] = esc_url_raw( $thumb[0]['attribs']['']['url'] );
        }

        // 2. Check media:content
        $media = $rss_item->get_item_tags( 'http://search.yahoo.com/mrss/', 'content' );
        if ( $media ) {
            foreach ( $media as $m ) {
                if ( isset( $m['attribs']['']['url'] ) ) {
                    $medium = isset( $m['attribs']['']['medium'] ) ? $m['attribs']['']['medium'] : '';
                    if ( $medium === 'image' || empty( $medium ) ) {
                        $url = esc_url_raw( $m['attribs']['']['url'] );
                        if ( ! in_array( $url, $images, true ) ) {
                            $images[] = $url;
                        }
                    }
                }
            }
        }

        // 3. Check enclosures
        $enclosure = $rss_item->get_enclosure();
        if ( $enclosure && $enclosure->get_link() ) {
            $type = $enclosure->get_type();
            if ( $type && strpos( $type, 'image' ) !== false ) {
                $url = esc_url_raw( $enclosure->get_link() );
                if ( ! in_array( $url, $images, true ) ) {
                    $images[] = $url;
                }
            }
        }

        // 4. Extract from content HTML
        if ( ! empty( $content ) ) {
            if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $matches ) ) {
                foreach ( $matches[1] as $img_url ) {
                    $img_url = esc_url_raw( $img_url );
                    if ( ! empty( $img_url ) && ! in_array( $img_url, $images, true ) ) {
                        $images[] = $img_url;
                    }
                }
            }
        }

        return $images;
    }
}
