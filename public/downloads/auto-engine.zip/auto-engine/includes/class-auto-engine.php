<?php
/**
 * Auto Engine — core orchestrator that ties all modules together.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Auto_Engine {

    /**
     * Singleton instance.
     *
     * @var AE_Auto_Engine|null
     */
    private static $instance = null;

    /**
     * Logger instance.
     *
     * @var AE_Logger
     */
    private $logger;

    /**
     * Feed manager instance.
     *
     * @var AE_Feed_Manager
     */
    private $feed_manager;

    /**
     * Feed fetcher instance.
     *
     * @var AE_Feed_Fetcher
     */
    private $fetcher;

    /**
     * Content cleaner instance.
     *
     * @var AE_Content_Cleaner
     */
    private $cleaner;

    /**
     * Duplicate checker instance.
     *
     * @var AE_Duplicate_Checker
     */
    private $dedup;

    /**
     * AI rewriter instance.
     *
     * @var AE_AI_Rewriter
     */
    private $ai;

    /**
     * Publisher instance.
     *
     * @var AE_Publisher
     */
    private $publisher;

    /**
     * Rate limiter instance.
     *
     * @var AE_Rate_Limiter
     */
    private $rate_limiter;

    /**
     * Plugin settings.
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor.
     */
    private function __construct() {
        $this->settings     = get_option( 'auto_engine_settings', array() );
        // Existing keywords normalize karo (agar pehle mixed-case save hue hain)
        if ( ! empty( $this->settings['title_filter_keywords'] ) && is_array( $this->settings['title_filter_keywords'] ) ) {
            $this->settings['title_filter_keywords'] = array_values(
                array_unique( array_map( 'mb_strtolower', array_filter( $this->settings['title_filter_keywords'] ) ) )
            );
        }
        $this->logger       = AE_Logger::get_instance();
        $this->feed_manager = AE_Feed_Manager::get_instance();
        $this->fetcher      = AE_Feed_Fetcher::get_instance();
        $this->cleaner      = AE_Content_Cleaner::get_instance();
        $this->dedup        = AE_Duplicate_Checker::get_instance();
        $this->ai           = AE_AI_Rewriter::get_instance();
        $this->publisher    = AE_Publisher::get_instance();
        $this->rate_limiter = AE_Rate_Limiter::get_instance();

        // Initialize cron handler
        AE_Cron_Handler::get_instance();
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Auto_Engine
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Process all active feeds — the main pipeline.
     *
     * @param int $specific_feed_id Optional. Process only this feed ID.
     * @return array Results summary.
     */
    public function process_feeds( $specific_feed_id = 0, $bulk_mode = false ) {
        $this->logger->log( 0, 'fetch', 'Starting feed processing cycle...' );

        $results = array(
            'fetched'    => 0,
            'published'  => 0,
            'duplicates' => 0,
            'skipped'    => 0,
            'errors'     => 0,
        );

        // Get feeds to process
        if ( $specific_feed_id > 0 ) {
            $feed = $this->feed_manager->get_feed( $specific_feed_id );
            $feeds = $feed ? array( $feed ) : array();
        } else {
            $feeds = $this->feed_manager->get_feeds( array( 'active_only' => true ) );
        }

        if ( empty( $feeds ) ) {
            $this->logger->log( 0, 'info', 'No active feeds to process.' );
            return $results;
        }

        foreach ( $feeds as $feed ) {
            $feed_results = $this->process_single_feed( $feed, $bulk_mode );

            $results['fetched']    += $feed_results['fetched'];
            $results['published']  += $feed_results['published'];
            $results['duplicates'] += $feed_results['duplicates'];
            $results['skipped']    += $feed_results['skipped'];
            $results['errors']     += $feed_results['errors'];
        }

        $this->logger->log(
            0,
            'fetch',
            sprintf(
                'Processing cycle complete. Fetched: %d, Published: %d, Duplicates: %d, Skipped: %d, Errors: %d',
                $results['fetched'],
                $results['published'],
                $results['duplicates'],
                $results['skipped'],
                $results['errors']
            )
        );

        return $results;
    }

    /**
     * Process a single feed through the full pipeline.
     *
     * Flow:
     * 1. Feed fetch karo
     * 2. Aaj (IST) ki unpublished news → newest first → 1 publish karo
     * 3. Aaj ki koi news nahi → purani unpublished news → new-to-old → 1 publish karo
     * 4. Har cycle mein guaranteed 1 post (jab tak kuch unpublished bacha ho)
     *
     * @param object $feed Feed database object.
     * @return array Results for this feed.
     */
    private function process_single_feed( $feed, $bulk_mode = false ) {
        $results = array(
            'fetched'    => 0,
            'published'  => 0,
            'duplicates' => 0,
            'skipped'    => 0,
            'errors'     => 0,
        );

        // Step 1: Fetch items
        $items = $this->fetcher->fetch( $feed );
        $results['fetched'] = count( $items );

        if ( empty( $items ) ) {
            return $results;
        }

        // ── Aaj ki aur purani news alag karo (24-hour limit ke saath) ────────
        $ist_tz      = new DateTimeZone( 'Asia/Kolkata' );
        $now_ist     = new DateTime( 'now', $ist_tz );
        $today_ist   = $now_ist->format( 'Y-m-d' );

        // Settings se max_age_hours lo (default: 24 ghante)
        $max_age_hours = isset( $this->settings['max_content_age_hours'] )
            ? max( 1, absint( $this->settings['max_content_age_hours'] ) )
            : 24;

        $todays_items = array();
        $older_items  = array(); // Sirf last N ghanton ki purani news

        foreach ( $items as $item ) {
            if ( empty( $item['date'] ) ) {
                // Date nahi hai → skip (unknown age content publish mat karo)
                continue;
            }
            try {
                $item_dt   = new DateTime( $item['date'], $ist_tz );
                $item_date = $item_dt->format( 'Y-m-d' );

                // Age check: item kitna purana hai (ghanton mein)
                $age_seconds = $now_ist->getTimestamp() - $item_dt->getTimestamp();
                $age_hours   = $age_seconds / 3600;

                // Max age se zyada purana → completely skip karo
                if ( $age_hours > $max_age_hours ) {
                    continue;
                }

                if ( $item_date === $today_ist ) {
                    $todays_items[] = $item;
                } else {
                    // Purana hai lekin max_age_hours ke andar → fallback ke liye rakhte hain
                    $older_items[] = $item;
                }
            } catch ( Exception $e ) {
                // Date parse nahi hui → skip (safe side pe rehna better hai)
                continue;
            }
        }

        // Aaj ki news → newest first
        if ( ! empty( $todays_items ) ) {
            usort( $todays_items, function( $a, $b ) {
                return strtotime( $b['date'] ) - strtotime( $a['date'] );
            } );
        }

        // Purani (fallback) news → bhi newest first
        if ( ! empty( $older_items ) ) {
            usort( $older_items, function( $a, $b ) {
                return strtotime( $b['date'] ) - strtotime( $a['date'] );
            } );
        }

        // Merge: pehle aaj ki, phir last N ghanton ki purani — strict age-gated fallback
        $items_to_process = array_merge( $todays_items, $older_items );

        // ── Random Shuffle (multi-site staggering) ─────────────────────────
        // Same feed jab multiple sites pe configured ho, to normally sab sites
        // "newest first" order follow karke same article same time pe publish
        // karte hain. Yahan top-N naye items ke pool ko shuffle kar dete hain
        // taaki har site alag-alag item pehle pick kare — result: same article
        // alag-alag sites pe alag time pe aayega, sab jagah ek sath nahi.
        $shuffle_enabled = ! empty( $this->settings['shuffle_recent_items'] );
        if ( $shuffle_enabled && count( $items_to_process ) > 1 ) {
            $pool_size = isset( $this->settings['shuffle_pool_size'] )
                ? max( 2, absint( $this->settings['shuffle_pool_size'] ) )
                : 5;
            $pool_size = min( $pool_size, count( $items_to_process ) );

            $pool = array_slice( $items_to_process, 0, $pool_size );
            $rest = array_slice( $items_to_process, $pool_size );

            // Fisher-Yates shuffle (wp_rand secure aur naya seed har call pe)
            for ( $i = count( $pool ) - 1; $i > 0; $i-- ) {
                $j = wp_rand( 0, $i );
                $tmp        = $pool[ $i ];
                $pool[ $i ] = $pool[ $j ];
                $pool[ $j ] = $tmp;
            }

            $items_to_process = array_merge( $pool, $rest );
        }
        // ─────────────────────────────────────────────────────────────────────

        // Agar koi bhi valid item nahi mila → feed skip karo
        if ( empty( $items_to_process ) ) {
            $this->logger->log( $feed->id, 'info', sprintf(
                'Koi publishable item nahi mila (sabhi items %d ghante se zyada purane hain).',
                $max_age_hours
            ) );
            return $results;
        }
        // ─────────────────────────────────────────────────────────────────────

        foreach ( $items_to_process as $item ) {

            // Bulk mode (Auto Fetch Schedule) mein koi per-feed limit nahi — saare items publish karo
            // Legacy mode mein sirf 1 post per feed per cycle
            if ( ! $bulk_mode && $results['published'] >= 1 ) {
                break;
            }

            // Rate limit check
            if ( ! $this->rate_limiter->can_publish() ) {
                $this->logger->log( $feed->id, 'info', 'Rate limit reached, stopping processing.' );
                break;
            }

            // Duplicate check
            if ( $this->dedup->is_duplicate( $item['title'], $item['link'] ) ) {
                $results['duplicates']++;
                continue;
            }

            // Title keyword filter
            $filter_keywords = isset( $this->settings['title_filter_keywords'] ) ? $this->settings['title_filter_keywords'] : array();
            if ( ! empty( $filter_keywords ) ) {
                $title_lower = mb_strtolower( $item['title'] );
                foreach ( $filter_keywords as $kw ) {
                    if ( $kw !== '' && mb_strpos( $title_lower, mb_strtolower( $kw ) ) !== false ) {
                        $this->logger->log( $feed->id, 'info', sprintf( 'Skipped (title filter "%s"): "%s"', $kw, $item['title'] ) );
                        $results['skipped']++;
                        continue 2;
                    }
                }
            }

            // Content clean
            $cleaned_content = $this->cleaner->clean( $item['content'], $item['image_mode'] );

            // Short-content scraping fallback — kuch feeds (e.g. onmanorama.com)
            // sirf chhota teaser/summary deti hain, poora article RSS mein nahi
            // hota. Agar content threshold se kam hai, article URL se full
            // content scrape karne ki koshish karo.
            $scrape_enabled    = isset( $this->settings['scrape_short_content'] ) ? (bool) $this->settings['scrape_short_content'] : true;
            $scrape_threshold  = isset( $this->settings['scrape_min_word_count'] ) ? absint( $this->settings['scrape_min_word_count'] ) : 40;
            $pre_scrape_words  = $this->cleaner->get_word_count( $cleaned_content );

            if ( $scrape_enabled && $scrape_threshold > 0 && $pre_scrape_words < $scrape_threshold && ! empty( $item['link'] ) ) {
                $scraped_html = $this->fetcher->fetch_full_article( $item['link'] );
                if ( ! empty( $scraped_html ) ) {
                    $scraped_clean = $this->cleaner->clean( $scraped_html, $item['image_mode'] );
                    $scraped_words = $this->cleaner->get_word_count( $scraped_clean );
                    // Sirf tab use karo jab scrape se feed se zyada content mila ho.
                    if ( $scraped_words > $pre_scrape_words ) {
                        $this->logger->log( $feed->id, 'info', sprintf(
                            'Short feed content (%d words) — scraped full article from URL (%d words): "%s"',
                            $pre_scrape_words, $scraped_words, $item['title']
                        ) );
                        $cleaned_content = $scraped_clean;
                    } else {
                        $this->logger->log( $feed->id, 'info', sprintf(
                            'Short feed content (%d words) — scraping fallback failed/insufficient, original content rakha: "%s"',
                            $pre_scrape_words, $item['title']
                        ) );
                    }
                } else {
                    $this->logger->log( $feed->id, 'info', sprintf(
                        'Short feed content (%d words) — scraping fallback failed (article fetch error), original content rakha: "%s"',
                        $pre_scrape_words, $item['title']
                    ) );
                }
            }

            // Min word count check
            $min_words  = isset( $this->settings['min_word_count'] ) ? absint( $this->settings['min_word_count'] ) : 0;
            $word_count = $this->cleaner->get_word_count( $cleaned_content );
            if ( $min_words > 0 && $word_count < $min_words ) {
                $this->logger->log( $feed->id, 'info', sprintf( 'Skipped low quality: "%s" (%d words, min: %d)', $item['title'], $word_count, $min_words ) );
                $results['skipped']++;
                continue;
            }

            // AI Rewrite / Translate — per-feed content_mode ke basis pe
            $title   = $item['title'];
            $content = $cleaned_content;
            $content_mode = isset( $feed->content_mode ) ? $feed->content_mode : 'direct';

            if ( $content_mode === 'api_translate' ) {
                // API se translate karo (Claude ya ChatGPT)
                $translated = $this->ai->translate_via_api( $title, $content, $feed->id );
                $title   = $translated['title'];
                $content = $translated['content'];
            } elseif ( $content_mode === 'translate' ) {
                // Free Google Translate se Hindi → English
                $title   = $this->ai->google_translate( $title, 'hi', 'en' );
                $content = $this->ai->google_translate( wp_strip_all_tags( $content ), 'hi', 'en' );
                if ( strpos( $content, '<p>' ) === false ) {
                    $content = wpautop( $content );
                }
                $this->logger->log( $feed->id, 'ai', 'Content translated via Google Translate (free).' );
            } else {
                // direct mode — global AI rewrite (agar enabled hai)
                if ( $this->ai->is_enabled() ) {
                    $title   = $this->ai->rewrite_title( $title, $feed->id );
                    $content = $this->ai->rewrite_content( $content, $title, $feed->id );
                }
            }

            // Find & Replace
            $title   = $this->apply_find_replace( $title, 'title' );
            $content = $this->apply_find_replace( $content, 'content' );

            // Title Symbol / ZWC — unique marker lagao
            $title = $this->apply_title_symbol( $title );

            // Publish
            $post_data = array(
                'title'          => $title,
                'content'        => $content,
                'category_id'    => $item['category_id'],
                'category_ids'   => isset( $item['category_ids'] ) ? $item['category_ids'] : array(),
                'tags'           => $item['tags'],
                'featured_image' => $item['featured_image'],
                'feed_id'        => $item['feed_id'],
                'link'           => $item['link'],
                'date'           => $item['date'],
                'author'         => $item['author'],
                'image_mode'     => $item['image_mode'],
                'author_id'      => isset( $feed->author_id ) ? absint( $feed->author_id ) : 0,
                'logo_watermark' => isset( $feed->logo_watermark ) ? (bool) $feed->logo_watermark : false,
                'logo_position'  => isset( $feed->logo_position ) ? $feed->logo_position : 'bottom-right',
            );

            $post_id = $this->publisher->publish( $post_data );

            if ( is_wp_error( $post_id ) ) {
                $this->logger->log( $feed->id, 'error', 'Publish failed: ' . $post_id->get_error_message() );
                $results['errors']++;
                continue;
            }

            $this->dedup->mark_processed( $feed->id, $item['title'], $item['link'], $post_id );
            $this->rate_limiter->record_publish();

            $is_today = ! empty( $item['date'] ) && ( new DateTime( $item['date'], $ist_tz ) )->format( 'Y-m-d' ) === $today_ist;
            $this->logger->log(
                $feed->id,
                'publish',
                sprintf( 'Published (%s): "%s" (Post #%d)', $is_today ? 'aaj ki news' : 'purani news fallback', $title, $post_id )
            );

            $results['published']++;
        }

        return $results;
    }


    /**
     * Apply find & replace rules to text.
     *
     * @param string $text   The text to process.
     * @param string $field  'title' or 'content'.
     * @return string Processed text.
     */
    private function apply_find_replace( $text, $field ) {
        $rules = isset( $this->settings['find_replace_rules'] ) ? $this->settings['find_replace_rules'] : array();

        if ( empty( $rules ) || ! is_array( $rules ) ) {
            return $text;
        }

        foreach ( $rules as $rule ) {
            $target = isset( $rule['target'] ) ? $rule['target'] : 'both';
            $type   = isset( $rule['type'] )   ? $rule['type']   : 'normal';

            if ( $target !== 'both' && $target !== $field ) {
                continue;
            }

            // Special bracket-removal rules
            if ( $type === 'remove_brackets' ) {
                $text = preg_replace( '/\s*\([^)]*\)\s*/u', ' ', $text );
                $text = trim( preg_replace( '/\s{2,}/', ' ', $text ) );
                continue;
            }
            if ( $type === 'remove_curly' ) {
                $text = preg_replace( '/\s*\{[^}]*\}\s*/u', ' ', $text );
                $text = trim( preg_replace( '/\s{2,}/', ' ', $text ) );
                continue;
            }
            if ( $type === 'remove_square' ) {
                $text = preg_replace( '/\s*\[[^\]]*\]\s*/u', ' ', $text );
                $text = trim( preg_replace( '/\s{2,}/', ' ', $text ) );
                continue;
            }

            // Normal find & replace
            if ( empty( $rule['find'] ) ) {
                continue;
            }
            $find    = $rule['find'];
            $replace = isset( $rule['replace'] ) ? $rule['replace'] : '';
            $text = str_replace( $find, $replace, $text );
        }

        return $text;
    }

    /**
     * Apply title symbol or Zero-Width Character (ZWC) to title.
     *
     * Settings:
     *   title_symbol          : the actual character(s) to insert
     *   title_symbol_type     : 'zwc'|'star'|'bullet'|'caret'|'hash'|'pipe'|'dot'|'dash'|'custom'|'none'
     *   title_symbol_position : 'prefix'|'suffix'|'both'|'none'
     *
     * @param string $title
     * @return string
     */
    private function apply_title_symbol( $title ) {
        $position = isset( $this->settings['title_symbol_position'] ) ? $this->settings['title_symbol_position'] : 'none';

        if ( $position === 'none' || empty( $position ) ) {
            return $title;
        }

        $sym_type = isset( $this->settings['title_symbol_type'] ) ? $this->settings['title_symbol_type'] : 'zwc';

        if ( $sym_type === 'zwc' ) {
            $symbol = "\u{200B}"; // Zero-Width Space — invisible
        } elseif ( $sym_type === 'none' ) {
            return $title;
        } else {
            $symbol = isset( $this->settings['title_symbol'] ) ? $this->settings['title_symbol'] : '';
        }

        if ( $symbol === '' && $sym_type !== 'zwc' ) {
            return $title;
        }

        switch ( $position ) {
            case 'prefix':
                return $symbol . $title;
            case 'suffix':
                return $title . $symbol;
            case 'both':
                return $symbol . $title . $symbol;
            default:
                return $title;
        }
    }

    /**
     * Get dashboard statistics.
     *
     * @return array Stats data.
     */
    public function get_stats() {
        $log_counts = $this->logger->get_all_counts();
        $cron       = AE_Cron_Handler::get_instance()->get_status();
        $remaining  = $this->rate_limiter->get_remaining();

        return array(
            'total_feeds'    => $this->feed_manager->get_count(),
            'active_feeds'   => $this->feed_manager->get_count( true ),
            'posts_published' => $this->dedup->get_published_count(),
            'total_processed' => $this->dedup->get_processed_count(),
            'log_counts'     => $log_counts,
            'cron'           => $cron,
            'rate_limit'     => $remaining,
            'ai_enabled'     => $this->ai->is_enabled(),
        );
    }
}
