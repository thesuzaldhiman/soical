<?php
/**
 * Cron Handler — WordPress Cron based processing.
 *
 * Supports multiple time slots (IST) for controlled publishing windows.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Cron_Handler {

    private static $instance = null;

    private function __construct() {
        add_action( 'auto_engine_cron_hook', array( $this, 'run' ) );

        if ( ! wp_next_scheduled( 'auto_engine_cron_hook' ) ) {
            wp_schedule_event( time(), 'ae_every_minute', 'auto_engine_cron_hook' );
        }
    }

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Main execution — triggered every 1 minute by WP-Cron.
     *
     * Two modes:
     *
     * MODE A — Auto Fetch Schedule ON:
     *   - Cron har minute check karta hai kya ab koi scheduled fetch time hai.
     *   - Scheduled time match hone par SAARI active feeds ek sath fetch hoti hain.
     *   - Har feed se SAARE naye items publish hote hain (sirf 1 nahi).
     *   - Har schedule time sirf ek baar trigger hota hai (duplicate prevention).
     *
     * MODE B — Auto Fetch Schedule OFF (legacy):
     *   - Pehle wali har-minute random single post behaviour.
     *   - Time Slot check bhi apply hota hai.
     */
    public function run() {
        $settings = get_option( 'auto_engine_settings', array() );

        $auto_fetch_enabled = ! empty( $settings['auto_fetch_enabled'] );

        if ( $auto_fetch_enabled ) {
            // ── MODE A: Scheduled Bulk Fetch ─────────────────────────────────
            // Auto Fetch ON hai — sirf scheduled times pe hi fetch hoga
            // Legacy per-minute mode BILKUL nahi chalega
            $due = $this->is_auto_fetch_due( $settings );

            AE_Logger::get_instance()->log( 0, 'info', sprintf(
                '[Auto Fetch Mode] Cron tick at %s IST — Schedule due: %s',
                ( new DateTime( 'now', new DateTimeZone( 'Asia/Kolkata' ) ) )->format( 'H:i:s' ),
                $due ? 'YES — Fetch start' : 'NO — Skip'
            ) );

            if ( ! $due ) {
                return; // Scheduled time nahi aaya — kuch mat karo
            }

            AE_Logger::get_instance()->log( 0, 'fetch', '[Auto Fetch] Interval-based bulk fetch triggered — saari feeds ek sath fetch ho rahi hain.' );

            // Last fetch timestamp save karo — countdown timer ke liye
            update_option( 'ae_last_bulk_fetch_ts', time(), false );

            $engine = AE_Auto_Engine::get_instance();
            $engine->process_feeds( 0, true ); // feed_id=0 → saari feeds, bulk_mode=true → sab items

        } else {
            // ── MODE B: Legacy per-minute single post ────────────────────────
            if ( ! $this->is_within_time_slot() ) {
                return;
            }

            $feeds = AE_Feed_Manager::get_instance()->get_feeds( array( 'active_only' => true ) );
            if ( empty( $feeds ) ) {
                return;
            }

            $due_feeds = array();
            foreach ( $feeds as $feed ) {
                if ( $this->is_feed_due( $feed ) ) {
                    $due_feeds[] = $feed;
                }
            }

            if ( empty( $due_feeds ) ) {
                return;
            }

            // Round-robin: last successful feed ke baad se shuru karo
            $last_feed_id = (int) get_option( 'ae_last_published_feed_id', 0 );

            // Due feeds ko round-robin order mein arrange karo
            if ( $last_feed_id > 0 ) {
                $reordered = array();
                $found     = false;
                // Last successful feed ke BAAD wali feeds pehle
                foreach ( $due_feeds as $feed ) {
                    if ( $found ) {
                        $reordered[] = $feed;
                    } elseif ( (int) $feed->id === $last_feed_id ) {
                        $found = true; // yahan se baad wali chahiye
                    }
                }
                // Bachi hui feeds (last_feed_id tak wali) end mein lagao
                foreach ( $due_feeds as $feed ) {
                    if ( (int) $feed->id === $last_feed_id ) {
                        break;
                    }
                    $reordered[] = $feed;
                }
                // Agar last_feed_id due_feeds mein nahi mila to original order
                $due_feeds = ! empty( $reordered ) ? $reordered : $due_feeds;
            }

            $engine = AE_Auto_Engine::get_instance();

            // Har minute sirf 1 post — jo feed se mili wahan STOP, next minute aage se shuru
            foreach ( $due_feeds as $feed ) {
                $result = $engine->process_feeds( $feed->id, false );
                if ( ! empty( $result['published'] ) && $result['published'] > 0 ) {
                    // Is feed se post mili — yaad rakho, next minute yahan se aage jaana hai
                    update_option( 'ae_last_published_feed_id', $feed->id, false );
                    break;
                }
                // Post nahi mili — same minute mein next feed try karo
            }
        }
    }

    /**
     * Check if interval-based auto-fetch is due.
     *
     * Naya mode: Fixed time slots ki jagah interval (minutes) use hoga.
     * Last fetch ke baad interval minutes guzar gaye to fetch due hai.
     * Lock transient ensure karta hai duplicate trigger nahi hoga.
     *
     * @param array $settings Plugin settings.
     * @return bool
     */
    private function is_auto_fetch_due( $settings ) {
        $interval_minutes = isset( $settings['fetch_interval_minutes'] ) ? max( 1, absint( $settings['fetch_interval_minutes'] ) ) : 2;

        // Last bulk fetch timestamp
        $last_fetch_ts = absint( get_option( 'ae_last_bulk_fetch_ts', 0 ) );
        $now_ts        = time();

        // Pehli baar fetch — abhi due hai
        if ( $last_fetch_ts === 0 ) {
            // Lock for 60 seconds to prevent concurrent triggers
            $lock_key = 'ae_af_interval_lock';
            if ( get_transient( $lock_key ) ) {
                return false;
            }
            set_transient( $lock_key, 1, 60 );
            return true;
        }

        $elapsed_seconds  = $now_ts - $last_fetch_ts;
        $interval_seconds = $interval_minutes * 60;

        // Safety net: agar kisi wajah se timestamp bahut purana ho (e.g. 10x interval)
        // to force-fetch karo taaki koi bhi hang state se bahar aa jaye
        $max_wait_seconds = $interval_seconds * 10;
        $force_fetch      = $elapsed_seconds > $max_wait_seconds;

        if ( $elapsed_seconds >= $interval_seconds || $force_fetch ) {
            // Lock: prevent duplicate within same minute
            $lock_key = 'ae_af_interval_lock_' . floor( $now_ts / 60 );
            if ( get_transient( $lock_key ) ) {
                return false;
            }
            set_transient( $lock_key, 1, 90 ); // 90s lock
            return true;
        }

        return false;
    }

    /**
     * Check if current IST time is within any configured time slot.
     *
     * Slots stored as: [['start'=>'10:30','end'=>'10:59'], ['start'=>'13:00','end'=>'13:59']]
     * If no slots configured → always return true (legacy behaviour).
     *
     * @return bool
     */
    public function is_within_time_slot() {
        $settings = get_option( 'auto_engine_settings', array() );
        $slots    = isset( $settings['time_slots'] ) ? $settings['time_slots'] : array();

        // Koi slot set nahi → hamesha allowed
        if ( empty( $slots ) || ! is_array( $slots ) ) {
            return true;
        }

        try {
            $tz          = new DateTimeZone( 'Asia/Kolkata' );
            $now         = new DateTime( 'now', $tz );
            $now_minutes = (int) $now->format( 'H' ) * 60 + (int) $now->format( 'i' );

            foreach ( $slots as $slot ) {
                if ( empty( $slot['start'] ) || empty( $slot['end'] ) ) {
                    continue;
                }

                list( $sh, $sm ) = array_map( 'intval', explode( ':', $slot['start'] ) );
                list( $eh, $em ) = array_map( 'intval', explode( ':', $slot['end'] ) );

                $start_min = $sh * 60 + $sm;
                $end_min   = $eh * 60 + $em;

                // Overnight slot support (e.g. 23:30 – 00:30)
                if ( $end_min < $start_min ) {
                    if ( $now_minutes >= $start_min || $now_minutes <= $end_min ) {
                        return true;
                    }
                } else {
                    if ( $now_minutes >= $start_min && $now_minutes <= $end_min ) {
                        return true;
                    }
                }
            }

            return false;

        } catch ( Exception $e ) {
            return true; // Error par allow karo
        }
    }

    /**
     * Check if a feed is due for fetching (IST based).
     *
     * @param object $feed
     * @return bool
     */
    private function is_feed_due( $feed ) {
        $interval_minutes = isset( $feed->fetch_interval ) ? absint( $feed->fetch_interval ) : 10;
        $interval_minutes = max( 1, $interval_minutes );

        if ( empty( $feed->last_fetched ) || $feed->last_fetched === '0000-00-00 00:00:00' ) {
            // Feed kabhi fetch nahi hui — random offset assign karo taaki sab sites pe
            // alag-alag time pe due ho. Offset = 0 se (interval-1) minutes ke beech random.
            $offset_minutes = rand( 0, max( 1, $interval_minutes - 1 ) );
            $fake_last = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( $offset_minutes * 60 ) );
            AE_Feed_Manager::get_instance()->update_feed(
                $feed->id,
                array( 'last_fetched' => $fake_last )
            );
            // Sirf wo feeds turant due hongi jinhe offset=0 mila
            return $offset_minutes === 0;
        }

        try {
            $timezone_ist = new DateTimeZone( 'Asia/Kolkata' );
            $now          = new DateTime( 'now', $timezone_ist );
            $last_fetched = new DateTime( $feed->last_fetched, $timezone_ist );

            $diff_seconds = $now->getTimestamp() - $last_fetched->getTimestamp();
            $diff_minutes = floor( $diff_seconds / 60 );

            if ( $diff_minutes < 0 ) {
                return true;
            }

            return $diff_minutes >= $interval_minutes;

        } catch ( Exception $e ) {
            return true;
        }
    }

    public function reschedule() {
        wp_clear_scheduled_hook( 'auto_engine_cron_hook' );

        if ( ! wp_next_scheduled( 'auto_engine_cron_hook' ) ) {
            wp_schedule_event( time(), 'ae_every_minute', 'auto_engine_cron_hook' );
        }

        AE_Logger::get_instance()->log( 0, 'info', 'WP-Cron rescheduled to 1 minute format.' );
    }

    public function get_next_run() {
        return wp_next_scheduled( 'auto_engine_cron_hook' );
    }

    public function is_scheduled() {
        return false !== $this->get_next_run();
    }

    public function get_status() {
        $next = $this->get_next_run();

        if ( $next ) {
            try {
                $tz = new DateTimeZone( 'Asia/Kolkata' );
                $dt = new DateTime();
                $dt->setTimestamp( $next );
                $dt->setTimezone( $tz );
                $next_run_str = $dt->format( 'Y-m-d h:i:s A' ) . ' IST';
            } catch ( Exception $e ) {
                $next_run_str = gmdate( 'Y-m-d H:i:s', $next );
            }
        } else {
            $next_run_str = null;
        }

        return array(
            'scheduled'      => false !== $next,
            'next_run'       => $next_run_str,
            'next_run_human' => $next ? human_time_diff( time(), $next ) : null,
            'mode'           => 'wp-cron (IST)',
            'in_time_slot'   => $this->is_within_time_slot(),
        );
    }
}
