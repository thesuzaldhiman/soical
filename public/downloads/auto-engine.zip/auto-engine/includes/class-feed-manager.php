<?php
/**
 * Feed Manager — CRUD operations for RSS feeds.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Feed_Manager {

    /**
     * Singleton instance.
     *
     * @var AE_Feed_Manager|null
     */
    private static $instance = null;

    /**
     * Table name.
     *
     * @var string
     */
    private $table;

    /**
     * Constructor.
     */
    private function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'ae_feeds';
        $this->maybe_run_migrations();
    }

    /**
     * Auto-migration: table exist karo aur naye columns add karo agar exist nahi karte.
     * Table exist nahi karti (fresh install, plugin reactivate without deactivate) —
     * toh pehle table banao, phir columns check karo.
     */
    private function maybe_run_migrations() {
        global $wpdb;

        // Pehle check karo table exist karti hai ya nahi
        $table_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(1) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
            DB_NAME,
            $this->table
        ) );

        if ( ! $table_exists ) {
            // Table nahi hai — activation function call karo
            // (dbDelta safe hai — duplicate run pe kuch nahi karta)
            if ( function_exists( 'ae_activate' ) ) {
                ae_activate();
            }
            return;
        }

        // Table hai — sirf missing columns add karo
        $cols = $wpdb->get_col( "DESCRIBE {$this->table}", 0 );
        if ( ! in_array( 'category_ids', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN category_ids TEXT DEFAULT NULL AFTER category_id" );
        }
        if ( ! in_array( 'author_id', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN author_id BIGINT(20) UNSIGNED DEFAULT 0" );
        }
        if ( ! in_array( 'fetch_interval', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN fetch_interval INT UNSIGNED DEFAULT 10" );
        }
        if ( ! in_array( 'logo_watermark', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN logo_watermark TINYINT(1) DEFAULT 0" );
        }
        if ( ! in_array( 'logo_position', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN logo_position VARCHAR(20) DEFAULT 'bottom-right'" );
        }
        if ( ! in_array( 'logo_opacity', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN logo_opacity TINYINT(3) NOT NULL DEFAULT 80" );
        } else {
            // Null values fix karo existing rows me
            $wpdb->query( "UPDATE {$this->table} SET logo_opacity = 80 WHERE logo_opacity IS NULL" );
        }
        if ( ! in_array( 'logo_size', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN logo_size TINYINT(3) NOT NULL DEFAULT 20" );
        } else {
            $wpdb->query( "UPDATE {$this->table} SET logo_size = 20 WHERE logo_size IS NULL" );
        }
        if ( ! in_array( 'logo_no_margin', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN logo_no_margin TINYINT(1) NOT NULL DEFAULT 0" );
        } else {
            $wpdb->query( "UPDATE {$this->table} SET logo_no_margin = 0 WHERE logo_no_margin IS NULL" );
        }
        if ( ! in_array( 'content_mode', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN content_mode VARCHAR(20) DEFAULT 'direct'" );
        }
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Feed_Manager
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Add a new feed.
     *
     * @param array $data {
     *     @type string $feed_url    RSS feed URL.
     *     @type string $feed_name   Feed display name.
     *     @type int    $category_id WordPress category ID.
     *     @type string $fetch_mode  'new_only' or 'all'.
     *     @type string $image_mode  'featured_only' or 'all_images'.
     * }
     * @return int|false Feed ID on success, false on failure.
     */
    public function add_feed( $data ) {
        global $wpdb;

        $feed_url = isset( $data['feed_url'] ) ? esc_url_raw( $data['feed_url'] ) : '';
        if ( empty( $feed_url ) ) {
            return false;
        }

        // Build insert data — category_ids column may not exist on older installs
        $cat_ids_arr   = isset( $data['category_ids'] ) && is_array( $data['category_ids'] ) ? array_filter( array_map( 'absint', $data['category_ids'] ) ) : array();
        $cat_id_single = ! empty( $cat_ids_arr ) ? $cat_ids_arr[0] : ( isset( $data['category_id'] ) ? absint( $data['category_id'] ) : 0 );

        $insert_data = array(
            'feed_url'       => $feed_url,
            'feed_name'      => isset( $data['feed_name'] ) ? sanitize_text_field( $data['feed_name'] ) : '',
            'category_id'    => $cat_id_single,
            'category_ids'   => ! empty( $cat_ids_arr ) ? wp_json_encode( array_values( $cat_ids_arr ) ) : null,
            'fetch_mode'     => isset( $data['fetch_mode'] ) && $data['fetch_mode'] === 'all' ? 'all' : 'new_only',
            'image_mode'     => isset( $data['image_mode'] ) && $data['image_mode'] === 'all_images' ? 'all_images' : 'featured_only',
            'fetch_interval' => isset( $data['fetch_interval'] ) ? max( 1, absint( $data['fetch_interval'] ) ) : 2,
            'author_id'      => isset( $data['author_id'] ) ? absint( $data['author_id'] ) : 0,
            'logo_watermark' => ! empty( $data['logo_watermark'] ) ? 1 : 0,
            'logo_position'  => isset( $data['logo_position'] ) && in_array( $data['logo_position'], array( 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center' ), true ) ? $data['logo_position'] : 'bottom-right',
            'logo_opacity'   => isset( $data['logo_opacity'] ) ? max( 0, min( 100, intval( $data['logo_opacity'] ) ) ) : 80,
            'logo_size'      => isset( $data['logo_size'] ) ? max( 5, min( 80, intval( $data['logo_size'] ) ) ) : 20,
            'logo_no_margin' => ! empty( $data['logo_no_margin'] ) ? 1 : 0,
            'content_mode'   => isset( $data['content_mode'] ) && in_array( $data['content_mode'], array( 'direct', 'translate', 'api_translate' ), true ) ? $data['content_mode'] : 'direct',
            'is_active'      => 1,
            'created_at'     => current_time( 'mysql' ),
        );
        $insert_format = array( '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%d', '%s', '%s' );

        $result = $wpdb->insert( $this->table, $insert_data, $insert_format );

        if ( false === $result ) {
            // DB error log karo taaki debug ho sake
            AE_Logger::get_instance()->log( 0, 'error', sprintf(
                'Feed insert failed. DB Error: %s | Table: %s',
                $wpdb->last_error ?: 'unknown',
                $this->table
            ) );
            return false;
        }

        AE_Logger::get_instance()->log( $wpdb->insert_id, 'info', sprintf( 'Feed added: %s', $feed_url ) );

        return $wpdb->insert_id;
    }

    /**
     * Update an existing feed.
     *
     * @param int   $feed_id Feed ID.
     * @param array $data    Fields to update.
     * @return bool True on success, false on failure.
     */
    public function update_feed( $feed_id, $data ) {
        global $wpdb;

        $update = array();
        $formats = array();

        if ( isset( $data['feed_url'] ) ) {
            $update['feed_url'] = esc_url_raw( $data['feed_url'] );
            $formats[] = '%s';
        }

        if ( isset( $data['feed_name'] ) ) {
            $update['feed_name'] = sanitize_text_field( $data['feed_name'] );
            $formats[] = '%s';
        }

        if ( isset( $data['category_ids'] ) && is_array( $data['category_ids'] ) ) {
            $cat_ids = array_filter( array_map( 'absint', $data['category_ids'] ) );
            $update['category_id']  = ! empty( $cat_ids ) ? $cat_ids[0] : 0;
            $update['category_ids'] = ! empty( $cat_ids ) ? wp_json_encode( array_values( $cat_ids ) ) : null;
            $formats[] = '%d';
            $formats[] = '%s';
        } elseif ( isset( $data['category_id'] ) ) {
            $update['category_id'] = absint( $data['category_id'] );
            $formats[] = '%d';
        }

        if ( isset( $data['fetch_mode'] ) ) {
            $update['fetch_mode'] = $data['fetch_mode'] === 'all' ? 'all' : 'new_only';
            $formats[] = '%s';
        }

        if ( isset( $data['image_mode'] ) ) {
            $update['image_mode'] = $data['image_mode'] === 'all_images' ? 'all_images' : 'featured_only';
            $formats[] = '%s';
        }

        if ( isset( $data['is_active'] ) ) {
            $update['is_active'] = absint( $data['is_active'] ) ? 1 : 0;
            $formats[] = '%d';
        }

        if ( isset( $data['fetch_interval'] ) ) {
            $update['fetch_interval'] = max( 1, absint( $data['fetch_interval'] ) );
            $formats[] = '%d';
        }

        if ( isset( $data['author_id'] ) ) {
            $update['author_id'] = absint( $data['author_id'] );
            $formats[] = '%d';
        }

        if ( isset( $data['logo_watermark'] ) ) {
            $update['logo_watermark'] = ! empty( $data['logo_watermark'] ) ? 1 : 0;
            $formats[] = '%d';
        }

        if ( isset( $data['logo_position'] ) ) {
            $allowed_positions = array( 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center' );
            $update['logo_position'] = in_array( $data['logo_position'], $allowed_positions, true ) ? $data['logo_position'] : 'bottom-right';
            $formats[] = '%s';
        }

        // opacity, size, no_margin — sirf tab update karo jab explicitly pass ki gayi ho.
        // Pehle yeh hamesha update hoti thi (default 80/20/0 ke saath agar missing),
        // jiski wajah se partial updates (e.g. cron ka sirf last_fetched update) bhi
        // in values ko silently default pe reset kar deti thi. Ab sirf jab user
        // explicitly inhe save kare, tabhi badlengi.
        if ( isset( $data['logo_opacity'] ) ) {
            $update['logo_opacity'] = max( 0, min( 100, intval( $data['logo_opacity'] ) ) );
            $formats[] = '%d';
        }
        if ( isset( $data['logo_size'] ) ) {
            $update['logo_size'] = max( 5, min( 80, intval( $data['logo_size'] ) ) );
            $formats[] = '%d';
        }
        if ( isset( $data['logo_no_margin'] ) ) {
            $update['logo_no_margin'] = ! empty( $data['logo_no_margin'] ) ? 1 : 0;
            $formats[] = '%d';
        }

        if ( isset( $data['content_mode'] ) ) {
            $allowed_modes = array( 'direct', 'translate', 'api_translate' );
            $update['content_mode'] = in_array( $data['content_mode'], $allowed_modes, true ) ? $data['content_mode'] : 'direct';
            $formats[] = '%s';
        }

        if ( isset( $data['last_fetched'] ) ) {
            $update['last_fetched'] = sanitize_text_field( $data['last_fetched'] );
            $formats[] = '%s';
        }

        if ( empty( $update ) ) {
            return false;
        }

        $result = $wpdb->update(
            $this->table,
            $update,
            array( 'id' => absint( $feed_id ) ),
            $formats,
            array( '%d' )
        );

        return false !== $result;
    }

    /**
     * Delete a feed.
     *
     * @param int $feed_id Feed ID.
     * @return bool True on success, false on failure.
     */
    public function delete_feed( $feed_id ) {
        global $wpdb;

        // Also clean up processed items for this feed
        $wpdb->delete(
            $wpdb->prefix . 'ae_processed',
            array( 'feed_id' => absint( $feed_id ) ),
            array( '%d' )
        );

        $result = $wpdb->delete(
            $this->table,
            array( 'id' => absint( $feed_id ) ),
            array( '%d' )
        );

        if ( $result ) {
            AE_Logger::get_instance()->log( $feed_id, 'info', 'Feed deleted' );
        }

        return false !== $result;
    }

    /**
     * Get a single feed by ID.
     *
     * @param int $feed_id Feed ID.
     * @return object|null Feed object or null.
     */
    public function get_feed( $feed_id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->table} WHERE id = %d",
                absint( $feed_id )
            )
        );
    }

    /**
     * Get all feeds.
     *
     * @param array $args {
     *     @type bool $active_only Only return active feeds.
     *     @type string $orderby   Column to order by.
     *     @type string $order     ASC or DESC.
     * }
     * @return array Array of feed objects.
     */
    public function get_feeds( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'active_only' => false,
            'orderby'     => 'created_at',
            'order'       => 'DESC',
        );

        $args = wp_parse_args( $args, $defaults );

        $where = '1=1';
        if ( $args['active_only'] ) {
            $where .= ' AND is_active = 1';
        }

        $allowed_orderby = array( 'id', 'feed_url', 'feed_name', 'category_id', 'is_active', 'last_fetched', 'created_at' );
        $orderby = in_array( $args['orderby'], $allowed_orderby, true ) ? $args['orderby'] : 'created_at';
        $order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';

        $results = $wpdb->get_results(
            "SELECT * FROM {$this->table} WHERE {$where} ORDER BY {$orderby} {$order}"
        );

        return $results ? $results : array();
    }

    /**
     * Toggle feed active status.
     *
     * @param int $feed_id Feed ID.
     * @return bool New status.
     */
    public function toggle_feed( $feed_id ) {
        global $wpdb;

        $feed = $this->get_feed( $feed_id );
        if ( ! $feed ) {
            return false;
        }

        $new_status = $feed->is_active ? 0 : 1;

        $wpdb->update(
            $this->table,
            array( 'is_active' => $new_status ),
            array( 'id' => absint( $feed_id ) ),
            array( '%d' ),
            array( '%d' )
        );

        return (bool) $new_status;
    }

    /**
     * Get total feed count.
     *
     * @param bool $active_only Count only active feeds.
     * @return int
     */
    public function get_count( $active_only = false ) {
        global $wpdb;

        if ( $active_only ) {
            return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table} WHERE is_active = 1" );
        }

        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table}" );
    }

    /**
     * Update last fetched timestamp.
     *
     * @param int $feed_id Feed ID.
     * @return bool
     */
    public function update_last_fetched( $feed_id ) {
        return $this->update_feed( $feed_id, array( 'last_fetched' => current_time( 'mysql' ) ) );
    }

    /**
     * Test a feed URL — fetches and returns preview items.
     *
     * @param string $url Feed URL to test.
     * @return array|WP_Error Array of items or WP_Error on failure.
     */
    public function test_feed( $url ) {
        $url = esc_url_raw( $url );

        if ( empty( $url ) ) {
            return new WP_Error( 'invalid_url', __( 'Please provide a valid feed URL.', 'auto-engine' ) );
        }

        // Multiple strategies try karo — kuch APIs browser simulation chahte hain
        $strategies = array(
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'headers'    => array(
                    'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language' => 'hi-IN,hi;q=0.9,en;q=0.7',
                    'Referer'         => ( parse_url( $url, PHP_URL_SCHEME ) ?: 'https' ) . '://' . ( parse_url( $url, PHP_URL_HOST ) ?: '' ) . '/',
                    'Cache-Control'   => 'no-cache',
                ),
            ),
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
                'headers'    => array(
                    'Accept'          => 'application/rss+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language' => 'hi,en;q=0.5',
                    'Referer'         => home_url(),
                ),
            ),
            array(
                'user-agent' => 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)',
                'headers'    => array(
                    'Accept' => 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*',
                ),
            ),
        );

        $body = null;
        foreach ( $strategies as $strategy ) {
            $response = wp_remote_get( $url, array(
                'timeout'     => 20,
                'user-agent'  => $strategy['user-agent'],
                'headers'     => $strategy['headers'],
                'sslverify'   => false,
                'redirection' => 5,
            ) );

            if ( is_wp_error( $response ) ) continue;

            $code = wp_remote_retrieve_response_code( $response );
            if ( $code === 200 ) {
                $body = wp_remote_retrieve_body( $response );
                if ( ! empty( $body ) ) break;
            }
        }

        if ( empty( $body ) ) {
            return new WP_Error( 'feed_error', 'Feed se response nahi aaya. Hosting server is URL ko block kar raha hai. Aap FetchRSS.com se proxy URL banake try kar sakte hain.' );
        }

        // JSON feed hai ya RSS/XML — detect karo
        $trimmed = ltrim( $body );
        if ( strlen( $trimmed ) > 0 && ( $trimmed[0] === '{' || $trimmed[0] === '[' ) ) {
            return $this->test_json_feed( $body );
        }

        // SimplePie load karo
        if ( ! class_exists( 'SimplePie' ) ) {
            require_once ABSPATH . WPINC . '/class-simplepie.php';
        }

        $rss = new SimplePie();
        $rss->set_raw_data( $body );
        $rss->enable_cache( false );
        $rss->force_feed( true );
        $rss->init();

        if ( $rss->error() ) {
            return new WP_Error( 'feed_error', $rss->error() );
        }

        $max_items = $rss->get_item_quantity( 5 );
        $items     = $rss->get_items( 0, $max_items );

        if ( empty( $items ) ) {
            return new WP_Error( 'no_items', __( 'No items found in this feed.', 'auto-engine' ) );
        }

        $preview = array();
        foreach ( $items as $item ) {
            $content = $item->get_content();
            $image = '';

            // Try to extract first image
            if ( preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/', $content, $matches ) ) {
                $image = $matches[1];
            }

            // Try enclosure
            if ( empty( $image ) ) {
                $enclosure = $item->get_enclosure();
                if ( $enclosure && $enclosure->get_link() ) {
                    $type = $enclosure->get_type();
                    if ( $type && strpos( $type, 'image' ) !== false ) {
                        $image = $enclosure->get_link();
                    }
                }
            }

            // Try media:thumbnail or media:content
            if ( empty( $image ) ) {
                $dom = $item->get_item_tags( 'http://search.yahoo.com/mrss/', 'thumbnail' );
                if ( $dom && isset( $dom[0]['attribs']['']['url'] ) ) {
                    $image = $dom[0]['attribs']['']['url'];
                }
            }

            if ( empty( $image ) ) {
                $dom = $item->get_item_tags( 'http://search.yahoo.com/mrss/', 'content' );
                if ( $dom && isset( $dom[0]['attribs']['']['url'] ) ) {
                    $medium = isset( $dom[0]['attribs']['']['medium'] ) ? $dom[0]['attribs']['']['medium'] : '';
                    if ( $medium === 'image' || empty( $medium ) ) {
                        $image = $dom[0]['attribs']['']['url'];
                    }
                }
            }

            $preview[] = array(
                'title'   => html_entity_decode( wp_strip_all_tags( $item->get_title() ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
                'link'    => $item->get_permalink(),
                'date'    => $item->get_date( 'Y-m-d H:i:s' ),
                'image'   => $image,
                'excerpt' => html_entity_decode( wp_trim_words( wp_strip_all_tags( $content ), 30 ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
            );
        }

        return $preview;
    }

    /**
     * JSON feed test karo — preview items return karo
     */
    private function test_json_feed( $body ) {
        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE || empty( $data ) ) {
            return new WP_Error( 'json_error', 'JSON parse error: ' . json_last_error_msg() );
        }

        // Items array dhundho
        $items_raw = array();
        if ( isset( $data['data']['news'] ) && is_array( $data['data']['news'] ) )      $items_raw = $data['data']['news'];
        elseif ( isset( $data['items'] ) && is_array( $data['items'] ) )                $items_raw = $data['items'];
        elseif ( isset( $data['articles'] ) && is_array( $data['articles'] ) )          $items_raw = $data['articles'];
        elseif ( isset( $data['entries'] ) && is_array( $data['entries'] ) )            $items_raw = $data['entries'];
        elseif ( isset( $data['data'] ) && is_array( $data['data'] ) )                  $items_raw = $data['data'];
        elseif ( is_array( $data ) && isset( $data[0] ) )                               $items_raw = $data;

        if ( empty( $items_raw ) ) {
            return new WP_Error( 'no_items', 'JSON feed mila lekin items nahi mile. Feed structure supported nahi hai.' );
        }

        $preview = array();
        foreach ( array_slice( $items_raw, 0, 5 ) as $raw ) {
            if ( ! is_array( $raw ) ) continue;

            $title   = wp_strip_all_tags( html_entity_decode( $raw['title'] ?? $raw['headline'] ?? $raw['name'] ?? '', ENT_QUOTES, 'UTF-8' ) );
            $link    = $raw['url'] ?? $raw['link'] ?? $raw['permalink'] ?? $raw['web_url'] ?? '';
            $content = $raw['content'] ?? $raw['body'] ?? $raw['description'] ?? $raw['summary'] ?? '';
            if ( is_array( $content ) ) $content = $content['html'] ?? $content['text'] ?? '';
            $date    = $raw['pubDate'] ?? $raw['published_at'] ?? $raw['date'] ?? $raw['created_at'] ?? '';

            $image = '';
            foreach ( array( 'image', 'thumbnail', 'image_url', 'featured_image', 'photo', 'img_url' ) as $f ) {
                if ( ! empty( $raw[ $f ] ) && is_string( $raw[ $f ] ) ) { $image = $raw[ $f ]; break; }
            }
            if ( empty( $image ) && ! empty( $raw['image']['url'] ) )    $image = $raw['image']['url'];
            if ( empty( $image ) && ! empty( $raw['thumbnail']['url'] ) ) $image = $raw['thumbnail']['url'];

            if ( empty( $title ) || empty( $link ) ) continue;

            $preview[] = array(
                'title'   => $title,
                'link'    => $link,
                'date'    => $date ? date( 'Y-m-d H:i:s', strtotime( $date ) ) : '',
                'image'   => $image,
                'excerpt' => wp_trim_words( wp_strip_all_tags( $content ), 30 ),
            );
        }

        if ( empty( $preview ) ) {
            return new WP_Error( 'no_items', 'JSON feed parse hua lekin valid items nahi mile.' );
        }

        return $preview;
    }
}
