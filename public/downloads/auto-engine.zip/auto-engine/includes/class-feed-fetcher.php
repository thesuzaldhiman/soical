<?php
/**
 * Feed Fetcher — fetches items from RSS feeds using SimplePie.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Feed_Fetcher {

    /**
     * Singleton instance.
     *
     * @var AE_Feed_Fetcher|null
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return AE_Feed_Fetcher
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Fetch items from a feed.
     *
     * @param object $feed Feed database object.
     * @return array Array of structured feed items.
     */
    public function fetch( $feed ) {
        $logger = AE_Logger::get_instance();
        $url    = $feed->feed_url;

        $logger->log( $feed->id, 'fetch', sprintf( 'Fetching feed: %s', $url ) );

        $body = $this->fetch_url( $url );

        if ( is_wp_error( $body ) ) {
            $logger->log( $feed->id, 'error', sprintf( 'Feed fetch error: %s', $body->get_error_message() ) );
            return array();
        }

        // JSON feed hai ya RSS/XML — detect karo
        $trimmed = ltrim( $body );
        if ( strlen( $trimmed ) > 0 && ( $trimmed[0] === '{' || $trimmed[0] === '[' ) ) {
            // JSON feed — custom parser use karo
            return $this->parse_json_feed( $body, $feed );
        }

        // SimplePie se RSS/XML parse karo
        if ( ! class_exists( 'SimplePie' ) ) {
            require_once ABSPATH . WPINC . '/class-simplepie.php';
        }

        $rss = new SimplePie();
        $rss->set_raw_data( $body );
        $rss->enable_cache( false );
        $rss->force_feed( true );
        $rss->set_stupidly_fast( true );
        $rss->init();

        if ( $rss->error() ) {
            $logger->log( $feed->id, 'error', sprintf( 'Feed parse error: %s', $rss->error() ) );
            return array();
        }

        $max_items = $rss->get_item_quantity( 50 );
        $rss_items = $rss->get_items( 0, $max_items );

        if ( empty( $rss_items ) ) {
            $logger->log( $feed->id, 'fetch', 'No items found in feed.' );
            return array();
        }

        $items = array();
        foreach ( $rss_items as $rss_item ) {
            $item = $this->parse_item( $rss_item, $feed );
            if ( $item ) {
                $items[] = $item;
            }
        }

        $logger->log( $feed->id, 'fetch', sprintf( 'Fetched %d items from feed.', count( $items ) ) );

        AE_Feed_Manager::get_instance()->update_last_fetched( $feed->id );

        return $items;
    }

    /**
     * Article URL se OG image / Twitter card image fetch karo.
     * Jab feed mein koi image nahi hoti tab ye fallback use hoti hai.
     *
     * @param string $url Article URL.
     * @return string Image URL ya empty string.
     */
    private function fetch_og_image( $url ) {
        if ( empty( $url ) ) {
            return '';
        }

        $response = wp_remote_get( $url, array(
            'timeout'    => 10,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'sslverify'  => false,
            'redirection' => 3,
        ) );

        if ( is_wp_error( $response ) ) {
            return '';
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return '';
        }

        $html = wp_remote_retrieve_body( $response );
        if ( empty( $html ) ) {
            return '';
        }

        // og:image check karo
        if ( preg_match( '/<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $m ) ) {
            return esc_url_raw( $m[1] );
        }

        // Alternate attribute order
        if ( preg_match( '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']/i', $html, $m ) ) {
            return esc_url_raw( $m[1] );
        }

        // twitter:image fallback
        if ( preg_match( '/<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $m ) ) {
            return esc_url_raw( $m[1] );
        }

        if ( preg_match( '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']twitter:image["\']/i', $html, $m ) ) {
            return esc_url_raw( $m[1] );
        }

        return '';
    }

    /**
     * Article URL se full article body scrape karo — fallback jab feed
     * sirf chhota teaser/summary deti hai (e.g. onmanorama.com jaisi feeds
     * jo poora content RSS mein nahi dalti).
     *
     * Heuristic approach (no external library, koi Readability dependency nahi):
     * 1. Pehle common article-body containers try karo (class/id patterns).
     * 2. Agar wo na mile, to page ke saare <p> tags collect karke sabse
     *    bada contiguous text block use karo.
     *
     * @param string $url Article URL.
     * @return string HTML content ya empty string agar scrape fail ho.
     */
    public function fetch_full_article( $url ) {
        if ( empty( $url ) ) {
            return '';
        }

        $response = wp_remote_get( $url, array(
            'timeout'     => 15,
            'user-agent'  => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'sslverify'   => false,
            'redirection' => 5,
            'headers'     => array(
                'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language' => 'hi-IN,hi;q=0.9,en-IN;q=0.8,en;q=0.7',
            ),
        ) );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return '';
        }

        $html = wp_remote_retrieve_body( $response );
        if ( empty( $html ) ) {
            return '';
        }

        // Encoding fix: agar UTF-8 nahi hai to convert karo (kai Indian news
        // sites declared charset sahi se nahi bhejte).
        if ( function_exists( 'mb_convert_encoding' ) && ! mb_check_encoding( $html, 'UTF-8' ) ) {
            $converted = mb_convert_encoding( $html, 'UTF-8', 'auto' );
            if ( $converted ) {
                $html = $converted;
            }
        }

        // Script/style/noscript blocks hata do — warna unka text bhi pick ho jaayega.
        $html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $html );
        $html = preg_replace( '#<style\b[^>]*>.*?</style>#is', '', $html );
        $html = preg_replace( '#<noscript\b[^>]*>.*?</noscript>#is', '', $html );

        $body = $this->extract_article_container( $html );
        if ( empty( $body ) ) {
            $body = $this->extract_largest_paragraph_block( $html );
        }

        return $body;
    }

    /**
     * Common article-body container patterns try karo (class/id ke through).
     * Zyadatar WordPress/CMS-driven Indian news sites in patterns ko follow karte hain.
     *
     * @param string $html Full page HTML.
     * @return string Extracted inner HTML ya empty string.
     */
    private function extract_article_container( $html ) {
        $patterns = array(
            'article[^>]*itemprop=["\']articleBody["\']',
            'div[^>]*itemprop=["\']articleBody["\']',
            '[a-z0-9]+[^>]*class=["\'][^"\']*\b(?:article[-_]?body|article[-_]?content|story[-_]?body|story[-_]?content|post[-_]?content|entry[-_]?content|content[-_]?body)\b[^"\']*["\']',
            'article[^>]*class=["\'][^"\']*\bcontent\b[^"\']*["\']',
        );

        foreach ( $patterns as $pattern ) {
            if ( preg_match( '#<(' . $pattern . ')[^>]*>(.*?)</[a-z0-9]+>#is', $html, $m ) ) {
                $inner = $m[2];
                $text  = trim( wp_strip_all_tags( $inner ) );
                // Bahut chhota match ho to skip karo, false positive ho sakta hai.
                if ( str_word_count( $text ) >= 30 || mb_strlen( $text ) >= 150 ) {
                    return $this->sanitize_scraped_html( $inner );
                }
            }
        }

        return '';
    }

    /**
     * Fallback: page ke saare <p> tags collect karo aur unhe jod do.
     * Boilerplate (nav, footer, share-buttons, copyright lines) wale chhote
     * paragraphs ko length aur common-phrase filters se chhanate hain.
     *
     * @param string $html Full page HTML.
     * @return string Extracted HTML (paragraphs joined) ya empty string.
     */
    private function extract_largest_paragraph_block( $html ) {
        if ( ! preg_match_all( '#<p\b[^>]*>(.*?)</p>#is', $html, $matches ) ) {
            return '';
        }

        $skip_phrases = array(
            'cookie', 'subscribe', 'newsletter', 'all rights reserved',
            'follow us', 'download the app', 'click here', 'read more',
            'सब्सक्राइब', 'न्यूज़लेटर', 'फॉलो करें',
        );

        $good_paragraphs = array();
        foreach ( $matches[1] as $p_inner ) {
            $text = trim( wp_strip_all_tags( $p_inner ) );
            if ( mb_strlen( $text ) < 40 ) {
                continue; // Bahut chhota — likely UI/nav text.
            }
            $lower = mb_strtolower( $text );
            $skip  = false;
            foreach ( $skip_phrases as $phrase ) {
                if ( mb_strpos( $lower, mb_strtolower( $phrase ) ) !== false ) {
                    $skip = true;
                    break;
                }
            }
            if ( $skip ) {
                continue;
            }
            $good_paragraphs[] = '<p>' . $p_inner . '</p>';
        }

        if ( count( $good_paragraphs ) < 2 ) {
            return ''; // Itna kam mila to scraping fail mano, original content rakho.
        }

        return $this->sanitize_scraped_html( implode( "\n", $good_paragraphs ) );
    }

    /**
     * Scraped HTML ko safe/clean rakhne ke liye basic sanitize.
     * Sirf allowed tags rakhega — wp_kses_post jaisa hi behavior.
     *
     * @param string $html Raw scraped HTML.
     * @return string Sanitized HTML.
     */
    private function sanitize_scraped_html( $html ) {
        // Inline scripts/event handlers hata do (defense-in-depth, upar bhi strip ho chuka hai).
        $html = preg_replace( '/\son\w+\s*=\s*"[^"]*"/i', '', $html );
        $html = preg_replace( "/\son\w+\s*=\s*'[^']*'/i", '', $html );
        return wp_kses_post( $html );
    }

    /**
     * Fetch a URL with multiple fallback strategies.
     * Kuch APIs browser simulation chahte hain — yeh function multiple strategies try karta hai.
     *
     * @param string $url Feed URL.
     * @return string|WP_Error Raw body or error.
     */
    private function fetch_url( $url ) {
        $strategies = array(
            // Strategy 1: Chrome browser simulation
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'headers'    => array(
                    'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Accept-Language' => 'hi-IN,hi;q=0.9,en-IN;q=0.8,en;q=0.7',
                    'Accept-Encoding' => 'gzip, deflate, br',
                    'Referer'         => ( parse_url( $url, PHP_URL_SCHEME ) ?: 'https' ) . '://' . ( parse_url( $url, PHP_URL_HOST ) ?: '' ) . '/',
                    'Cache-Control'   => 'no-cache',
                    'Pragma'          => 'no-cache',
                ),
            ),
            // Strategy 2: Firefox simulation
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
                'headers'    => array(
                    'Accept'          => 'application/rss+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language' => 'hi,en;q=0.5',
                    'Referer'         => home_url(),
                    'Cache-Control'   => 'max-age=0',
                ),
            ),
            // Strategy 3: Generic RSS reader
            array(
                'user-agent' => 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)',
                'headers'    => array(
                    'Accept' => 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*',
                ),
            ),
        );

        foreach ( $strategies as $strategy ) {
            $response = wp_remote_get( $url, array(
                'timeout'    => 20,
                'user-agent' => $strategy['user-agent'],
                'headers'    => $strategy['headers'],
                'sslverify'  => false,
                'redirection' => 5,
            ) );

            if ( is_wp_error( $response ) ) {
                continue;
            }

            $code = wp_remote_retrieve_response_code( $response );
            if ( $code === 200 ) {
                $body = wp_remote_retrieve_body( $response );
                if ( ! empty( $body ) ) {
                    return $body;
                }
            }
        }

        return new WP_Error( 'fetch_failed', sprintf( 'Feed fetch failed. Server ne request block kar di (tried %d strategies).', count( $strategies ) ) );
    }

    /**
     * Parse a single SimplePie item into a structured array.
     *
     * @param SimplePie_Item $rss_item SimplePie item.
     * @param object         $feed     Feed database object.
     * @return array|false Structured item or false on failure.
     */
    /**
     * JSON API feeds parse karo — IndiaTV, aur similar JSON news APIs ke liye
     */
    private function parse_json_feed( $body, $feed ) {
        $logger = AE_Logger::get_instance();
        $data   = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE || empty( $data ) ) {
            $logger->log( $feed->id, 'error', 'JSON feed parse error: ' . json_last_error_msg() );
            return array();
        }

        // Items array dhundho — common JSON feed structures handle karo
        $items_raw = array();

        // Structure 1: {"data": {"news": [...]}} — IndiaTV style
        if ( isset( $data['data']['news'] ) && is_array( $data['data']['news'] ) ) {
            $items_raw = $data['data']['news'];
        }
        // Structure 2: {"items": [...]}
        elseif ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
            $items_raw = $data['items'];
        }
        // Structure 3: {"articles": [...]} — NewsAPI style
        elseif ( isset( $data['articles'] ) && is_array( $data['articles'] ) ) {
            $items_raw = $data['articles'];
        }
        // Structure 4: {"feed": {...}, "entries": [...]} — JSON Feed spec
        elseif ( isset( $data['entries'] ) && is_array( $data['entries'] ) ) {
            $items_raw = $data['entries'];
        }
        // Structure 5: Root level array
        elseif ( is_array( $data ) && isset( $data[0] ) ) {
            $items_raw = $data;
        }
        // Structure 6: {"data": [...]}
        elseif ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
            $items_raw = $data['data'];
        }

        if ( empty( $items_raw ) ) {
            $logger->log( $feed->id, 'fetch', 'JSON feed: Koi items nahi mile. Response structure check karo.' );
            return array();
        }

        $category_ids = ! empty( $feed->category_ids )
            ? array_filter( array_map( 'absint', (array) json_decode( $feed->category_ids, true ) ) )
            : array();

        $items = array();
        foreach ( $items_raw as $raw ) {
            if ( ! is_array( $raw ) ) continue;

            // Title — common field names
            $title = $raw['title'] ?? $raw['headline'] ?? $raw['name'] ?? $raw['post_title'] ?? '';
            $title = wp_strip_all_tags( html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ) );
            if ( empty( trim( $title ) ) ) continue;

            // Link / URL
            $link = $raw['url'] ?? $raw['link'] ?? $raw['permalink'] ?? $raw['post_url'] ?? $raw['web_url'] ?? '';
            if ( empty( $link ) ) continue;

            // Content / Description
            $content = $raw['content'] ?? $raw['body'] ?? $raw['description'] ?? $raw['summary'] ?? $raw['post_content'] ?? '';
            if ( is_array( $content ) ) {
                $content = $content['html'] ?? $content['text'] ?? implode( ' ', $content );
            }

            // Date
            $date_raw = $raw['pubDate'] ?? $raw['published_at'] ?? $raw['date'] ?? $raw['created_at'] ?? $raw['post_date'] ?? '';
            $date     = ! empty( $date_raw ) ? strtotime( $date_raw ) : time();
            if ( ! $date ) $date = time();

            // Image — common field names
            $image = '';
            $image_fields = array( 'image', 'thumbnail', 'image_url', 'featured_image', 'media_url', 'photo', 'picture', 'img_url', 'coverImage' );
            foreach ( $image_fields as $field ) {
                if ( ! empty( $raw[ $field ] ) && is_string( $raw[ $field ] ) ) {
                    $image = $raw[ $field ];
                    break;
                }
            }
            // Nested image objects
            if ( empty( $image ) && ! empty( $raw['image']['url'] ) )      $image = $raw['image']['url'];
            if ( empty( $image ) && ! empty( $raw['thumbnail']['url'] ) )   $image = $raw['thumbnail']['url'];
            if ( empty( $image ) && ! empty( $raw['media'][0]['url'] ) )    $image = $raw['media'][0]['url'];
            if ( empty( $image ) && ! empty( $raw['images'][0] ) )          $image = $raw['images'][0];

            $items[] = array(
                'title'          => $title,
                'link'           => esc_url_raw( $link ),
                'content'        => wp_kses_post( $content ),
                'date'           => $date,
                'featured_image' => esc_url_raw( $image ),
                'category_ids'   => $category_ids,
                'feed_id'        => $feed->id,
                'image_mode'     => $feed->image_mode,
                'logo_watermark' => ! empty( $feed->logo_watermark ) ? 1 : 0,
                'logo_position'  => ! empty( $feed->logo_position ) ? $feed->logo_position : 'bottom-right',
                'logo_opacity'   => isset( $feed->logo_opacity ) ? intval( $feed->logo_opacity ) : 80,
                'logo_size'      => isset( $feed->logo_size )    ? intval( $feed->logo_size )    : 20,
                'logo_no_margin' => ! empty( $feed->logo_no_margin ) ? 1 : 0,
            );
        }

        $logger->log( $feed->id, 'fetch', sprintf( 'JSON feed: %d items mile.', count( $items ) ) );
        return $items;
    }

    private function parse_item( $rss_item, $feed ) {
        $title = $rss_item->get_title();
        $title = trim( wp_strip_all_tags( $title ) );
        $title = html_entity_decode( $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

        if ( empty( $title ) ) {
            return false;
        }

        $content = $rss_item->get_content();
        $link    = $rss_item->get_permalink();
        $date    = $rss_item->get_date( 'Y-m-d H:i:s' );
        $author  = '';

        $author_obj = $rss_item->get_author();
        if ( $author_obj ) {
            $author = $author_obj->get_name();
        }

        // Extract images
        $images = $this->extract_images( $rss_item, $content );

        // Determine featured image
        $featured_image = ! empty( $images ) ? $images[0] : '';

        // Fallback: Agar feed se koi image nahi mili, article URL se OG image try karo
        if ( empty( $featured_image ) && ! empty( $link ) ) {
            $og_image = $this->fetch_og_image( $link );
            if ( ! empty( $og_image ) ) {
                $featured_image = $og_image;
                $images[]       = $og_image;
            }
        }

        return array(
            'title'          => $title,
            'content'        => $content,
            'link'           => $link,
            'date'           => $date,
            'author'         => $author,
            'featured_image' => $featured_image,
            'all_images'     => $images,
            'tags'           => array(),
            'feed_id'        => $feed->id,
            'category_id'    => $feed->category_id,
            'category_ids'   => ( ! empty( $feed->category_ids ) && is_string( $feed->category_ids ) )
                                    ? array_filter( array_map( 'absint', (array) json_decode( $feed->category_ids, true ) ) )
                                    : array(),
            'image_mode'      => $feed->image_mode,
            'logo_watermark'  => ! empty( $feed->logo_watermark ) ? 1 : 0,
            'logo_position'   => ! empty( $feed->logo_position ) ? $feed->logo_position : 'bottom-right',
            'logo_opacity'    => isset( $feed->logo_opacity ) ? intval( $feed->logo_opacity ) : 80,
            'logo_size'       => isset( $feed->logo_size )    ? intval( $feed->logo_size )    : 20,
            'logo_no_margin'  => ! empty( $feed->logo_no_margin ) ? 1 : 0,
        );
    }

    /**
     * Extract images from a feed item.
     * Checks content, enclosures, and media namespace.
     * Priority: media:content (badi image) > enclosures > content HTML > media:thumbnail (fallback only)
     *
     * @param SimplePie_Item $rss_item SimplePie item.
     * @param string         $content  Item content HTML.
     * @return array Array of image URLs.
     */
    private function extract_images( $rss_item, $content ) {
        $images    = array();
        $thumbnail = '';

        // 1. media:thumbnail — sirf fallback ke liye save karo, abhi add mat karo
        // Kai feeds (jaise India TV News) mein thumbnail choti hoti hai (100x75 etc.)
        // aur media:content mein badi original image hoti hai.
        $thumb = $rss_item->get_item_tags( 'http://search.yahoo.com/mrss/', 'thumbnail' );
        if ( $thumb && isset( $thumb[0]['attribs']['']['url'] ) ) {
            $thumbnail = esc_url_raw( $thumb[0]['attribs']['']['url'] );
        }

        // 2. media:content — pehle check karo, yahan badi image hoti hai
        $media = $rss_item->get_item_tags( 'http://search.yahoo.com/mrss/', 'content' );
        if ( $media ) {
            foreach ( $media as $m ) {
                if ( isset( $m['attribs']['']['url'] ) ) {
                    $medium = isset( $m['attribs']['']['medium'] ) ? $m['attribs']['']['medium'] : '';
                    if ( $medium === 'image' || empty( $medium ) ) {
                        $url = esc_url_raw( $m['attribs']['']['url'] );
                        if ( ! empty( $url ) && ! in_array( $url, $images, true ) ) {
                            $images[] = $url;
                        }
                    }
                }
            }
        }

        // 3. Check enclosures
        $enclosure = $rss_item->get_enclosure();
        if ( $enclosure && $enclosure->get_link() ) {
            $type = $enclosure->get_type();
            if ( $type && strpos( $type, 'image' ) !== false ) {
                $url = esc_url_raw( $enclosure->get_link() );
                if ( ! in_array( $url, $images, true ) ) {
                    $images[] = $url;
                }
            }
        }

        // 4. Extract from content HTML
        if ( ! empty( $content ) ) {
            if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $matches ) ) {
                foreach ( $matches[1] as $img_url ) {
                    $img_url = esc_url_raw( $img_url );
                    if ( ! empty( $img_url ) && ! in_array( $img_url, $images, true ) ) {
                        $images[] = $img_url;
                    }
                }
            }
        }

        // 5. Agar koi badi image nahi mili, tab media:thumbnail ko fallback ke roop mein use karo
        if ( empty( $images ) && ! empty( $thumbnail ) ) {
            $images[] = $thumbnail;
        }

        return $images;
    }
}
