<?php
/**
 * Auto Engine Bridge API for Social Auto Poster
 *
 * Provides high-speed REST API endpoints for remote post publishing, connection verification,
 * and media management from the Social Auto Poster Web App.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Bridge_API {

    /**
     * Singleton instance.
     *
     * @var AE_Bridge_API|null
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return AE_Bridge_API
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    /**
     * Register REST API routes.
     */
    public function register_routes() {
        // Status / Ping route
        register_rest_route( 'auto-engine/v1', '/status', array(
            'methods'             => array( 'GET', 'POST' ),
            'callback'            => array( $this, 'handle_status' ),
            'permission_callback' => array( $this, 'verify_api_key' ),
        ) );

        // Direct Publish route
        register_rest_route( 'auto-engine/v1', '/publish', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'handle_publish' ),
            'permission_callback' => array( $this, 'verify_api_key' ),
        ) );

        // Categories list route
        register_rest_route( 'auto-engine/v1', '/categories', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'handle_get_categories' ),
            'permission_callback' => array( $this, 'verify_api_key' ),
        ) );
    }

    /**
     * Verify incoming secret key.
     *
     * @param WP_REST_Request $request Request object.
     * @return bool|WP_Error True if authorized, WP_Error otherwise.
     */
    public function verify_api_key( $request ) {
        $valid_key = get_option( 'ae_bridge_key', '' );
        if ( empty( $valid_key ) ) {
            $valid_key = get_option( 'ae_direct_cron_key', '' );
        }

        // 1. Check Header 'X-AE-Key'
        $header_key = $request->get_header( 'x_ae_key' );
        if ( ! empty( $header_key ) && hash_equals( $valid_key, $header_key ) ) {
            return true;
        }

        // 2. Check Authorization: Bearer <key>
        $auth_header = $request->get_header( 'authorization' );
        if ( ! empty( $auth_header ) && preg_match( '/Bearer\s+(.*)$/i', $auth_header, $matches ) ) {
            if ( hash_equals( $valid_key, trim( $matches[1] ) ) ) {
                return true;
            }
        }

        // 3. Check Query or Body Param 'ae_key'
        $param_key = $request->get_param( 'ae_key' );
        if ( ! empty( $param_key ) && hash_equals( $valid_key, $param_key ) ) {
            return true;
        }

        return new WP_Error(
            'ae_unauthorized',
            'Invalid or missing Auto Engine Bridge Secret Key. Please check the key in Auto Engine Settings -> Social Auto Poster Bridge.',
            array( 'status' => 401 )
        );
    }

    /**
     * Handle status ping request.
     *
     * @return WP_REST_Response
     */
    public function handle_status() {
        $categories = get_categories( array( 'hide_empty' => false ) );
        $cat_list   = array();
        foreach ( $categories as $cat ) {
            $cat_list[] = array(
                'id'    => $cat->term_id,
                'name'  => $cat->name,
                'slug'  => $cat->slug,
                'count' => $cat->count,
            );
        }

        return rest_ensure_response( array(
            'success'        => true,
            'site_name'      => get_bloginfo( 'name' ),
            'site_url'       => home_url(),
            'site_icon'      => get_site_icon_url(),
            'plugin_version' => defined( 'AE_VERSION' ) ? AE_VERSION : '7.5.0',
            'bridge_version' => '1.0',
            'server_time'    => current_time( 'mysql' ),
            'categories'     => $cat_list,
            'features'       => array(
                'watermark'    => true,
                'seo'          => true,
                'cleaner'      => true,
                'ai_rewriting' => true,
            ),
        ) );
    }

    /**
     * Handle publish request.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function handle_publish( $request ) {
        $logger = AE_Logger::get_instance();
        $params = $request->get_json_params();
        if ( empty( $params ) ) {
            $params = $request->get_params();
        }

        $title   = isset( $params['title'] ) ? sanitize_text_field( $params['title'] ) : '';
        $content = isset( $params['content'] ) ? wp_kses_post( $params['content'] ) : '';

        // If title is missing, generate title from content
        if ( empty( $title ) && ! empty( $content ) ) {
            $title = wp_trim_words( strip_tags( $content ), 10, '...' );
        }

        if ( empty( $title ) ) {
            return new WP_Error( 'missing_data', 'Post title or content is required.', array( 'status' => 400 ) );
        }

        // Get media/image
        $featured_image = '';
        if ( ! empty( $params['featured_image'] ) ) {
            $featured_image = trim( $params['featured_image'] );
        } elseif ( ! empty( $params['image_url'] ) ) {
            $featured_image = trim( $params['image_url'] );
        } elseif ( ! empty( $params['media_url'] ) ) {
            $featured_image = trim( $params['media_url'] );
        }

        $status = isset( $params['status'] ) && in_array( $params['status'], array( 'publish', 'draft', 'pending' ), true )
            ? $params['status']
            : 'publish';

        $category_id  = isset( $params['category_id'] ) ? absint( $params['category_id'] ) : 0;
        $category_ids = isset( $params['category_ids'] ) ? (array) $params['category_ids'] : array();
        if ( $category_id > 0 && ! in_array( $category_id, $category_ids, true ) ) {
            $category_ids[] = $category_id;
        }

        $tags = isset( $params['tags'] ) ? $params['tags'] : array();
        if ( is_string( $tags ) ) {
            $tags = array_map( 'trim', explode( ',', $tags ) );
        }

        // Enable watermark if explicitly requested or let Auto Engine settings dictate
        $logo_watermark = isset( $params['logo_watermark'] ) ? ! empty( $params['logo_watermark'] ) : false;

        // Base64 image handler
        $uploaded_attachment_id = 0;
        if ( ! empty( $featured_image ) && strpos( $featured_image, 'data:image/' ) === 0 ) {
            $uploaded_attachment_id = $this->sideload_base64_image( $featured_image, $title );
        }

        // Build post data for AE_Publisher
        $post_data = array(
            'title'          => $title,
            'content'        => $content,
            'featured_image' => empty( $uploaded_attachment_id ) ? $featured_image : '',
            'category_ids'   => $category_ids,
            'category_id'    => $category_id,
            'tags'           => $tags,
            'author_id'      => isset( $params['author_id'] ) ? absint( $params['author_id'] ) : 0,
            'logo_watermark' => $logo_watermark,
            'source'         => 'social_auto_poster_app',
        );

        $publisher = AE_Publisher::get_instance();
        $post_id   = $publisher->publish( $post_data );

        if ( is_wp_error( $post_id ) ) {
            $logger->log( 0, 'error', 'Bridge API publish error: ' . $post_id->get_error_message() );
            return new WP_Error( 'publish_failed', $post_id->get_error_message(), array( 'status' => 500 ) );
        }

        // If base64 image was converted to attachment, set as featured image
        if ( $uploaded_attachment_id > 0 ) {
            set_post_thumbnail( $post_id, $uploaded_attachment_id );
            if ( $logo_watermark ) {
                $images = AE_Image_Handler::get_instance();
                $images->apply_watermark( $uploaded_attachment_id );
            }
        }

        // If status was requested as draft or pending, update
        if ( $status !== 'publish' ) {
            wp_update_post( array(
                'ID'          => $post_id,
                'post_status' => $status,
            ) );
        }

        $permalink = get_permalink( $post_id );
        $logger->log( 0, 'publish', sprintf( 'Post published via Bridge API: "%s" (ID: %d)', $title, $post_id ) );

        return rest_ensure_response( array(
            'success'   => true,
            'post_id'   => $post_id,
            'url'       => $permalink,
            'permalink' => $permalink,
            'title'     => get_the_title( $post_id ),
            'status'    => get_post_status( $post_id ),
            'message'   => 'Post published successfully on WordPress via Auto Engine Bridge',
        ) );
    }

    /**
     * Sideload a base64 image string into WordPress media library.
     *
     * @param string $base64_data Base64 data string.
     * @param string $title       Image title.
     * @return int Attachment ID or 0 on failure.
     */
    private function sideload_base64_image( $base64_data, $title = '' ) {
        if ( ! function_exists( 'media_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        if ( preg_match( '/^data:image\/(\w+);base64,/', $base64_data, $type ) ) {
            $data = substr( $base64_data, strpos( $base64_data, ',' ) + 1 );
            $type = strtolower( $type[1] ); // jpg, png, webp, gif

            if ( in_array( $type, array( 'pjpeg', 'jpeg' ), true ) ) {
                $type = 'jpg';
            }

            $decoded = base64_decode( $data );
            if ( false === $decoded ) {
                return 0;
            }

            $tmp_name = wp_tempnam( 'ae_bridge_' );
            file_put_contents( $tmp_name, $decoded );

            $file_array = array(
                'name'     => sanitize_file_name( ( $title ? sanitize_title( $title ) : 'post-image' ) . '-' . time() . '.' . $type ),
                'tmp_name' => $tmp_name,
            );

            $attachment_id = media_handle_sideload( $file_array, 0 );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $tmp_name );
                return 0;
            }

            return $attachment_id;
        }

        return 0;
    }

    /**
     * Handle categories retrieval.
     *
     * @return WP_REST_Response
     */
    public function handle_get_categories() {
        $categories = get_categories( array( 'hide_empty' => false ) );
        $result = array();
        foreach ( $categories as $cat ) {
            $result[] = array(
                'id'    => $cat->term_id,
                'name'  => $cat->name,
                'slug'  => $cat->slug,
                'count' => $cat->count,
            );
        }
        return rest_ensure_response( array(
            'success'    => true,
            'categories' => $result,
        ) );
    }
}
