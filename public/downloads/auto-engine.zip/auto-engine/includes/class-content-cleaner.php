<?php
/**
 * Content Cleaner — cleans HTML content from RSS feeds.
 *
 * Removes links, tracking URLs, unwanted patterns while preserving
 * headings, embeds, and HTML structure.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Content_Cleaner {

    /**
     * Singleton instance.
     *
     * @var AE_Content_Cleaner|null
     */
    private static $instance = null;

    /**
     * Patterns to remove (text content).
     *
     * @var array
     */
    private $remove_patterns = array(
        '/\bRead\s+more\b\.?/i',
        '/\bClick\s+here\b\.?/i',
        '/\bContinue\s+reading\b\.?/i',
        '/\bRead\s+the\s+full\s+(article|story|post)\b\.?/i',
        '/\bView\s+original\b\.?/i',
        '/\bSource\s*:\s*.*/i',
        '/\bvia\s+\S+/i',
        '/\bThe\s+post\s+.*\s+appeared\s+first\s+on\s+.*/i',
        '/\[\.{3}\]/i',
        '/\[\.\.\.\]/i',
        '/\bAlso\s+Read\s*:?\s*/i',
        '/यह\s*भी\s*पढ़ें\s*:?\s*/u',
        '/ये\s*भी\s*पढ़ें\s*:?\s*/u',
        '/और\s*पढ़ें\s*:?\s*/u',
    );

    /**
     * Embed domains to preserve.
     *
     * @var array
     */
    private $embed_domains = array(
        'youtube.com',
        'youtu.be',
        'vimeo.com',
        'twitter.com',
        'x.com',
        'instagram.com',
        'facebook.com',
        'tiktok.com',
        'dailymotion.com',
        'soundcloud.com',
        'spotify.com',
        'reddit.com',
    );

    /**
     * Get singleton instance.
     *
     * @return AE_Content_Cleaner
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Clean content from an RSS item.
     *
     * @param string $content    Raw HTML content.
     * @param string $image_mode 'featured_only' or 'all_images'.
     * @return string Cleaned HTML content.
     */
    public function clean( $content, $image_mode = 'featured_only' ) {
        if ( empty( $content ) ) {
            return '';
        }

        // Normalize encoding
        $content = mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' );

        // Protect embeds before processing
        $content = $this->protect_embeds( $content );

        // Use DOMDocument for safe HTML manipulation
        $content = $this->process_with_dom( $content, $image_mode );

        // Clean up text patterns
        $content = $this->clean_text_patterns( $content );

        // Restore protected embeds
        $content = $this->restore_embeds( $content );

        // Final cleanup
        $content = $this->final_cleanup( $content );

        return $content;
    }

    /**
     * Store for protected embeds.
     *
     * @var array
     */
    private $protected_embeds = array();

    /**
     * Protect embed tags by replacing with placeholders.
     *
     * @param string $content HTML content.
     * @return string Content with embed placeholders.
     */
    private function protect_embeds( $content ) {
        $this->protected_embeds = array();

        // Protect iframes
        $content = preg_replace_callback(
            '/<iframe[^>]*>.*?<\/iframe>/is',
            function ( $matches ) {
                $key = '<!--AE_EMBED_' . count( $this->protected_embeds ) . '-->';
                $this->protected_embeds[ $key ] = $matches[0];
                return $key;
            },
            $content
        );

        // Protect embed tags
        $content = preg_replace_callback(
            '/<embed[^>]*\/?>/is',
            function ( $matches ) {
                $key = '<!--AE_EMBED_' . count( $this->protected_embeds ) . '-->';
                $this->protected_embeds[ $key ] = $matches[0];
                return $key;
            },
            $content
        );

        // Protect object tags
        $content = preg_replace_callback(
            '/<object[^>]*>.*?<\/object>/is',
            function ( $matches ) {
                $key = '<!--AE_EMBED_' . count( $this->protected_embeds ) . '-->';
                $this->protected_embeds[ $key ] = $matches[0];
                return $key;
            },
            $content
        );

        // Protect blockquote embeds (Twitter, Instagram)
        $content = preg_replace_callback(
            '/<blockquote[^>]*class=["\'][^"\']*(?:twitter-tweet|instagram-media|tiktok-embed)[^"\']*["\'][^>]*>.*?<\/blockquote>/is',
            function ( $matches ) {
                $key = '<!--AE_EMBED_' . count( $this->protected_embeds ) . '-->';
                $this->protected_embeds[ $key ] = $matches[0];
                return $key;
            },
            $content
        );

        // Protect script tags related to embeds
        $content = preg_replace_callback(
            '/<script[^>]*(?:platform\.twitter|instagram\.com\/embed|tiktok\.com|youtube\.com)[^>]*>.*?<\/script>/is',
            function ( $matches ) {
                $key = '<!--AE_EMBED_' . count( $this->protected_embeds ) . '-->';
                $this->protected_embeds[ $key ] = $matches[0];
                return $key;
            },
            $content
        );

        return $content;
    }

    /**
     * Restore protected embeds from placeholders.
     *
     * @param string $content Content with placeholders.
     * @return string Content with embeds restored.
     */
    private function restore_embeds( $content ) {
        foreach ( $this->protected_embeds as $key => $embed ) {
            $content = str_replace( $key, $embed, $content );
        }
        return $content;
    }

    /**
     * Process HTML with DOMDocument.
     *
     * @param string $content    HTML content.
     * @param string $image_mode Image handling mode.
     * @return string Processed HTML.
     */
    private function process_with_dom( $content, $image_mode ) {
        // Suppress libxml errors
        $prev = libxml_use_internal_errors( true );

        $doc = new DOMDocument( '1.0', 'UTF-8' );
        $doc->loadHTML(
            '<html><body>' . $content . '</body></html>',
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );

        libxml_clear_errors();
        libxml_use_internal_errors( $prev );

        // Remove all anchor tags but keep their text content
        $this->strip_anchors( $doc );

        // Remove images if featured_only mode
        if ( $image_mode === 'featured_only' ) {
            $this->strip_images( $doc );
        }

        // Remove unwanted tags
        $this->strip_unwanted_tags( $doc );

        // Get the body content
        $body = $doc->getElementsByTagName( 'body' )->item( 0 );
        if ( ! $body ) {
            return $content;
        }

        $output = '';
        foreach ( $body->childNodes as $node ) {
            $output .= $doc->saveHTML( $node );
        }

        return $output;
    }

    /**
     * Strip anchor tags AND their text content completely.
     * Social media embed links (YouTube, Twitter, Instagram, Facebook, etc.) are preserved.
     *
     * @param DOMDocument $doc DOM document.
     */
    private function strip_anchors( $doc ) {
        $anchors = $doc->getElementsByTagName( 'a' );
        $to_remove = array();

        // Collect anchors to remove (can't modify while iterating)
        for ( $i = 0; $i < $anchors->length; $i++ ) {
            $anchor = $anchors->item( $i );

            // Check if this anchor is an embed link (YouTube, Twitter, Instagram, FB, etc.)
            $href = $anchor->getAttribute( 'href' );
            if ( $this->is_embed_url( $href ) ) {
                continue; // Keep social media embed links as-is
            }

            $to_remove[] = $anchor;
        }

        // Remove anchors AND their text content completely
        foreach ( $to_remove as $anchor ) {
            $parent = $anchor->parentNode;
            if ( $parent ) {
                $parent->removeChild( $anchor );
            }
        }
    }

    /**
     * Check if a URL is an embed URL that should be preserved.
     *
     * @param string $url URL to check.
     * @return bool True if it's an embed URL.
     */
    private function is_embed_url( $url ) {
        if ( empty( $url ) ) {
            return false;
        }

        $parsed = wp_parse_url( $url );
        if ( ! isset( $parsed['host'] ) ) {
            return false;
        }

        $host = strtolower( $parsed['host'] );

        foreach ( $this->embed_domains as $domain ) {
            if ( $host === $domain || strpos( $host, '.' . $domain ) !== false ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Strip all image tags from content.
     *
     * @param DOMDocument $doc DOM document.
     */
    private function strip_images( $doc ) {
        $images = $doc->getElementsByTagName( 'img' );
        $to_remove = array();

        for ( $i = 0; $i < $images->length; $i++ ) {
            $to_remove[] = $images->item( $i );
        }

        foreach ( $to_remove as $img ) {
            if ( $img->parentNode ) {
                // If image is inside a figure, remove the whole figure
                $parent = $img->parentNode;
                if ( $parent->nodeName === 'figure' ) {
                    if ( $parent->parentNode ) {
                        $parent->parentNode->removeChild( $parent );
                    }
                } elseif ( $parent->nodeName === 'picture' ) {
                    if ( $parent->parentNode ) {
                        $parent->parentNode->removeChild( $parent );
                    }
                } else {
                    $parent->removeChild( $img );
                }
            }
        }
    }

    /**
     * Strip unwanted tags (scripts, styles, forms, etc.).
     * Keeps: p, h1-h6, ul, ol, li, blockquote, pre, code, strong, em, br, div, span, figure, figcaption
     *
     * @param DOMDocument $doc DOM document.
     */
    private function strip_unwanted_tags( $doc ) {
        $remove_tags = array( 'script', 'style', 'form', 'input', 'button', 'select', 'textarea', 'nav', 'footer', 'aside' );
        $to_remove = array();

        foreach ( $remove_tags as $tag ) {
            $elements = $doc->getElementsByTagName( $tag );
            for ( $i = 0; $i < $elements->length; $i++ ) {
                $el = $elements->item( $i );
                // Don't remove embed-related scripts (they're already protected)
                if ( $tag === 'script' ) {
                    $src = $el->getAttribute( 'src' );
                    if ( $this->is_embed_url( $src ) ) {
                        continue;
                    }
                }
                $to_remove[] = $el;
            }
        }

        foreach ( $to_remove as $el ) {
            if ( $el->parentNode ) {
                $el->parentNode->removeChild( $el );
            }
        }
    }

    /**
     * Clean text patterns (Read more, Click here, etc.).
     *
     * @param string $content HTML content.
     * @return string Cleaned content.
     */
    private function clean_text_patterns( $content ) {
        foreach ( $this->remove_patterns as $pattern ) {
            $content = preg_replace( $pattern, '', $content );
        }

        return $content;
    }

    /**
     * Final cleanup of the content.
     *
     * @param string $content HTML content.
     * @return string Cleaned content.
     */
    private function final_cleanup( $content ) {
        // Remove empty paragraphs
        $content = preg_replace( '/<p>\s*<\/p>/i', '', $content );

        // Remove excessive whitespace
        $content = preg_replace( '/\n{3,}/', "\n\n", $content );

        // Remove empty divs
        $content = preg_replace( '/<div>\s*<\/div>/i', '', $content );

        // Trim
        $content = trim( $content );

        // Normalize line breaks
        $content = wpautop( $content );

        return $content;
    }

    /**
     * Get the word count of content.
     *
     * str_word_count() sirf ASCII letters (a-z/A-Z) count karta hai, isliye
     * Hindi/Devanagari ya kisi bhi non-Latin script ke liye galat (bahut kam)
     * ginti deta hai. Yahan dono scripts ke liye sahi se gin rahe hain:
     * - Devanagari runs (\x{0900}-\x{097F}) ko words count karo
     * - Baaki Latin/ASCII words ko str_word_count se count karo
     *
     * @param string $content HTML content.
     * @return int Word count.
     */
    public function get_word_count( $content ) {
        $text = trim( wp_strip_all_tags( $content ) );
        if ( '' === $text ) {
            return 0;
        }

        // Devanagari (Hindi) words — consecutive Devanagari chars ek word maano.
        $devanagari_words = 0;
        if ( preg_match_all( '/[\x{0900}-\x{097F}]+/u', $text, $matches ) ) {
            $devanagari_words = count( $matches[0] );
        }

        // Devanagari text hata kar baaki (Latin/ASCII) words count karo,
        // taaki mixed Hindi+English content mein double-count na ho.
        $remaining   = preg_replace( '/[\x{0900}-\x{097F}]+/u', ' ', $text );
        $ascii_words = str_word_count( $remaining );

        return $devanagari_words + $ascii_words;
    }
}
