<?php
/**
 * Uninstall Auto Engine — clean up all data.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Drop custom tables
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ae_feeds" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ae_logs" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ae_processed" );

// Delete options
delete_option( 'auto_engine_settings' );
delete_option( 'ae_db_version' );

// Clear any transients
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ae_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_ae_%'" );

// Clear scheduled cron
wp_clear_scheduled_hook( 'auto_engine_cron_hook' );
