<?php
/**
 * Admin — handles admin menus, pages, AJAX handlers, and asset enqueuing.
 *
 * @package Auto_Engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AE_Admin {

    /**
     * Singleton instance.
     *
     * @var AE_Admin|null
     */
    private static $instance = null;

    /**
     * Admin page hook suffix.
     *
     * @var string
     */
    private $page_hook;

    /**
     * Constructor.
     */
    private function __construct() {
        add_action( 'admin_menu', array( $this, 'register_menus' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        // AJAX handlers
        add_action( 'wp_ajax_ae_get_stats', array( $this, 'ajax_get_stats' ) );
        add_action( 'wp_ajax_ae_add_feed', array( $this, 'ajax_add_feed' ) );
        add_action( 'wp_ajax_ae_update_feed', array( $this, 'ajax_update_feed' ) );
        add_action( 'wp_ajax_ae_delete_feed', array( $this, 'ajax_delete_feed' ) );
        add_action( 'wp_ajax_ae_toggle_feed', array( $this, 'ajax_toggle_feed' ) );
        add_action( 'wp_ajax_ae_test_feed', array( $this, 'ajax_test_feed' ) );
        add_action( 'wp_ajax_ae_get_feeds', array( $this, 'ajax_get_feeds' ) );
        add_action( 'wp_ajax_ae_fetch_now', array( $this, 'ajax_fetch_now' ) );
        add_action( 'wp_ajax_ae_save_settings', array( $this, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_ae_get_logs', array( $this, 'ajax_get_logs' ) );
        add_action( 'wp_ajax_ae_clear_logs', array( $this, 'ajax_clear_logs' ) );
        add_action( 'wp_ajax_ae_test_ai', array( $this, 'ajax_test_ai' ) );
        add_action( 'wp_ajax_ae_reprocess_post', array( $this, 'ajax_reprocess_post' ) );
        add_action( 'wp_ajax_ae_save_cron_settings', array( $this, 'ajax_save_cron_settings' ) );
        add_action( 'wp_ajax_ae_generate_cron_key', array( $this, 'ajax_generate_cron_key' ) );
        add_action( 'wp_ajax_ae_test_cron', array( $this, 'ajax_test_cron' ) );
        add_action( 'wp_ajax_ae_export_feeds', array( $this, 'ajax_export_feeds' ) );
        add_action( 'wp_ajax_ae_import_feeds', array( $this, 'ajax_import_feeds' ) );

        // "All Posts" list table mein Auto Engine source feed column (Screen Options se toggle hoti hai).
        add_filter( 'manage_post_posts_columns', array( $this, 'add_feed_source_column' ) );
        add_action( 'manage_post_posts_custom_column', array( $this, 'render_feed_source_column' ), 10, 2 );
    }

    /**
     * Get singleton instance.
     *
     * @return AE_Admin
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register admin menus.
     */
    public function register_menus() {
        $this->page_hook = add_menu_page(
            __( 'Auto Engine', 'auto-engine' ),
            __( 'Auto Engine', 'auto-engine' ),
            'manage_options',
            'auto-engine',
            array( $this, 'render_dashboard' ),
            'dashicons-rss',
            30
        );

        add_submenu_page(
            'auto-engine',
            __( 'Dashboard', 'auto-engine' ),
            __( 'Dashboard', 'auto-engine' ),
            'manage_options',
            'auto-engine',
            array( $this, 'render_dashboard' )
        );

        add_submenu_page(
            'auto-engine',
            __( 'Feed Manager', 'auto-engine' ),
            __( 'Feed Manager', 'auto-engine' ),
            'manage_options',
            'auto-engine-feeds',
            array( $this, 'render_feeds' )
        );

        add_submenu_page(
            'auto-engine',
            __( 'Settings', 'auto-engine' ),
            __( 'Settings', 'auto-engine' ),
            'manage_options',
            'auto-engine-settings',
            array( $this, 'render_settings' )
        );

        add_submenu_page(
            'auto-engine',
            __( 'Logs', 'auto-engine' ),
            __( 'Logs', 'auto-engine' ),
            'manage_options',
            'auto-engine-logs',
            array( $this, 'render_logs' )
        );
    }

    /**
     * Enqueue admin assets.
     *
     * @param string $hook Current admin page hook.
     */
    public function enqueue_assets( $hook ) {
        // Only load on our pages
        $our_pages = array(
            'toplevel_page_auto-engine',
            'auto-engine_page_auto-engine-feeds',
            'auto-engine_page_auto-engine-settings',
            'auto-engine_page_auto-engine-logs',
            'auto-engine_page_auto-engine-cron',
        );

        if ( ! in_array( $hook, $our_pages, true ) ) {
            return;
        }

        // Enqueue WordPress media uploader for watermark
        wp_enqueue_media();

        wp_enqueue_style(
            'ae-admin-style',
            AE_PLUGIN_URL . 'admin/css/admin-style.css',
            array(),
            AE_VERSION
        );

        wp_enqueue_script(
            'ae-admin-script',
            AE_PLUGIN_URL . 'admin/js/admin-script.js',
            array( 'jquery' ),
            AE_VERSION,
            true
        );

        // Get all categories for the feed modal
        $categories = get_categories( array(
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ) );

        $cat_options = array();
        foreach ( $categories as $cat ) {
            $cat_options[] = array(
                'id'   => $cat->term_id,
                'name' => $cat->name,
            );
        }

        // Get all WordPress authors/users
        $users = get_users( array(
            'orderby' => 'display_name',
            'order'   => 'ASC',
            'fields'  => array( 'ID', 'display_name' ),
        ) );

        $author_options = array();
        foreach ( $users as $user ) {
            $author_options[] = array(
                'id'   => $user->ID,
                'name' => $user->display_name,
            );
        }

        wp_localize_script( 'ae-admin-script', 'aeAdmin', array(
            'ajax_url'         => admin_url( 'admin-ajax.php' ),
            'admin_url'        => admin_url(),
            'site_url'         => site_url(),
            'nonce'            => wp_create_nonce( 'ae_admin_nonce' ),
            'categories'       => $cat_options,
            'authors'          => $author_options,
            'settings'         => get_option( 'auto_engine_settings', array() ),
            'last_bulk_fetch_ts' => absint( get_option( 'ae_last_bulk_fetch_ts', 0 ) ),
            'strings'          => array(
                'confirm_delete'  => __( 'Are you sure you want to delete this feed?', 'auto-engine' ),
                'confirm_clear'   => __( 'Are you sure you want to clear all logs?', 'auto-engine' ),
                'saving'          => __( 'Saving...', 'auto-engine' ),
                'saved'           => __( 'Settings saved!', 'auto-engine' ),
                'error'           => __( 'An error occurred.', 'auto-engine' ),
                'fetching'        => __( 'Fetching...', 'auto-engine' ),
                'testing'         => __( 'Testing feed...', 'auto-engine' ),
                'processing'      => __( 'Processing...', 'auto-engine' ),
            ),
        ) );
    }

    /**
     * Render dashboard page.
     */
    public function render_dashboard() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Unauthorized access.', 'auto-engine' ) );
        }
        include AE_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    /**
     * Render feeds page.
     */
    public function render_feeds() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Unauthorized access.', 'auto-engine' ) );
        }
        include AE_PLUGIN_DIR . 'admin/views/feeds.php';
    }

    /**
     * Render settings page.
     */
    public function render_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Unauthorized access.', 'auto-engine' ) );
        }
        include AE_PLUGIN_DIR . 'admin/views/settings.php';
    }

    /**
     * Render logs page.
     */
    public function render_logs() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Unauthorized access.', 'auto-engine' ) );
        }
        include AE_PLUGIN_DIR . 'admin/views/logs.php';
    }

    // ─── AJAX Handlers ───

    /**
     * Verify AJAX request.
     *
     * @return bool
     */
    private function verify_ajax() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized.' ), 403 );
            return false;
        }

        if ( ! check_ajax_referer( 'ae_admin_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
            return false;
        }

        return true;
    }

    /**
     * AJAX: Get dashboard stats.
     */
    public function ajax_get_stats() {
        $this->verify_ajax();
        $stats = AE_Auto_Engine::get_instance()->get_stats();
        wp_send_json_success( $stats );
    }

    /**
     * AJAX: Add a feed.
     */
    public function ajax_add_feed() {
        $this->verify_ajax();

        $data = array(
            'feed_url'       => isset( $_POST['feed_url'] ) ? esc_url_raw( wp_unslash( $_POST['feed_url'] ) ) : '',
            'feed_name'      => isset( $_POST['feed_name'] ) ? sanitize_text_field( wp_unslash( $_POST['feed_name'] ) ) : '',
            'category_ids'   => isset( $_POST['category_ids'] ) && is_array( $_POST['category_ids'] )
                                    ? array_map( 'absint', $_POST['category_ids'] )
                                    : ( isset( $_POST['category_ids'] ) ? array( absint( $_POST['category_ids'] ) ) : array() ),
            'fetch_mode'     => isset( $_POST['fetch_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['fetch_mode'] ) ) : 'new_only',
            'image_mode'     => isset( $_POST['image_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['image_mode'] ) ) : 'featured_only',
            'fetch_interval' => isset( $_POST['fetch_interval'] ) ? max( 1, absint( $_POST['fetch_interval'] ) ) : 10,
            'author_id'      => isset( $_POST['author_id'] ) ? absint( $_POST['author_id'] ) : 0,
            'logo_watermark' => ! empty( $_POST['logo_watermark'] ) ? 1 : 0,
            'logo_position'  => isset( $_POST['logo_position'] ) ? sanitize_text_field( wp_unslash( $_POST['logo_position'] ) ) : 'bottom-right',
            'logo_opacity'   => isset( $_POST['logo_opacity'] )   ? max( 0, min( 100, intval( $_POST['logo_opacity'] ) ) ) : 80,
            'logo_size'      => isset( $_POST['logo_size'] )      ? max( 5, min( 80,  intval( $_POST['logo_size'] ) ) )    : 20,
            'logo_no_margin' => ! empty( $_POST['logo_no_margin'] ) ? 1 : 0,
            'content_mode'   => isset( $_POST['content_mode'] ) && in_array( $_POST['content_mode'], array( 'direct', 'translate', 'api_translate' ), true ) ? $_POST['content_mode'] : 'direct',
        );

        $feed_id = AE_Feed_Manager::get_instance()->add_feed( $data );

        if ( false === $feed_id ) {
            wp_send_json_error( array( 'message' => 'Failed to add feed. Please check the URL.' ) );
        }

        // Debug: saved feed wapas bhejo taaki JS mein verify ho sake
        $saved_feed = AE_Feed_Manager::get_instance()->get_feed( $feed_id );
        wp_send_json_success( array(
            'message'      => 'Feed added successfully!',
            'feed_id'      => $feed_id,
            'debug_cat_id' => $saved_feed ? $saved_feed->category_id : 'N/A',
            'debug_cat_ids'=> $saved_feed ? $saved_feed->category_ids : 'N/A',
        ) );
    }

    /**
     * AJAX: Update a feed.
     */
    public function ajax_update_feed() {
        $this->verify_ajax();

        $feed_id = isset( $_POST['feed_id'] ) ? absint( $_POST['feed_id'] ) : 0;
        if ( ! $feed_id ) {
            wp_send_json_error( array( 'message' => 'Invalid feed ID.' ) );
        }

        $data = array();
        if ( isset( $_POST['feed_url'] ) ) {
            $data['feed_url'] = esc_url_raw( wp_unslash( $_POST['feed_url'] ) );
        }
        if ( isset( $_POST['feed_name'] ) ) {
            $data['feed_name'] = sanitize_text_field( wp_unslash( $_POST['feed_name'] ) );
        }
        if ( isset( $_POST['category_ids'] ) ) {
            $raw_ids = $_POST['category_ids'];
            $data['category_ids'] = is_array( $raw_ids )
                ? array_map( 'absint', $raw_ids )
                : array( absint( $raw_ids ) );
        }
        if ( isset( $_POST['fetch_mode'] ) ) {
            $data['fetch_mode'] = sanitize_text_field( wp_unslash( $_POST['fetch_mode'] ) );
        }
        if ( isset( $_POST['image_mode'] ) ) {
            $data['image_mode'] = sanitize_text_field( wp_unslash( $_POST['image_mode'] ) );
        }
        if ( isset( $_POST['fetch_interval'] ) ) {
            $data['fetch_interval'] = max( 1, absint( $_POST['fetch_interval'] ) );
        }
        if ( isset( $_POST['author_id'] ) ) {
            $data['author_id'] = absint( $_POST['author_id'] );
        }
        // logo_watermark: checkbox hai — unchecked hone pe POST mein nahi aata
        // Hamesha update karo — isset check nahi lagana (0 value bhi valid hai)
        $data['logo_watermark'] = ! empty( $_POST['logo_watermark'] ) ? 1 : 0;
        $data['logo_no_margin'] = ! empty( $_POST['logo_no_margin'] ) ? 1 : 0;
        $data['logo_opacity']   = isset( $_POST['logo_opacity'] ) && $_POST['logo_opacity'] !== '' ? max( 0, min( 100, intval( $_POST['logo_opacity'] ) ) ) : 80;
        $data['logo_size']      = isset( $_POST['logo_size'] )    && $_POST['logo_size'] !== ''    ? max( 5, min( 80,  intval( $_POST['logo_size'] ) ) )    : 20;
        if ( isset( $_POST['logo_position'] ) ) {
            $data['logo_position'] = sanitize_text_field( wp_unslash( $_POST['logo_position'] ) );
        }
        if ( isset( $_POST['content_mode'] ) && in_array( $_POST['content_mode'], array( 'direct', 'translate', 'api_translate' ), true ) ) {
            $data['content_mode'] = $_POST['content_mode'];
        }

        $result = AE_Feed_Manager::get_instance()->update_feed( $feed_id, $data );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => 'Failed to update feed.' ) );
        }

        wp_send_json_success( array( 'message' => 'Feed updated successfully!' ) );
    }

    /**
     * AJAX: Delete a feed.
     */
    public function ajax_delete_feed() {
        $this->verify_ajax();

        $feed_id = isset( $_POST['feed_id'] ) ? absint( $_POST['feed_id'] ) : 0;
        if ( ! $feed_id ) {
            wp_send_json_error( array( 'message' => 'Invalid feed ID.' ) );
        }

        $result = AE_Feed_Manager::get_instance()->delete_feed( $feed_id );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => 'Failed to delete feed.' ) );
        }

        wp_send_json_success( array( 'message' => 'Feed deleted successfully!' ) );
    }

    /**
     * AJAX: Toggle feed active status.
     */
    public function ajax_toggle_feed() {
        $this->verify_ajax();

        $feed_id = isset( $_POST['feed_id'] ) ? absint( $_POST['feed_id'] ) : 0;
        if ( ! $feed_id ) {
            wp_send_json_error( array( 'message' => 'Invalid feed ID.' ) );
        }

        $new_status = AE_Feed_Manager::get_instance()->toggle_feed( $feed_id );

        wp_send_json_success( array(
            'message'    => $new_status ? 'Feed activated.' : 'Feed deactivated.',
            'active'     => $new_status,
            'new_status' => $new_status ? 1 : 0,
        ) );
    }

    /**
     * AJAX: Test a feed URL.
     */
    public function ajax_test_feed() {
        $this->verify_ajax();

        $url = isset( $_POST['feed_url'] ) ? esc_url_raw( wp_unslash( $_POST['feed_url'] ) ) : '';

        $result = AE_Feed_Manager::get_instance()->test_feed( $url );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array(
            'message' => 'Feed is working!',
            'items'   => $result,
        ) );
    }

    /**
     * AJAX: Get all feeds.
     */
    public function ajax_get_feeds() {
        $this->verify_ajax();

        $feeds = AE_Feed_Manager::get_instance()->get_feeds();

        // Enrich with category names
        foreach ( $feeds as &$feed ) {
            // Parse category_ids from JSON (column may not exist yet on older installs)
            $cat_ids = array();
            $raw_ids = isset( $feed->category_ids ) ? $feed->category_ids : null;
            if ( ! empty( $raw_ids ) ) {
                $decoded = json_decode( $raw_ids, true );
                if ( is_array( $decoded ) ) {
                    $cat_ids = $decoded;
                }
            }
            // Fallback to legacy single category_id
            if ( empty( $cat_ids ) && ! empty( $feed->category_id ) ) {
                $cat_ids = array( (int) $feed->category_id );
            }
            // IMPORTANT: JS ke saath match karne ke liye sab IDs strings mein convert karo
            // jQuery .val(['5','8']) kaam karta hai, .val([5,8]) integers kaam NAHI karta
            $feed->category_ids = array_map( 'strval', array_filter( $cat_ids ) );

            // Build display names
            $cat_names = array();
            foreach ( $cat_ids as $cid ) {
                $cat = get_category( $cid );
                if ( $cat ) {
                    $cat_names[] = $cat->name;
                }
            }
            $feed->category_name          = ! empty( $cat_names ) ? $cat_names[0] : '—';
            $feed->category_names_display = ! empty( $cat_names ) ? implode( ', ', $cat_names ) : '—';

            // Logo watermark fields — ensure always present (migration se pehle null ho sakta hai)
            $feed->logo_watermark = isset( $feed->logo_watermark ) ? (int) $feed->logo_watermark : 0;
            $feed->logo_position  = ! empty( $feed->logo_position ) ? $feed->logo_position : 'bottom-right';
            $feed->logo_opacity   = isset( $feed->logo_opacity )   ? (int) $feed->logo_opacity   : 80;
            $feed->logo_size      = isset( $feed->logo_size )      ? (int) $feed->logo_size      : 20;
            $feed->logo_no_margin = isset( $feed->logo_no_margin ) ? (int) $feed->logo_no_margin : 0;
            $feed->content_mode   = ! empty( $feed->content_mode ) ? $feed->content_mode : 'direct';
        }

        // Har feed ke liye post counts attach karo: aaj ki news aur total news.
        // _ae_feed_id postmeta ke through count karte hain — single query mein
        // saari feeds ke counts nikal lete hain (N+1 query se bachne ke liye).
        $this->attach_feed_post_counts( $feeds );

        wp_send_json_success( array( 'feeds' => $feeds ) );
    }

    /**
     * Har feed object mein 'posts_today' aur 'posts_total' properties attach karo.
     * _ae_feed_id postmeta se publish hue posts count karte hain (sirf published
     * status), site ki current timezone ke hisaab se "aaj" calculate karte hain.
     *
     * @param array $feeds Array of feed objects (by reference modified).
     */
    private function attach_feed_post_counts( &$feeds ) {
        global $wpdb;

        if ( empty( $feeds ) ) {
            return;
        }

        // Default 0 set karo sabke liye pehle (taaki koi post na hone par bhi field exist kare).
        foreach ( $feeds as $feed ) {
            $feed->posts_today = 0;
            $feed->posts_total = 0;
        }

        // Total counts — feed_id => count, sirf published posts.
        $total_rows = $wpdb->get_results(
            "SELECT pm.meta_value AS feed_id, COUNT(*) AS cnt
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_ae_feed_id'
               AND p.post_status = 'publish'
             GROUP BY pm.meta_value"
        );

        $total_map = array();
        foreach ( $total_rows as $row ) {
            $total_map[ (int) $row->feed_id ] = (int) $row->cnt;
        }

        // Aaj ki counts — site ki current timezone ke "today" ke hisaab se.
        $today_start = current_time( 'Y-m-d 00:00:00' );
        $today_end   = current_time( 'Y-m-d 23:59:59' );

        $today_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT pm.meta_value AS feed_id, COUNT(*) AS cnt
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key = '_ae_feed_id'
                   AND p.post_status = 'publish'
                   AND p.post_date >= %s
                   AND p.post_date <= %s
                 GROUP BY pm.meta_value",
                $today_start,
                $today_end
            )
        );

        $today_map = array();
        foreach ( $today_rows as $row ) {
            $today_map[ (int) $row->feed_id ] = (int) $row->cnt;
        }

        foreach ( $feeds as $feed ) {
            $fid = (int) $feed->id;
            $feed->posts_total = isset( $total_map[ $fid ] ) ? $total_map[ $fid ] : 0;
            $feed->posts_today = isset( $today_map[ $fid ] ) ? $today_map[ $fid ] : 0;
        }
    }

    /**
     * AJAX: Fetch now (manual trigger).
     */
    public function ajax_fetch_now() {
        $this->verify_ajax();

        $feed_id   = isset( $_POST['feed_id'] ) ? absint( $_POST['feed_id'] ) : 0;
        $settings  = get_option( 'auto_engine_settings', array() );
        // Auto Fetch ON hai ya "Fetch All" (feed_id=0) → bulk mode: saari feeds se saare items
        $bulk_mode = ! empty( $settings['auto_fetch_enabled'] ) || $feed_id === 0;
        $results   = AE_Auto_Engine::get_instance()->process_feeds( $feed_id, $bulk_mode );

        wp_send_json_success( array(
            'message' => sprintf(
                'Processing complete! Published: %d, Duplicates: %d, Skipped: %d, Errors: %d',
                $results['published'],
                $results['duplicates'],
                $results['skipped'],
                $results['errors']
            ),
            'results' => $results,
        ) );
    }

    /**
     * AJAX: Save settings.
     */
    public function ajax_save_settings() {
        $this->verify_ajax();

        $settings = get_option( 'auto_engine_settings', array() );

        // General
        if ( isset( $_POST['cron_interval'] ) ) {
            $settings['cron_interval'] = max( 1, absint( $_POST['cron_interval'] ) );
        }
        // Post status hamesha publish — draft option removed
        $settings['post_status'] = 'publish';
        if ( isset( $_POST['max_content_age_hours'] ) ) {
            $settings['max_content_age_hours'] = absint( $_POST['max_content_age_hours'] );
        }
        if ( isset( $_POST['shuffle_recent_items'] ) ) {
            $settings['shuffle_recent_items'] = (bool) $_POST['shuffle_recent_items'];
        } else {
            $settings['shuffle_recent_items'] = false;
        }
        if ( isset( $_POST['shuffle_pool_size'] ) ) {
            $settings['shuffle_pool_size'] = max( 2, absint( $_POST['shuffle_pool_size'] ) );
        }
        if ( isset( $_POST['min_word_count'] ) ) {
            $settings['min_word_count'] = absint( $_POST['min_word_count'] );
        }
        if ( isset( $_POST['scrape_short_content'] ) ) {
            $settings['scrape_short_content'] = (bool) $_POST['scrape_short_content'];
        }
        if ( isset( $_POST['scrape_min_word_count'] ) ) {
            $settings['scrape_min_word_count'] = absint( $_POST['scrape_min_word_count'] );
        }
        if ( isset( $_POST['rate_limit_hour'] ) ) {
            $settings['rate_limit_hour'] = absint( $_POST['rate_limit_hour'] );
        }
        if ( isset( $_POST['rate_limit_day'] ) ) {
            $settings['rate_limit_day'] = absint( $_POST['rate_limit_day'] );
        }

        // AI
        if ( isset( $_POST['ai_enabled'] ) ) {
            $settings['ai_enabled'] = (bool) $_POST['ai_enabled'];
        }
        if ( isset( $_POST['ai_provider'] ) ) {
            $allowed_providers = array( 'openai', 'anthropic' );
            $settings['ai_provider'] = in_array( $_POST['ai_provider'], $allowed_providers, true ) ? $_POST['ai_provider'] : 'openai';
        }
        if ( isset( $_POST['ai_api_key'] ) ) {
            $settings['ai_api_key'] = sanitize_text_field( wp_unslash( $_POST['ai_api_key'] ) );
        }
        if ( isset( $_POST['ai_model'] ) ) {
            $settings['ai_model'] = sanitize_text_field( wp_unslash( $_POST['ai_model'] ) );
        }
        if ( isset( $_POST['ai_rewrite_title'] ) ) {
            $settings['ai_rewrite_title'] = (bool) $_POST['ai_rewrite_title'];
        }
        if ( isset( $_POST['ai_rewrite_content'] ) ) {
            $settings['ai_rewrite_content'] = (bool) $_POST['ai_rewrite_content'];
        }
        if ( isset( $_POST['ai_custom_prompt'] ) ) {
            $settings['ai_custom_prompt'] = sanitize_textarea_field( wp_unslash( $_POST['ai_custom_prompt'] ) );
        }

        // Image
        if ( isset( $_POST['image_insert'] ) ) {
            $settings['image_insert'] = (bool) $_POST['image_insert'];
        }
        if ( isset( $_POST['image_position'] ) ) {
            $settings['image_position'] = max( 1, absint( $_POST['image_position'] ) );
        }

        // Watermark
        if ( isset( $_POST['watermark_enabled'] ) ) {
            $settings['watermark_enabled'] = (bool) $_POST['watermark_enabled'];
        }
        if ( isset( $_POST['watermark_image'] ) ) {
            $settings['watermark_image'] = absint( $_POST['watermark_image'] );
        }
        if ( isset( $_POST['watermark_position'] ) ) {
            $allowed = array( 'top-left', 'top-center', 'top-right', 'center-left', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right' );
            $settings['watermark_position'] = in_array( $_POST['watermark_position'], $allowed, true ) ? $_POST['watermark_position'] : 'bottom-right';
        }
        if ( isset( $_POST['watermark_opacity'] ) ) {
            $settings['watermark_opacity'] = max( 0, min( 100, absint( $_POST['watermark_opacity'] ) ) );
        }
        if ( isset( $_POST['watermark_size'] ) ) {
            $settings['watermark_size'] = max( 5, min( 80, absint( $_POST['watermark_size'] ) ) );
        }

        // Watermark no-margin
        $settings['watermark_no_margin'] = ! empty( $_POST['watermark_no_margin'] );

        // Text Watermark
        $settings['text_watermark_enabled'] = ! empty( $_POST['text_watermark_enabled'] );
        if ( isset( $_POST['twm_bold_text'] ) ) {
            $settings['twm_bold_text'] = sanitize_text_field( wp_unslash( $_POST['twm_bold_text'] ) );
        }
        if ( isset( $_POST['twm_random_text'] ) ) {
            $settings['twm_random_text'] = sanitize_text_field( wp_unslash( $_POST['twm_random_text'] ) );
        }

        // Title Filter Keywords
        if ( isset( $_POST['title_filter_keywords'] ) ) {
            $raw_kws  = sanitize_textarea_field( wp_unslash( $_POST['title_filter_keywords'] ) );
            $kw_lines = array_filter( array_map( 'trim', explode( "\n", $raw_kws ) ) );
            // Lowercase + deduplicate — case-insensitive matching ke liye
            $kw_lines = array_values( array_unique( array_map( 'mb_strtolower', $kw_lines ) ) );
            $settings['title_filter_keywords'] = $kw_lines;
        }

        // Find & Replace rules
        if ( isset( $_POST['find_replace_rules'] ) ) {
            $raw_rules = json_decode( stripslashes( $_POST['find_replace_rules'] ), true );
            $clean_rules = array();

            if ( is_array( $raw_rules ) ) {
                foreach ( $raw_rules as $rule ) {
                    $rule_type     = isset( $rule['type'] ) ? $rule['type'] : 'normal';
                    $allowed_types = array( 'normal', 'remove_brackets', 'remove_curly', 'remove_square' );
                    $special_types = array( 'remove_brackets', 'remove_curly', 'remove_square' );

                    // Normal type mein find field zaroori hai, special types mein nahi
                    if ( ! in_array( $rule_type, $special_types, true ) && empty( $rule['find'] ) ) {
                        continue;
                    }
                    $clean_rules[] = array(
                        'find'    => sanitize_text_field( $rule['find'] ),
                        'replace' => isset( $rule['replace'] ) ? sanitize_text_field( $rule['replace'] ) : '',
                        'target'  => in_array( $rule['target'], array( 'title', 'content', 'both' ), true ) ? $rule['target'] : 'both',
                        'type'    => in_array( $rule_type, $allowed_types, true ) ? $rule_type : 'normal',
                    );
                }
            }

            $settings['find_replace_rules'] = $clean_rules;
        }

        // Max posts per fetch cycle (0 = unlimited)
        if ( isset( $_POST['max_posts_per_cycle'] ) ) {
            $settings['max_posts_per_cycle'] = absint( $_POST['max_posts_per_cycle'] );
        }

        // Auto Fetch Schedule — Enable/Disable
        $settings['auto_fetch_enabled'] = ! empty( $_POST['auto_fetch_enabled'] ) ? 1 : 0;

        // Auto Fetch Interval (minutes) — replaces time slots
        if ( isset( $_POST['fetch_interval_minutes'] ) ) {
            $settings['fetch_interval_minutes'] = max( 1, absint( $_POST['fetch_interval_minutes'] ) );
        }

        // Keep backward compat: auto_fetch_times is no longer needed but preserve if present
        if ( isset( $_POST['auto_fetch_times'] ) ) {
            $raw_times   = json_decode( stripslashes( $_POST['auto_fetch_times'] ), true );
            $clean_times = array();

            if ( is_array( $raw_times ) ) {
                foreach ( $raw_times as $t ) {
                    $t = sanitize_text_field( $t );
                    if ( preg_match( '/^\d{2}:\d{2}$/', $t ) ) {
                        $clean_times[] = $t;
                    }
                }
            }

            $settings['auto_fetch_times'] = array_values( array_unique( $clean_times ) );
        }

        // Title Symbol / ZWC settings
        if ( isset( $_POST['title_symbol'] ) ) {
            $settings['title_symbol'] = sanitize_text_field( $_POST['title_symbol'] );
        }
        if ( isset( $_POST['title_symbol_type'] ) ) {
            $allowed_types = array( 'zwc', 'star', 'bullet', 'caret', 'hash', 'pipe', 'dot', 'dash', 'custom', 'none' );
            $type = sanitize_text_field( $_POST['title_symbol_type'] );
            $settings['title_symbol_type'] = in_array( $type, $allowed_types, true ) ? $type : 'zwc';
        }
        if ( isset( $_POST['title_symbol_position'] ) ) {
            $allowed_pos = array( 'prefix', 'suffix', 'both', 'none' );
            $pos = sanitize_text_field( $_POST['title_symbol_position'] );
            $settings['title_symbol_position'] = in_array( $pos, $allowed_pos, true ) ? $pos : 'prefix';
        }

        // Time Slots (IST)
        if ( isset( $_POST['time_slots'] ) ) {
            $raw_slots  = json_decode( stripslashes( $_POST['time_slots'] ), true );
            $clean_slots = array();

            if ( is_array( $raw_slots ) ) {
                foreach ( $raw_slots as $slot ) {
                    $start = isset( $slot['start'] ) ? sanitize_text_field( $slot['start'] ) : '';
                    $end   = isset( $slot['end'] )   ? sanitize_text_field( $slot['end'] )   : '';

                    // Validate HH:MM format
                    if ( preg_match( '/^\d{2}:\d{2}$/', $start ) && preg_match( '/^\d{2}:\d{2}$/', $end ) ) {
                        $clean_slots[] = array( 'start' => $start, 'end' => $end );
                    }
                }
            }

            $settings['time_slots'] = $clean_slots;
        }

        // Force update even if value appears same (WP caches and skips identical values)
        delete_option( 'auto_engine_settings' );
        add_option( 'auto_engine_settings', $settings, '', 'yes' );

        // Reschedule cron if interval changed
        AE_Cron_Handler::get_instance()->reschedule();

        // Reload settings in modules
        AE_AI_Rewriter::get_instance()->reload_settings();
        AE_Image_Handler::get_instance()->reload_settings();
        AE_Publisher::get_instance()->reload_settings();
        AE_Rate_Limiter::get_instance()->reload_settings();

        wp_send_json_success( array(
            'message'               => 'Settings saved successfully!',
            'auto_fetch_enabled'    => ! empty( $settings['auto_fetch_enabled'] ) ? 1 : 0,
            'fetch_interval_minutes'=> isset( $settings['fetch_interval_minutes'] ) ? intval( $settings['fetch_interval_minutes'] ) : 2,
            'last_fetch_ts'         => absint( get_option( 'ae_last_bulk_fetch_ts', 0 ) ),
        ) );
    }

    /**
     * AJAX: Get logs.
     */
    public function ajax_get_logs() {
        $this->verify_ajax();

        $args = array(
            'log_type' => isset( $_POST['log_type'] ) ? sanitize_text_field( wp_unslash( $_POST['log_type'] ) ) : '',
            'feed_id'  => isset( $_POST['feed_id'] ) ? absint( $_POST['feed_id'] ) : 0,
            'per_page' => isset( $_POST['per_page'] ) ? absint( $_POST['per_page'] ) : 50,
            'page'     => isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1,
            'search'   => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '',
        );

        $result = AE_Logger::get_instance()->get_logs( $args );

        // Pass all feeds for the feed filter dropdown (only on first load)
        if ( empty( $args['feed_id'] ) && empty( $args['log_type'] ) && empty( $args['search'] ) && $args['page'] === 1 ) {
            $feeds = AE_Feed_Manager::get_instance()->get_feeds();
            $result['feeds'] = array_map( function( $f ) {
                return array( 'id' => $f->id, 'name' => $f->feed_name ?: $f->feed_url );
            }, $feeds );
        }

        wp_send_json_success( $result );
    }

    /**
     * AJAX: Clear all logs.
     */
    public function ajax_clear_logs() {
        $this->verify_ajax();
        AE_Logger::get_instance()->clear_all();
        wp_send_json_success( array( 'message' => 'All logs cleared.' ) );
    }

    /**
     * AJAX: Test AI connection.
     */
    public function ajax_test_ai() {
        $this->verify_ajax();
        $result = AE_AI_Rewriter::get_instance()->test_connection();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( $result );
    }

    /**
     * AJAX: Reprocess a post.
     */
    public function ajax_reprocess_post() {
        $this->verify_ajax();

        $post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => 'Invalid post ID.' ) );
        }

        $result = AE_Publisher::get_instance()->reprocess( $post_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'message' => 'Post reprocessed successfully!' ) );
    }

    /**
     * Save cron key + interval.
     */
    public function ajax_save_cron_settings() {
        $this->verify_ajax();

        $interval = isset( $_POST['cron_interval'] ) ? max( 1, absint( $_POST['cron_interval'] ) ) : 2;
        update_option( 'ae_cron_interval', $interval );

        // Generate key if not exists
        $key = get_option( 'ae_direct_cron_key', '' );
        if ( empty( $key ) ) {
            $key = wp_generate_password( 32, false );
            update_option( 'ae_direct_cron_key', $key );
        }

        $trigger_url = home_url( '/?ae_cron=1&ae_key=' . $key );
        $command     = 'curl -s "' . $trigger_url . '" > /dev/null';
        $schedule    = '*/' . $interval . ' * * * *';

        wp_send_json_success( array(
            'message'      => 'Cron settings saved!',
            'key'          => $key,
            'trigger_url'  => $trigger_url,
            'command'      => $command,
            'schedule'     => $schedule,
            'interval'     => $interval,
        ) );
    }

    /**
     * Generate a new cron key.
     */
    public function ajax_generate_cron_key() {
        $this->verify_ajax();

        $key = wp_generate_password( 32, false );
        update_option( 'ae_direct_cron_key', $key );

        $trigger_url = home_url( '/?ae_cron=1&ae_key=' . $key );

        wp_send_json_success( array(
            'key'         => $key,
            'trigger_url' => $trigger_url,
            'command'     => 'curl -s "' . $trigger_url . '" > /dev/null',
        ) );
    }

    /**
     * Manually test cron trigger.
     */
    public function ajax_test_cron() {
        $this->verify_ajax();

        if ( ! defined( 'DOING_CRON' ) ) {
            define( 'DOING_CRON', true );
        }

        $handler = AE_Cron_Handler::get_instance();

        $in_slot = $handler->is_within_time_slot();

        if ( ! $in_slot ) {
            wp_send_json_success( array(
                'status'  => 'skipped',
                'message' => '⏰ Cron trigger hua, lekin abhi time slot ke bahar hai — feed skip hua. Time slot ke andar aane par automatically publish hogi.',
            ) );
            return;
        }

        $handler->run();

        wp_send_json_success( array(
            'status'  => 'ok',
            'message' => '✅ Cron successfully run hua! Logs check karo — agar koi due feed thi toh publish ho gayi hogi.',
        ) );
    }

    /**
     * AJAX: Export all feeds as JSON.
     */
    public function ajax_export_feeds() {
        $this->verify_ajax();

        $feeds = AE_Feed_Manager::get_instance()->get_feeds();
        $export = array();

        foreach ( $feeds as $feed ) {
            // Category names bhi include karo taaki import pe mapping ho sake
            $cat_ids = array();
            if ( ! empty( $feed->category_ids ) ) {
                $cat_ids = json_decode( $feed->category_ids, true );
            } elseif ( ! empty( $feed->category_id ) ) {
                $cat_ids = array( (int) $feed->category_id );
            }

            $cat_names = array();
            foreach ( $cat_ids as $cid ) {
                $term = get_term( $cid, 'category' );
                if ( $term && ! is_wp_error( $term ) ) {
                    $cat_names[] = $term->name;
                }
            }

            $export[] = array(
                'feed_url'       => $feed->feed_url,
                'feed_name'      => $feed->feed_name,
                'fetch_mode'     => $feed->fetch_mode,
                'image_mode'     => $feed->image_mode,
                'fetch_interval' => (int) $feed->fetch_interval,
                'is_active'      => (int) $feed->is_active,
                'logo_watermark' => (int) $feed->logo_watermark,
                'logo_position'  => $feed->logo_position ?: 'bottom-right',
                'content_mode'   => $feed->content_mode ?: 'direct',
                // Original category IDs aur names dono export karo
                'original_category_ids'   => $cat_ids,
                'original_category_names' => $cat_names,
            );
        }

        wp_send_json_success( array(
            'feeds'      => $export,
            'count'      => count( $export ),
            'site_url'   => get_bloginfo( 'url' ),
            'site_name'  => get_bloginfo( 'name' ),
            'exported_at'=> current_time( 'mysql' ),
        ) );
    }

    /**
     * AJAX: Import feeds from JSON (with category mapping).
     */
    public function ajax_import_feeds() {
        $this->verify_ajax();

        $raw = isset( $_POST['feeds'] ) ? wp_unslash( $_POST['feeds'] ) : '';
        if ( empty( $raw ) ) {
            wp_send_json_error( array( 'message' => 'Feeds data missing.' ) );
        }

        $feeds = json_decode( $raw, true );
        if ( ! is_array( $feeds ) ) {
            wp_send_json_error( array( 'message' => 'Invalid JSON data.' ) );
        }

        // Category mapping: { "original_feed_url" => [new_cat_ids] }
        $mapping_raw = isset( $_POST['category_mapping'] ) ? wp_unslash( $_POST['category_mapping'] ) : '{}';
        $cat_mapping = json_decode( $mapping_raw, true );
        if ( ! is_array( $cat_mapping ) ) {
            $cat_mapping = array();
        }

        $imported = 0;
        $skipped  = 0;
        $errors   = array();

        foreach ( $feeds as $feed ) {
            $feed_url = isset( $feed['feed_url'] ) ? esc_url_raw( $feed['feed_url'] ) : '';
            if ( empty( $feed_url ) ) {
                $skipped++;
                continue;
            }

            // Is URL ka category mapping dekho
            $new_cat_ids = isset( $cat_mapping[ $feed_url ] ) && is_array( $cat_mapping[ $feed_url ] )
                ? array_map( 'absint', $cat_mapping[ $feed_url ] )
                : array();

            $insert_data = array(
                'feed_url'       => $feed_url,
                'feed_name'      => isset( $feed['feed_name'] ) ? sanitize_text_field( $feed['feed_name'] ) : '',
                'category_ids'   => $new_cat_ids,
                'fetch_mode'     => isset( $feed['fetch_mode'] ) ? sanitize_text_field( $feed['fetch_mode'] ) : 'new_only',
                'image_mode'     => isset( $feed['image_mode'] ) ? sanitize_text_field( $feed['image_mode'] ) : 'featured_only',
                'fetch_interval' => isset( $feed['fetch_interval'] ) ? absint( $feed['fetch_interval'] ) : 10,
                'logo_watermark' => ! empty( $feed['logo_watermark'] ) ? 1 : 0,
                'logo_position'  => isset( $feed['logo_position'] ) ? sanitize_text_field( $feed['logo_position'] ) : 'bottom-right',
                'content_mode'   => isset( $feed['content_mode'] ) && in_array( $feed['content_mode'], array( 'direct', 'translate', 'api_translate' ), true ) ? $feed['content_mode'] : 'direct',
            );

            $result = AE_Feed_Manager::get_instance()->add_feed( $insert_data );
            if ( false !== $result ) {
                $imported++;
            } else {
                $errors[] = $feed_url;
            }
        }

        $msg = sprintf( '%d feeds import ho gayi', $imported );
        if ( $skipped > 0 ) {
            $msg .= sprintf( ', %d skip hui', $skipped );
        }
        if ( ! empty( $errors ) ) {
            $msg .= sprintf( ', %d fail hui', count( $errors ) );
        }

        wp_send_json_success( array(
            'message'  => $msg,
            'imported' => $imported,
            'skipped'  => $skipped,
            'errors'   => $errors,
        ) );
    }

    /**
     * "All Posts" list table mein "Auto Engine" column add karo.
     * Yeh column WordPress Screen Options panel mein automatically
     * show/hide checkbox ke saath aa jaata hai (core ka behavior).
     *
     * @param array $columns Existing columns.
     * @return array Modified columns.
     */
    public function add_feed_source_column( $columns ) {
        // Date column se pehle insert karo, taaki natural lage.
        $new_columns = array();
        foreach ( $columns as $key => $label ) {
            if ( 'date' === $key ) {
                $new_columns['ae_feed_source'] = '📡 Auto Engine';
            }
            $new_columns[ $key ] = $label;
        }
        // Agar 'date' column kisi wajah se nahi mila, to end mein add karo (fallback).
        if ( ! isset( $new_columns['ae_feed_source'] ) ) {
            $new_columns['ae_feed_source'] = '📡 Auto Engine';
        }
        return $new_columns;
    }

    /**
     * "Auto Engine" column ka content render karo — kis feed se post aayi hai.
     *
     * @param string $column  Column key.
     * @param int    $post_id Post ID.
     */
    public function render_feed_source_column( $column, $post_id ) {
        if ( 'ae_feed_source' !== $column ) {
            return;
        }

        $feed_id = get_post_meta( $post_id, '_ae_feed_id', true );
        if ( empty( $feed_id ) ) {
            echo '<span style="color:#999;">—</span>';
            return;
        }

        $feed_name = $this->get_cached_feed_name( (int) $feed_id );
        if ( $feed_name ) {
            echo '<span style="display:inline-block;padding:2px 8px;background:#eef6ff;color:#2563eb;border-radius:3px;font-size:12px;font-weight:600;">📡 ' . esc_html( $feed_name ) . '</span>';
        } else {
            // Feed delete ho gayi ho sakti hai — sirf indicate karo ki ye Auto Engine se aayi thi.
            echo '<span style="display:inline-block;padding:2px 8px;background:#f3f4f6;color:#6b7280;border-radius:3px;font-size:12px;">📡 Auto Engine</span>';
        }
    }

    /**
     * Feed names ko request ke duration ke liye cache karo, taaki "All Posts"
     * list mein har row ke liye alag DB query na chale.
     *
     * @param int $feed_id Feed ID.
     * @return string|false Feed name ya false agar feed nahi mili.
     */
    private function get_cached_feed_name( $feed_id ) {
        static $cache = array();

        if ( array_key_exists( $feed_id, $cache ) ) {
            return $cache[ $feed_id ];
        }

        $feed = AE_Feed_Manager::get_instance()->get_feed( $feed_id );
        $cache[ $feed_id ] = $feed && ! empty( $feed->feed_name ) ? $feed->feed_name : false;

        return $cache[ $feed_id ];
    }
}
